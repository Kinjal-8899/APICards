//
//  Configuration.swift
//  APICards
//
//  Created by Harindra Pittalia on 12/04/22.
//

import Foundation

//MARK: - Environment
enum Environment: String {
    case dev = "Dev"
    case stage = "Stage"
    case release = "Release"

    var hostUrl:String {
        switch self {
            case .dev: return "http://1177-157-32-123-250.in.ngrok.io/api/v1"
            case .stage: return "http://1177-157-32-123-250.in.ngrok.io/api/v1"
            case .release: return "http://13.127.182.178/api/v1"
        }
    }
    
    var privacyPolicy:String {
        switch self {
            case .dev: return "https://0b9222e890d8.ngrok.io/privacy.html"
            case .stage: return "http://23.22.140.172/privacy.html"
            case .release: return "https://olp-media.com/privacy.html"
        }
    }
    
    var termsAndCondition:String {
        switch self {
            case .dev: return "https://0b9222e890d8.ngrok.io/terms-of-service.html"
            case .stage: return "http://23.22.140.172/terms-of-service.html"
            case .release: return "https://olp-media.com/terms-of-service.html"
        }
    }
   
    var about:String {
        switch self {
            case .dev: return "https://0b9222e890d8.ngrok.io/about-us.html"
            case .stage: return "http://23.22.140.172/about-us.html"
            case .release: return "https://olp-media.com/about-us.html"
        }
    }
    
    var isDevBuild: Bool {
        return self == .dev
    }
    
    var isReleaseBuild: Bool {
        return self == .release
    }
    
    var isStageBuild: Bool {
        return self == .stage
    }
}

//MARK: - Configuration
struct Configuration {
    static var environment: Environment = {
        if let configuration = Bundle.main.object(forInfoDictionaryKey: "Configuration") as? String {
            if configuration.range(of: "Dev") != nil {
                return Environment.dev
            } else if configuration.range(of: "Stage") != nil {
                return Environment.stage
            }
        }
        return Environment.release
    }()
}
