//
//  ACDashboardVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 20/06/22.
//

import UIKit

class ACDashboardVC: UIViewController {

    @IBOutlet weak var viewAllBtn: UIButton!
    @IBOutlet weak var secondView: UIStackView!
    @IBOutlet weak var thirdView: CardView!
    @IBOutlet weak var firstView: CardView!
    @IBOutlet weak var runningJobTimer: UILabel!
    @IBOutlet weak var runningJobStartTime: UILabel!
    @IBOutlet weak var runningJobDesc: UILabel!
    @IBOutlet weak var runningJobTitle: UILabel!
    @IBOutlet weak var lblJoinedDate: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var tblViewHeight: NSLayoutConstraint!
    @IBOutlet weak var upcomingTableView: UITableView!
    @IBOutlet weak var lblTotalCompletedJobs: UILabel!
    @IBOutlet weak var lblTotalJobs: UILabel!
    @IBOutlet weak var lblRemainJob: UILabel!
    @IBOutlet weak var lblTotalEarnedMoney: UILabel!
    @IBOutlet weak var lblTodayMoney: UILabel!
    @IBOutlet weak var profileImageView: UIImageView!
    
    //MARK: - Variables
    var noOfRowsDisplay: Int = 0
    var isViewAll: Bool = false
    var jobArray: [JobData] = [JobData]()
    var upcomingJobArray: [JobData] = [JobData]()
    var ongoingJob: JobData?
    
    var jobViewModel = JobViewModel()
    var timer: Timer?
    
    var profileViewModel = ProfileViewModel()
    var userData: LoginResponseData?
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        lblUserName.text = UserDefaultHelper.userName
        lblJoinedDate.text = String.getCurrentDateStr()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(profilePicTapped(_:)))
        self.profileImageView.addGestureRecognizer(tap)
        
        
        let tapOngoingView = UITapGestureRecognizer(target: self, action: #selector(ongoingViewTapped(_:)))
        self.firstView.addGestureRecognizer(tapOngoingView)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
//        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItem.Style.plain, target: nil, action: nil)
//        self.navigationItem.backBarButtonItem?.tintColor = .black
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @objc func ongoingViewTapped(_ sender: UITapGestureRecognizer) {
        let aVC = ACJobDetailsVC.instantiate(storyboard: "Home")
        aVC.jobData = ongoingJob
        aVC.jobId = ongoingJob?.id
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    
    @objc func profilePicTapped(_ sender: UITapGestureRecognizer) {
        let aVC = ACProfileVC.instantiate(storyboard: "Home")
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
   
    //MARK: - Btn click events
    @IBAction func ongoingDetailBtnPressed(_ sender: UIButton) {
        let aVC = ACJobDetailsVC.instantiate(storyboard: "Home")
        aVC.jobData = ongoingJob
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func viewAllBtnClicked(_ sender: UIButton) {
        isViewAll = !isViewAll
        DispatchQueue.main.async {
            self.upcomingTableView.reloadData()
        }
    }
    
}

//MARK: - ACDashboardVC
extension ACDashboardVC {
    
    //MARK: - initial Setup
    func initialSetup() {
        upcomingTableView.register(ACUpcomingTVCell.nib(), forCellReuseIdentifier: ACUpcomingTVCell.identifier)
        upcomingTableView.register(ACNoDataTableViewCell.nib(), forCellReuseIdentifier: ACNoDataTableViewCell.identifier)
        
        profileViewModel.delegate = self
        jobViewModel.delegate = self
        self.upcomingTableView.isHidden = true
        
        viewAllBtn.isHidden = true
        getUserData()
        getJobList()
        getMoneyAndJobsData()
        
        
        if (UserDefaultHelper.jobIdInProgresss != nil) {
            firstView.isHidden = false
            
            self.runningJobTimer.text = UserDefaultHelper.strLatestTime
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimerLabel), userInfo: nil, repeats: true)
        } else {
            firstView.isHidden = true
        }
        
    }
    
    func getJobList() {
        thirdView.isHidden = true
        self.showActivityIndicator()
        let params = ["status" : "\(JobStatus.inProgress),\(JobStatus.inBreak),\(JobStatus.assigned)"]
        jobViewModel.getJobList(params: params)
    }
    
    func getMoneyAndJobsData() {
        secondView.isHidden = true
        self.showActivityIndicator()
        jobViewModel.getTodaysJobData()
    }
    
    //MARK: - update Timer Label
    @objc func updateTimerLabel() {
        self.runningJobTimer.text = SingleTonTimer.sharedTimer.currenttimeStr
    
    }
    
    func getUserData() {
       // self.showActivityIndicator()
        guard let userId = UserDefaultHelper.userId else { return }
        profileViewModel.getUserData(userId: userId)
    }
    
    func setUserData() {
        lblUserName.text = userData?.fullname
//        if userData?.profilePic == "" {
//            profileImageView.image = UIImage(named: "defaultPerson")
//        }
//        else {
//            let url : URL = URL(string: "\(APIUrls.imageBaseURL)\(userData?.profilePic ?? "")")!
//            profileImageView.sd_setImage(with: url)
//        }
    }
}


//MARK: - ACDashboardVC with UITableViewDelegate, UITableViewDataSource
extension ACDashboardVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isViewAll {
            noOfRowsDisplay = upcomingJobArray.count
        } else if upcomingJobArray.count == 0 {
            noOfRowsDisplay = 1
        }
        else {
            noOfRowsDisplay = min(upcomingJobArray.count, 5)
        }
        return noOfRowsDisplay
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if upcomingJobArray.count == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: ACNoDataTableViewCell.identifier, for: indexPath) as! ACNoDataTableViewCell
            cell.backgroundColor = UIColor(named: "AppViewColor")
            cell.contentView.backgroundColor = UIColor(named: "AppViewColor")
            cell.selectionStyle = .none
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: ACUpcomingTVCell.identifier, for: indexPath) as! ACUpcomingTVCell
            let job: JobData = upcomingJobArray[indexPath.row]
            cell.setup(title: job.name ?? "", rate: job.hourlyRate ?? 0)
            cell.selectionStyle = .none
//            if indexPath.row == noOfRowsDisplay - 1 {
//                cell.lineView.isHidden = true
//            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        tblViewHeight.constant = tableView.contentSize.height
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let aVC = ACJobDetailsVC.instantiate(storyboard: "Home")
        aVC.jobData = upcomingJobArray[indexPath.row]
        aVC.jobId = upcomingJobArray[indexPath.row].id
        self.navigationController?.pushViewController(aVC, animated: true)
    }
}

//MARK: - ACDashboardVC with JobViewModelDelegate
extension ACDashboardVC: JobViewModelDelegate {
    
    func didReceiveJobListResponse(jobsResponse: JobModel?) {
        self.hideActivityIndicator()
        if jobsResponse?.data != nil {
            jobArray = jobsResponse?.data ?? [JobData]()
            ongoingJob = jobArray.filter{ $0.status == JobStatus.inProgress || $0.status == JobStatus.inBreak }.first
            upcomingJobArray = jobArray.filter{ $0.status == JobStatus.assigned }
            DispatchQueue.main.async {
                if self.ongoingJob != nil {
                    self.runningJobTitle.text = self.ongoingJob?.name
                    self.runningJobDesc.text = self.ongoingJob?.datumDescription
                    self.runningJobStartTime.text = self.ongoingJob?.startTime?.changeDateFormateToUTC(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .dd_MM_yyyy_hh_mm_a)
                }
                if self.jobArray.count > 5 {
                    self.viewAllBtn.isHidden = false
                } else {
                    self.viewAllBtn.isHidden = true
                }
                self.thirdView.isHidden = false
                self.upcomingTableView.isHidden = false
                self.upcomingTableView.reloadData()
            }
        } else {
            openAlert(title: ACAlertTitle.oops, message: jobsResponse?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        }
    }
    
    func didReceiveTodayJobs(response: TodayJobModel?) {
        self.hideActivityIndicator()
        if response?.data == nil {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        } else {
            DispatchQueue.main.async {
                //change second view's data
                self.secondView.isHidden = false
                self.lblTodayMoney.text = "$\(response?.data?.todayPayment ?? "0.00")"
                self.lblTotalEarnedMoney.text = "$\(response?.data?.totalPayment ?? "0.00")"
                self.lblRemainJob.text = "\(response?.data?.todayRemainingJobs ?? 0)"
                self.lblTotalJobs.text = "Remain out of \(response?.data?.todayCompletedJobs ?? 0) Jobs"
                self.lblTotalCompletedJobs.text = "\(response?.data?.totalJobsDone ?? 0)"
            }
        }
    }
}

//MARK: - ACDashboardVC with ProfileViewModelDelegate
extension ACDashboardVC : ProfileViewModelDelegate {
    func didReceiveUserData(response: LoginResponse?) {
        self.hideActivityIndicator()
        if response?.data != nil {
            DispatchQueue.main.async {
                self.userData = response?.data
                self.setUserData()
            }
        } else {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        }
    }
}

