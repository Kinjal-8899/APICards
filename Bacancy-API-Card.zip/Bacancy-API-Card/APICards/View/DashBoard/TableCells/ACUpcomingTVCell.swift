//
//  ACUpcomingTVCell.swift
//  API Cards
//
//  Created by Harindra Pittalia on 20/06/22.
//

import UIKit

class ACUpcomingTVCell: UITableViewCell {
    
  
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblJobTitle: UILabel!
    @IBOutlet weak var lineView: UIView!
    static let identifier = "ACUpcomingTVCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func setup(title: String, rate: Int) {
        lblJobTitle.text = title
        lblAmount.text = "$\(rate)/hr"
    }
    
}
