//
//  CartItemTableViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 08/04/22.
//

import UIKit

class CartItemTableViewCell: UITableViewCell {

    @IBOutlet weak var itemLbl: UILabel!
    static let identifier = "CartItemTableViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setup(id: Int) {
        itemLbl.text = "Item No: \(id)"
    }
    
}
