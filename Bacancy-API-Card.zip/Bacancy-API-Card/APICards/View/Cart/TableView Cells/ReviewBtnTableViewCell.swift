//
//  ReviewBtnTableViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 11/04/22.
//

import UIKit

class ReviewBtnTableViewCell: UITableViewCell {

    static let identifier = "ReviewBtnTableViewCell"
    
    var completion : ((Bool) -> Void)?
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func reviewBtnPressed(_ sender: UIButton) {
        guard let completion = completion else {
            return
        }
        completion(true)
    }
}
