//
//  AmountTableViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 11/04/22.
//

import UIKit

class AmountTableViewCell: UITableViewCell {

    static let identifier = "AmountTableViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
