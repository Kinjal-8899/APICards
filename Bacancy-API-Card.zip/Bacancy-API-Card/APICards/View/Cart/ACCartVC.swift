//
//  ACCartVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 11/04/22.
//

import UIKit

class ACCartVC: UIViewController {

    @IBOutlet weak var cartTableView: UITableView!
    
    //Swipe up
    var formViewController: ACCartItemVC!
    var bgView: UIView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
    }
    
    @IBAction func menuBtnPressed(_ sender: UIBarButtonItem) {
        let aVC = ACMenuVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    private func setupTableView() {
        cartTableView.register(CartItemTableViewCell.nib(), forCellReuseIdentifier: CartItemTableViewCell.identifier)
        cartTableView.register(AmountTableViewCell.nib(), forCellReuseIdentifier: AmountTableViewCell.identifier)
        cartTableView.register(ReviewBtnTableViewCell.nib(), forCellReuseIdentifier: ReviewBtnTableViewCell.identifier)
    }

    private func setupSwipeUpView() {
        
        bgView = UIView()
        bgView.frame = view.frame
        bgView.backgroundColor = .black
        bgView.alpha = 0.5
        view.addSubview(bgView)
        
        self.formViewController = ACCartItemVC(nibName: "ACCartItemVC", bundle: nil)
        self.formViewController.view.frame = CGRect(x: 0, y: self.view.frame.height - (self.formViewController.containerView.frame.height + 80), width: self.view.frame.width, height: self.formViewController.containerView.frame.height + 80)
        self.formViewController.delegate = self
        
        self.addChild(self.formViewController)
        self.view.addSubview(self.formViewController.view)
    }
    
    private func closeSlideupView() {
        self.formViewController.view.removeFromSuperview()
        self.formViewController.removeFromParent()
        self.bgView.removeFromSuperview()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
}


extension ACCartVC: UpdateCartItem {
    func removebtnClicked(isClicked: Bool) {
        self.closeSlideupView()
    }
    
    func saveBtnClicked(noOfItems: Int, isSalesTax: Bool, desc: String) {
        self.closeSlideupView()
    }
    
    func closeBtnClicked(isClicked: Bool) {
        self.closeSlideupView()
    }
    
    
}
extension ACCartVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        } else if section == 1 {
            return 10
        } else {
            return 1
        }
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: AmountTableViewCell.identifier, for: indexPath) as! AmountTableViewCell
            return cell
        } else if indexPath.section == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: CartItemTableViewCell.identifier, for: indexPath) as! CartItemTableViewCell
            cell.setup(id: indexPath.row + 1)
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: ReviewBtnTableViewCell.identifier, for: indexPath) as! ReviewBtnTableViewCell
            cell.completion = {
                isClicked in
                if isClicked {
                    let aVC = ACPayableAmountVC.instantiate()
                    self.navigationController?.pushViewController(aVC, animated: true)
                }
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 100.0
        } else if indexPath.section == 1 {
            return 60.0
        } else {
            return 94
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        setupSwipeUpView()
    }
    
}
