//
//  ACCartItemVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 11/04/22.
//

import UIKit

protocol UpdateCartItem {
    func closeBtnClicked(isClicked: Bool)
    func removebtnClicked(isClicked: Bool)
    func saveBtnClicked(noOfItems: Int, isSalesTax: Bool, desc: String)
}

class ACCartItemVC: UIViewController {
    
    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var salesTaxSwitch: UISwitch!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var quantityLbl: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var containerView: UIView!
    
    var delegate : UpdateCartItem?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.roundCorners(corners: [.topLeft,.topRight], radius: 30)
        containerView.roundCorners(corners: [.topLeft, .topRight], radius: 30)
       
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.view.roundCorners(corners: [.topLeft,.topRight], radius: 30)
        containerView.roundCorners(corners: [.topLeft, .topRight], radius: 30)
    }

    @IBAction func saleTaxSwitchPressed(_ sender: UISwitch) {
        
    }
    
    @IBAction func saveBtnPrssed(_ sender: UIButton) {
        delegate?.closeBtnClicked(isClicked: true)
    }
    
    @IBAction func closeBtnPressed(_ sender: UIButton) {
        delegate?.closeBtnClicked(isClicked: true)
    }
    
    
    @IBAction func removeItemBtnPressed(_ sender: UIButton) {
        delegate?.closeBtnClicked(isClicked: true)
    }
    
    
    @IBAction func minusPressed(_ sender: UIButton) {
        if Int(quantityLbl.text!)! - 1 > 1 {
            quantityLbl.text = "\( Int(quantityLbl.text!)! - 1 )"
        } else {
            quantityLbl.text = "1"
        }
    }
    
    @IBAction func plusPressed(_ sender: UIButton) {
        quantityLbl.text = "\( Int(quantityLbl.text!)! + 1 )"
    }
    
}



