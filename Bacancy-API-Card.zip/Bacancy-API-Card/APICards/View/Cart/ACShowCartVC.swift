//
//  ACShowCartVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 08/04/22.
//

import UIKit

class ACShowCartVC: UIViewController {
    
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var cartTableView: UITableView!
    
    //slideup
    enum FormState {
        case expanded
        case collapsed
    }
    var formViewController: ACCartItem = ACCartItem()
    var formVisible: Bool = false
    var nextState:FormState {
        return formVisible ? .collapsed : .expanded
    }
    var animationArray = [UIViewPropertyAnimator]()
    var visualEffectView : UIVisualEffectView!
    var animationCompleted:CGFloat = 0
   
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
    }
    

    @IBAction func reviewOrderBtnPressed(_ sender: UIButton) {
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    private func setupTableView() {
        cartTableView.register(CartItemTableViewCell.nib(), forCellReuseIdentifier: CartItemTableViewCell.identifier)
    }
    
    private func loadSlideUpView() {
        self.view.alpha = 0.5
        formViewController.frame = CGRect(x: 0, y: view.frame.height - 80, width: view.frame.width, height: 80)
        formViewController.backgroundColor = .white
               //formViewController.view.clipsToBounds = true
        view.addSubview(formViewController)
        animationNeeded(state: nextState, duration: 0.9)
    }

}

extension ACShowCartVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CartItemTableViewCell.identifier, for: indexPath) as! CartItemTableViewCell
        cell.setup(id: indexPath.row + 1)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        loadSlideUpView()
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        print(indexPath.row)
        print(cartTableView.contentSize.height)
        tableViewHeight.constant = cartTableView.contentSize.height 
    }
}

extension ACShowCartVC  {
    private func animationNeeded(state: FormState, duration: TimeInterval) {
        if animationArray.isEmpty {
            let frameAnimator = UIViewPropertyAnimator(duration: duration, dampingRatio: 1) {
                switch state {
                case .expanded:
                    self.formViewController.frame.origin.y = self.view.frame.height - 400
                case .collapsed:
                    self.formViewController.frame.origin.y = self.view.frame.height - 80
                }
            }
            frameAnimator.addCompletion { (_) in
                self.formVisible = !self.formVisible
                self.animationArray.removeAll()
            }
            frameAnimator.startAnimation()
            animationArray.append(frameAnimator)
            
            let blurAnimator = UIViewPropertyAnimator(duration: duration, dampingRatio: 1) {
                switch state {
                case .expanded:
                    self.visualEffectView.effect = UIBlurEffect(style: .dark)
                case .collapsed:
                    self.visualEffectView.effect = nil
                }
            }
            blurAnimator.startAnimation()
            animationArray.append(blurAnimator)
        }
    }
    
    private func startAnimation(state: FormState, duration: TimeInterval) {
        if animationArray.isEmpty {
            animationNeeded(state: state, duration: duration)
        }
        for animator in animationArray {
            animator.pauseAnimation()
            animationCompleted = animator.fractionComplete
        }
    }
    
    private func updateTransition(fractionCompleted: CGFloat) {
        for animator in animationArray {
            animator.fractionComplete = fractionCompleted + animationCompleted
        }
    }
    
    private func continuTransition() {
        for animator in animationArray {
            animator.continueAnimation(withTimingParameters: nil, durationFactor: 0)
        }
    }
}
