//
//  ACCardDetailVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import UIKit

class ACCardDetailVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func processPaymentBtnPressed(_ sender: UIButton) {
        let aVC = ACProgressViewVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func backBtnPressed(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    

}
