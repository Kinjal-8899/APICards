//
//  ACPaymentOptionVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import UIKit



class ACPaymentOptionVC: UIViewController {

   
    @IBOutlet weak var tableView: UITableView!
    var jobModel : JobDataNewModel?
    var paymentViewModel = PaymentViewModel()
    var summaryData : CompanyPaymentData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        initialSetup()
    }
    
    @IBAction func backBtnPressed(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    private func setupTableView() {
        tableView.register(PaymentDetailTableViewCell.nib(), forCellReuseIdentifier: PaymentDetailTableViewCell.identifier)
        
        tableView.register(PaymentOptionTableViewCell.nib(), forCellReuseIdentifier: PaymentOptionTableViewCell.identifier)
    }
    

}
extension ACPaymentOptionVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: PaymentDetailTableViewCell.identifier, for: indexPath) as! PaymentDetailTableViewCell
            cell.lblBillAmount.text = "$\(summaryData?.total_paid_amount ?? 0.0)"
            cell.lblCompanyName.text = summaryData?.companyName
       //     cell.lblInvoiceNo.text = summaryData?.invoiceNo
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: PaymentOptionTableViewCell.identifier, for: indexPath) as! PaymentOptionTableViewCell
            cell.paymentModeClicked = { paymentMode in
                
                if paymentMode == PaymentType.cash {
                    self.makePayment(paymentType: paymentMode)
                }
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 1 {
            return 350.0
        }
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    
}

extension ACPaymentOptionVC {
    
    func initialSetup() {
        paymentViewModel.delegate = self
    }
    
    func makePayment(paymentType: String) {
        self.showActivityIndicator()
        guard let jobModel = jobModel else { return }
 
        let params: Dictionary<String,Any> = [ "job_id" : jobModel.job?.id ?? 0,
                                               "company_id": jobModel.job?.companyID ?? 0,
                                               "total_amount": summaryData?.total_amount ?? 0.0,
                                               "discount": summaryData?.discount ?? 0.0,
                                               "total_paid_amount": summaryData?.total_paid_amount ?? 0.0,
                                               "tips": summaryData?.tips ?? 0.0,
                                               "tax": summaryData?.tax ?? 0.0,
                                               "note": summaryData?.note ?? "",
                                               "transaction_id": "",
                                               "card_type": "",
                                               "card_holder_name": "",
                                               "card_number": "",
                                               "payment_type": paymentType
                                                ]
        paymentViewModel.makePayment(params: params)
        
    }
}

extension ACPaymentOptionVC : PaymentViewModelDelegate {
    func didReceiveResponse(response: PaymentModel?) {
        self.hideActivityIndicator()
        if response?.data != nil {
            openAlert(title: ACAlertTitle.success, message: ACAlertMessage.paymentSuccess, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{_ in
                let aVC = ACJobHomeVC.instantiate()
                self.navigationController?.pushViewController(aVC, animated: true)
            }])
        } else {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                self.navigationController?.popViewController(animated: true)
            }])
        }
    }
    
    
}
