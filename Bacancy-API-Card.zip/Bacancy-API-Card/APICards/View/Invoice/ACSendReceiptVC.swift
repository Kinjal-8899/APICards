//
//  ACSendReceiptVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import UIKit

class ACSendReceiptVC: UIViewController {

   
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    @IBAction func sendOnMailPressed(_ sender: UIButton) {
        let aVC = ACAllSetVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
}

