//
//  PaymentOptionCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import UIKit

class PaymentOptionCell: UICollectionViewCell {
    
    @IBOutlet weak var roundView: RoundView!
    @IBOutlet weak var paymentLbl: UILabel!
    @IBOutlet weak var paymentImageView: UIImageView!
    static let identifier = "PaymentOptionCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setup(image: UIImage, name: String) {
        if name != "Card Reader" {
            roundView.backgroundColor = .white
            paymentLbl.alpha = 1
        }
        paymentLbl.alpha = 0.8
        paymentImageView.image = image
        paymentLbl.text = name
        
    }

}
