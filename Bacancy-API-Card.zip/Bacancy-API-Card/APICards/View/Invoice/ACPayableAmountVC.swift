//
//  ACPayableAmountVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 11/04/22.
//

import UIKit

class ACPayableAmountVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func backBtnPressed(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
