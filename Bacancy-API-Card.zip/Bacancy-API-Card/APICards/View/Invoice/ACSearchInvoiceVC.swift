//
//  ACSearchInvoiceVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import UIKit

class ACSearchInvoiceVC: UIViewController {

    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var refIdTxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func searchBtnPressed(_ sender: UIButton) {
        let aVC = ACPaymentOptionVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func menuBtnPressed(_ sender: UIBarButtonItem) {
        let aVC = ACMenuVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    
    
}
