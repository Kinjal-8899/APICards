//
//  SendReceiptTableViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import UIKit

class SendReceiptTableViewCell: UITableViewCell {

    static let identifier = "SendReceiptTableViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
