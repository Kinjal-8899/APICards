//
//  ACProgressViewVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 08/04/22.
//

import UIKit

class ACProgressViewVC: UIViewController {
    
    @IBOutlet weak var lbl: UILabel!
    var circularProgressBarView: CircularProgressBarView!
    var circularViewDuration: TimeInterval = 5
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpCircularProgressBarView()
    }
    
    func setUpCircularProgressBarView() {
        // set view
        circularProgressBarView = CircularProgressBarView(frame: .zero)
        // align to the center of the screen
        circularProgressBarView.center = view.center
        // call the animation with circularViewDuration
        circularProgressBarView.progressAnimation(duration: circularViewDuration) {
            result in
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(self.circularViewDuration)) {
                if result {
                    let aVC = ACSendReceiptVC.instantiate()
                    self.navigationController?.pushViewController(aVC, animated: true)
                }
            }
        }
        // add this view to the view controller
        view.addSubview(circularProgressBarView)
    }
}
