//
//  PaymentDetailTableViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import UIKit

class PaymentDetailTableViewCell: UITableViewCell {

    @IBOutlet weak var lblBillAmount: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblInvoiceNo: UILabel!
    static let identifier = "PaymentDetailTableViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
