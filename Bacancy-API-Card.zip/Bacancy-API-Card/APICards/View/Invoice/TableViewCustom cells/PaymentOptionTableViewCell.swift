//
//  PaymentOptionTableViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import UIKit

struct PaymentMode {
    var image: UIImage?
    var name: String?
}

typealias btnClicked = ((String) -> Void)?

class PaymentOptionTableViewCell: UITableViewCell {
    
    @IBOutlet weak var collectionView: UICollectionView!
    var paymentModeClicked : btnClicked?
    
    let paymentModeArray: [PaymentMode] = [
        PaymentMode(image: UIImage(systemName: "creditcard"), name: "Card Reader"),
        PaymentMode(image: UIImage(named: "ic_menual_card"), name: "Manual Card"),
        PaymentMode(image: UIImage(named: "ic_card"), name: PaymentType.cash),
        PaymentMode(image: UIImage(named: "ic_apple_pay"), name: "Apple Pay"),
        PaymentMode(image: UIImage(named: "ic_google_pay"), name: "Google Pay")
    ]
    
    static let identifier = "PaymentOptionTableViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectionView.collectionViewLayout = UICollectionViewFlowLayout()
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(PaymentOptionCell.nib(), forCellWithReuseIdentifier: PaymentOptionCell.identifier)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}

extension PaymentOptionTableViewCell: UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return paymentModeArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PaymentOptionCell.identifier, for: indexPath) as! PaymentOptionCell
        cell.setup(image: paymentModeArray[indexPath.row].image!, name: paymentModeArray[indexPath.row].name!)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width / 4
                      ,height: collectionView.frame.size.height / 2
        )
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let paymentmodeClicked = paymentModeClicked {
            paymentmodeClicked!(paymentModeArray[indexPath.row].name!)
        }
    }
}
