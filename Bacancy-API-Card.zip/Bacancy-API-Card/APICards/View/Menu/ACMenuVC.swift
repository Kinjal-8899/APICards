//
//  ACMenuVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 14/04/22.
//

import UIKit

struct Menu {
    var image: UIImage
    var label: String
}

class ACMenuVC: UIViewController {

    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var menuTableView: UITableView!
    
    var logoutViewModel: LogoutViewModel!
    
    let menuArray : [Menu] = [ Menu(image: UIImage(named: "ic_transactions")!, label: "Transactions"),
                               Menu(image: UIImage(named: "ic_invoice")!, label: "Invoice"),
                               Menu(image: UIImage(named: "ic_report")!, label: "Reports"),
                               Menu(image: UIImage(named: "ic_settings")!, label: "Settings"),
                               Menu(image: UIImage(named: "ic_help")!, label: "Help"),
                               Menu(image: UIImage(named: "ic_user")!, label: "Sign Out")
                              ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        menuTableView.register(MenuTableViewCell.nib(), forCellReuseIdentifier: MenuTableViewCell.identifier)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    @IBAction func menuBtnPressed(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func signOut() {
        let email = UserDefaultHelper.userEmail
        if email == nil {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.notLoggedIn, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        } else {
            openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.logout, alertStyle: .alert, actionTitles: [ACAlertTitle.yes, ACAlertTitle.no], actionStyles: [.default,.destructive], actions: [{ _ in
                self.logoutViewModel = LogoutViewModel()
                self.logoutViewModel.delegate = self
                self.showActivityIndicator()
                self.logoutViewModel.logoutUser(email: email!)
            }, nil])
        }
    }
   
}

//MARK: - ACMenuVC with LogoutViewModelDelegate
extension ACMenuVC: LogoutViewModelDelegate {
    func didReceiveLogoutResponse(logoutResponse: LogoutModel?) {
        self.hideActivityIndicator()
        UserDefaultHelper.userEmail = nil
        UserDefaultHelper.authToken = nil
        UserDefaultHelper.isUserLoggedIn = false
        UserDefaultHelper.userData = nil
        let aVC = ACSignInVC.instantiate()
       // aVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(aVC, animated: true)
    }
}

//MARK: - ACMenuVC with UITableViewDelegate, UITableViewDataSource
extension ACMenuVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MenuTableViewCell.identifier, for: indexPath) as! MenuTableViewCell
        let menu: Menu = menuArray[indexPath.row]
        cell.setup(image: menu.image, text: menu.label)
        cell.selectionStyle = .none
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 45
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        tableViewHeight.constant = tableView.contentSize.height
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let menu: Menu = menuArray[indexPath.row]
        switch menu.label {
        case "Transactions":
            let aVC = ACTransactionVC.instantiate()
            self.navigationController?.pushViewController(aVC, animated: true)
        case "Invoice":
            let aVC = ACSearchInvoiceVC.instantiate()
            self.navigationController?.pushViewController(aVC, animated: true)
        case "Sign Out":
            self.signOut()
        case "Reports": break
        case "Settings": break
        case "Help": break
        default:
            break
        }
    }
}
