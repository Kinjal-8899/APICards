//
//  MenuTableViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 14/04/22.
//

import UIKit

class MenuTableViewCell: UITableViewCell {

    @IBOutlet weak var menuLabel: UILabel!
    @IBOutlet weak var menuImageView: UIImageView!
    static let identifier = "MenuTableViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    //MARK: - setup cell data
    func setup(image: UIImage, text: String) {
        menuLabel.text = text
        menuImageView.image = image
    }
    
}
