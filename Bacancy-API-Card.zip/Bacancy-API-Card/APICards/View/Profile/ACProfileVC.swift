//
//  ACProfileVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 28/06/22.
//

import UIKit

class ACProfileVC: UIViewController {

    //MARK: - IBOutlets
    @IBOutlet weak var txtEmaill: UITextField!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var phoneView: UIView!
    @IBOutlet weak var nameView: UIView!
    
    //MARK: - Variables
    var profileViewModel = ProfileViewModel()
    var userData: LoginResponseData?
    var logoutViewModel: LogoutViewModel!
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGesture = UITapGestureRecognizer(target: self,
                                                action: #selector(hideKeyboard))
        txtName.addTarget(self, action: #selector(self.textFieldDidChange(_:)),
                                  for: .editingChanged)
        view.addGestureRecognizer(tapGesture)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    //MARK: - Btn Click events
    @IBAction func backBtnPressed(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func myReportsBtnPressed(_ sender: UIButton) {
        let aVC = ACMyReportsVC.instantiate(storyboard: "Home")
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func appPermissionBtnPressed(_ sender: UIButton) {
        let aVC = ACPermissionVC.instantiate(storyboard: "Main")
        aVC.userData = self.userData
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    @IBAction func saveBtnPressed(_ sender: UIButton) {
    }
    
    @IBAction func logoutBtnPressed(_ sender: UIButton) {
        let email = userData?.email
        if email == nil {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.notLoggedIn, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        } else {
            openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.logout, alertStyle: .alert, actionTitles: [ACAlertTitle.yes, ACAlertTitle.no], actionStyles: [.default,.destructive], actions: [{ _ in
                self.logoutViewModel = LogoutViewModel()
                self.logoutViewModel.delegate = self
                self.showActivityIndicator()
                self.logoutViewModel.logoutUser(email: email!)
            }, nil])
        }
    }
    
}


//MARK: - ACProfileVC
extension ACProfileVC {
    func initialSetup() {
        CommonMethods.setBorderRadius(view: nameView, radius: 10, borderColor: AppColors.appBorderColor, borderWidth: 1)
        CommonMethods.setBorderRadius(view: phoneView, radius: 10, borderColor: AppColors.appBorderColor, borderWidth: 1)
        CommonMethods.setBorderRadius(view: emailView, radius: 10, borderColor: AppColors.appBorderColor, borderWidth: 1)
        saveBtn.isHidden = true
        profileViewModel.delegate = self
        getUserData()
        
    }
    
    
    func getUserData() {
        //self.showActivityIndicator()
        guard let userId = UserDefaultHelper.userId else { return }
        profileViewModel.getUserData(userId: userId)
    }
    
    func setUserData() {
        txtName.text = userData?.fullname
        userName.text = userData?.fullname
        txtPhone.text = userData?.mobile
        txtEmaill.text = userData?.email
//        if userData?.profilePic == "" {
//            profileImageView.image = UIImage(named: "defaultPerson")
//        }
//        else {
//            let url : URL = URL(string: "\(APIUrls.imageBaseURL)\(userData?.profilePic ?? "")")!
//            profileImageView.sd_setImage(with: url)
//        }
    }
    
}
//MARK: - ACProfileVC
extension ACProfileVC {
   
    @objc func textFieldDidChange(_ textField: UITextField) {
        if textField.text != UserDefaultHelper.userName {
            saveBtn.isHidden = false
        } else {
            saveBtn.isHidden = true
        }
    }
    
    @objc func hideKeyboard() {
        view.endEditing(true)
    }
}

//MARK: - ACProfileVC with ProfileViewModelDelegate
extension ACProfileVC: ProfileViewModelDelegate {
    func didReceiveUserData(response: LoginResponse?) {
        self.hideActivityIndicator()
        if response?.data != nil {
            DispatchQueue.main.async {
                self.userData = response?.data
                self.setUserData()
            }
        } else {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        }
    }
}

//MARK: - ACProfileVC with LogoutViewModelDelegate
extension ACProfileVC: LogoutViewModelDelegate {
    func didReceiveLogoutResponse(logoutResponse: LogoutModel?) {
        self.hideActivityIndicator()
        UserDefaultHelper.authToken = nil
        UserDefaultHelper.isUserLoggedIn = false
        let aVC = ACSignInVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
}
