//
//  ACReportsTVCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 28/06/22.
//

import UIKit

class ACReportsTVCell: UITableViewCell {

    @IBOutlet weak var lineView: UIView!
    @IBOutlet weak var lblTotalMoney: UILabel!
    @IBOutlet weak var lblNoOfJobs: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    static let identifier = "ACReportsTVCell"
    
    var reportModel: ReportsData?
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setup() {
        lblDate.text = reportModel?.date.changeDateFormat(fromFormat: .YYYY_MM_DD, toFormat: .d_MMM_YYYY)
        lblNoOfJobs.text = "\(reportModel?.jobsCount ?? 0)"
        let amount = "\(Float(reportModel?.totalPayment ?? 0).round(to: 2))"
        lblTotalMoney.text = "$\(amount)"
    }
    
}
