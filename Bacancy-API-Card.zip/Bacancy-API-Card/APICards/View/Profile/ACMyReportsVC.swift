//
//  ACMyReportsVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 28/06/22.
//

import UIKit

class ACMyReportsVC: UIViewController {

    //MARK: - IBOutlets
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var reportsTableView: UITableView!
    @IBOutlet weak var filterBtn: UIButton!
    
    //MARK: - Variables
    var filterVC: ACFilterDateVC!
    var bgView: UIView!
    var isFilterApplied: Bool = false
    var profileViewModel = ProfileViewModel()
    var reportArray = [ReportsData]()
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    //MARK: - Btn click events
    @IBAction func backBtnPressed(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func filterBtnPressed(_ sender: UIButton) {
        setupSwipeUpView()
    }
}

//MARK: - ACMyReportsVC
extension ACMyReportsVC {
    
    func initialSetup() {
        reportsTableView.register(ACReportsTVCell.nib(), forCellReuseIdentifier: ACReportsTVCell.identifier)
        reportsTableView.register(ACNoDataTableViewCell.nib(), forCellReuseIdentifier: ACNoDataTableViewCell.identifier)
        profileViewModel.delegate = self
        self.showActivityIndicator()
        reportsTableView.isHidden = true
        profileViewModel.getReportlist()
    }
    
    private func setupSwipeUpView() {
        
        bgView = UIView()
        bgView.frame = view.frame
        bgView.backgroundColor = .black
        bgView.alpha = 0.5
        let tap = UITapGestureRecognizer(target: self, action: #selector(bgViewTapped(_:)))
        bgView.addGestureRecognizer(tap)
        view.addSubview(bgView)
        
        self.filterVC = ACFilterDateVC(nibName: "ACFilterDateVC", bundle: nil)
        self.filterVC.view.frame = CGRect(x: 0, y: self.view.frame.height - (self.filterVC.containerView.frame.height + 80), width: self.view.frame.width, height: self.filterVC.containerView.frame.height + 80)
        self.filterVC.delegate = self
        
        self.addChild(self.filterVC)
        self.view.addSubview(self.filterVC.view)
    }
    
    @objc func bgViewTapped(_ sender: UITapGestureRecognizer) {
        closeSlideupView()
    }
    
    private func closeSlideupView() {
        self.filterVC.view.removeFromSuperview()
        self.filterVC.removeFromParent()
        self.bgView.removeFromSuperview()
        
    }
    
}

//MARK: - ACMyReportsVC with FilterDateDelegate
extension ACMyReportsVC: FilterDateDelegate {
    func applyClicked(from: String, to: String) {
        print(from)
        print(to)
        self.isFilterApplied = true
        self.closeSlideupView()
        self.showActivityIndicator()
        
        self.reportsTableView.isHidden = true
        self.showActivityIndicator()
        profileViewModel.getReportlistBetweenDates(startDate: from, endDate: to)
       
        DispatchQueue.main.async {
            self.filterBtn.setImage(UIImage(named: "Filter2"), for: .normal)
        }
    }
    
    
}

//MARK: - ACMyReportsVC with ProfileViewModelDelegate
extension ACMyReportsVC: ProfileViewModelDelegate {
    func didReceiveReportsList(response: ReportsModel?) {
        reportArray.removeAll()
        self.hideActivityIndicator()
        if response?.data != nil {
            DispatchQueue.main.async {
                self.reportArray = response?.data ?? [ReportsData]()
                self.reportsTableView.isHidden = false
                self.reportsTableView.reloadData()
            }
        } else {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        }
    }
}

//MARK: - ACMyReportsVC with UITableViewDelegate, UITableViewDataSource
extension ACMyReportsVC: UITableViewDelegate, UITableViewDataSource {
   
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reportArray.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: ACReportsTVCell.identifier, for: indexPath) as! ACReportsTVCell
        cell.selectionStyle = .none
        cell.reportModel = reportArray[indexPath.row]
        cell.setup()
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        tableViewHeight.constant = tableView.contentSize.height
    }
}

