//
//  ACPermissionVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 01/07/22.
//

import UIKit

class ACPermissionVC: UIViewController {

    //MARK: - IBOutlets
    @IBOutlet weak var switchNotification: UISwitch!
    @IBOutlet weak var switchlocation: UISwitch!
    @IBOutlet weak var switchbluetooth: UISwitch!
    
    //MARK: - Variables
    var profileViewModel = ProfileViewModel()
    var userData: LoginResponseData?
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        profileViewModel.delegate = self
    }
    
    //MARK: - Btn click events
    @IBAction func doneBtnPressed(_ sender: UIButton) {
        guard let uid = UserDefaultHelper.userId else {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
            return
        }
        
        let dict: Dictionary<String, Any> = [ "user_id": uid,
                                              "notification": switchNotification.isOn,
                                              "location": switchlocation.isOn,
                                              "bluetooth": switchbluetooth.isOn
                                            ]
        print(dict)
        self.showActivityIndicator()
        profileViewModel.setAppPermissions(params: dict)
    }
    
    @IBAction func backBtnPressed(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func notificationSwitch(_ sender: UISwitch) {
    }
    
    @IBAction func locationSwitch(_ sender: UISwitch) {
    }
    
    @IBAction func bluetoothSwitch(_ sender: UISwitch) {
    }
}

//MARK: - ACPermissionVC
extension ACPermissionVC {
    
    func initialSetup() {
        if userData?.bluetooth ?? true {
            switchbluetooth.isOn = true
        } else {
            switchbluetooth.isOn = false
        }
        
        if userData?.notification ?? true {
            switchNotification.isOn = true
        } else {
            switchNotification.isOn = false
        }
        
        if userData?.location ?? true {
            switchlocation.isOn = true
        } else {
            switchlocation.isOn = false
        }
    }
    
}

//MARK: - ACPermissionVC with ProfileViewModelDelegate
extension ACPermissionVC: ProfileViewModelDelegate {
    func didReceiveUserData(response: LoginResponse?) {
        self.hideActivityIndicator()
        if response?.data != nil {
            openAlert(title: ACAlertTitle.success, message: "App Permissions are updated", alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{_ in
                self.navigationController?.popViewController(animated: true)
            }])
        } else {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        }
    }
}
