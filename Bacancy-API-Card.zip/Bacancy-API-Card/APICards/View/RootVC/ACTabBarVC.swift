//
//  ACTabBarVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 06/04/22.
//

import UIKit

class ACTabBarVC2: UITabBarController {
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()      
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
}
