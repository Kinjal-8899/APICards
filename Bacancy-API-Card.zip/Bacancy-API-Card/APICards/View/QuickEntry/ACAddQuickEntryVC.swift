//
//  ACAddQuickEntryVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 08/04/22.
//

import UIKit

class ACAddQuickEntryVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    @IBAction func menuBtnPressed(_ sender: UIBarButtonItem) {
    }
    
    @IBAction func deleteBtnPressed(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
