//
//  ACHomeVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 05/04/22.
//

import UIKit

class ACHomeVC: UIViewController {
    
    @IBOutlet weak var lblNoOfTransaction: UILabel!
    @IBOutlet weak var lblTransaction: UILabel!
    @IBOutlet weak var lblAddedDate: UILabel!
    @IBOutlet weak var lblGrossMoney: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblMoney: UILabel!
    
    var jobViewModel = JobViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblEmail.text = UserDefaultHelper.userEmail
        guard let name = UserDefaultHelper.userName else { return }
        self.navigationItem.title = "Welcome " + name
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    @IBAction func addBtnPressed(_ sender: UIBarButtonItem) {
        let aVC = ACAddQuickEntryVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func menuBtnPressed(_ sender: UIBarButtonItem) {
        let aVC = ACMenuVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    
    @IBAction func scoreOtherBtnPressed(_ sender: UIButton) {
        let aVC = ACChooseDateVC.instantiate()
        aVC.delegate = self
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    
    @IBAction func transactionOtherBtnPressed(_ sender: UIButton) {
        let aVC = ACChooseDateVC.instantiate()
        aVC.delegate = self
        self.navigationController?.pushViewController(aVC, animated: true)
    }
}

//MARK: - ACHomeVC
extension ACHomeVC {
    func initialSetup() {
        self.showActivityIndicator()
        jobViewModel.delegate = self
        jobViewModel.getTodaysJobData()
    }
}

//MARK: - ACHomeVC with ChooseDateDelegate
extension ACHomeVC: ChooseDateDelegate {
    func todayDateChose() {
        lblGrossMoney.text = "Today's Gross Money In"
        lblTransaction.text = "Today's Remaining Assigned Jobs"
        self.showActivityIndicator()
        jobViewModel.getTodaysJobData()
    }
    
    func dateChosen(startDate: String, endDate: String) {
        lblGrossMoney.text = "Gross money between \(startDate) and \(endDate)"
        lblTransaction.text = "Jobs between \(startDate) and \(endDate)"
        self.showActivityIndicator()
        jobViewModel.getBetweenDatesJobData(startDate: startDate, endDate: endDate)
    }
}

//MARK: - ACHomeVC With JobViewModelDelegate
extension ACHomeVC: JobViewModelDelegate {
    func didReceiveTodayJobs(response: TodayJobModel?) {
        self.hideActivityIndicator()
        if response?.data == nil {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        } else {
            //lblNoOfTransaction.text = "\(response?.data?.totalJobs ?? 0)"
          //  lblMoney.text = "$" + (response?.data!.totalPayment)!
        }
    }
}
