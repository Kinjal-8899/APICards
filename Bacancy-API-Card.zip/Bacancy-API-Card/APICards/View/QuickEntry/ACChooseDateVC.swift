//
//  ACChooseDateVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 21/04/22.
//

import UIKit
import ActionSheetPicker_3_0

protocol ChooseDateDelegate {
    func dateChosen(startDate: String, endDate: String)
    func todayDateChose()
}

class ACChooseDateVC: UIViewController {

    @IBOutlet weak var txtEndDate: UITextField!
    @IBOutlet weak var txtStartDate: UITextField!
    
    var delegate: ChooseDateDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK: - start Date Btn Pressed
    @IBAction func startDateBtnPressed(_ sender: UIButton) {
        ActionSheetDatePicker.show(withTitle: "Date",
                                   datePickerMode: .date,
                                   selectedDate: Date(),
                                   minimumDate: nil,
                                   maximumDate: Date.getCurrentDate(),
                                   doneBlock: { picker, date, origin in
            
            if let aDate = date as? Date
            {
                self.txtStartDate.text = aDate.toString(formateType: .dd_MM_yyyy)
            }
            return
        }, cancel: { (sender) in
            return
        }, origin: sender)
    }
    
    //MARK: - end Date Btn Pressed
    @IBAction func endDateBtnPressed(_ sender: UIButton) {
        ActionSheetDatePicker.show(withTitle: "Date",
                                   datePickerMode: .date,
                                   selectedDate: Date(),
                                   minimumDate: nil,
                                   maximumDate: Date.getCurrentDate(),
                                   doneBlock: { picker, date, origin in
            
            if let aDate = date as? Date
            {
                self.txtEndDate.text = aDate.toString(formateType: .dd_MM_yyyy)
            }
            
            return
        }, cancel: { (sender) in
            return
        }, origin: sender)
    }
    
    //MARK: - check Btn Pressed
    @IBAction func checkBtnPressed(_ sender: UIButton) {
        guard let startDate = txtStartDate.text, !startDate.isEmpty else {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.chooseStartDate, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
            return
        }
        guard let endDate = txtEndDate.text, !endDate.isEmpty else {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.chooseEndDate, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
            return
        }
        delegate?.dateChosen(startDate: startDate, endDate: endDate)
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK: - check Today Btn Pressed
    @IBAction func checkTodayBtnPressed(_ sender: UIButton) {
        delegate?.todayDateChose()
        self.navigationController?.popViewController(animated: true)
    }
    
}
