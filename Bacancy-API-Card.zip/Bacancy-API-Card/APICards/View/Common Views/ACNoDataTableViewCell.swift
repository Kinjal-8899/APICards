//
//  ACNoDataTableViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 05/05/22.
//

import UIKit

class ACNoDataTableViewCell: UITableViewCell {

    @IBOutlet weak var lblNoData: UILabel!
    
    static let identifier = "ACNoDataTableViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
