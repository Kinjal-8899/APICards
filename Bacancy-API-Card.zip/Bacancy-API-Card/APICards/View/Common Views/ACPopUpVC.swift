//
//  ACPopUpVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 29/06/22.
//

import UIKit

class ACPopUpVC: UIViewController {
    
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    //MARK: - Btn Click Events
    @IBAction func okBtnClicked(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
