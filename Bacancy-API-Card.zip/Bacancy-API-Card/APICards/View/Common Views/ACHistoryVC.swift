//
//  ACHistoryVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 25/05/22.
//

import UIKit
import ActionSheetPicker_3_0

protocol ACChooseDateDelegate {
    func dateChosen(startDate: String, endDate: String)
    func viewHistory()
}

class ACHistoryVC: UIViewController {

    @IBOutlet weak var txtEndDate: UITextField!
    @IBOutlet weak var txtStartDate: UITextField!
    @IBOutlet weak var mainView: CardView!
    
    var delegate: ACChooseDateDelegate?
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        mainView.addBorders(edges: [.left,.right,.bottom], color: AppColors.appOrangeColor, width: 2)
        self.view.addBorders(edges: [.left,.right,.bottom], color: AppColors.appOrangeColor, width: 2)
        
    }

    //MARK: - Btn click events
    @IBAction func startDateBtnPressed(_ sender: UIButton) {
        ActionSheetDatePicker.show(withTitle: "Date",
                                   datePickerMode: .date,
                                   selectedDate: Date(),
                                   minimumDate: nil,
                                   maximumDate: Date.getCurrentDate(),
                                   doneBlock: { picker, date, origin in
            
            if let aDate = date as? Date
            {
                self.txtStartDate.text = aDate.toString(formateType: .dd_MM_yyyy)
            }
            return
        }, cancel: { (sender) in
            return
        }, origin: sender)
    }
    
    @IBAction func endDateBtnPressed(_ sender: UIButton) {
        ActionSheetDatePicker.show(withTitle: "Date",
                                   datePickerMode: .date,
                                   selectedDate: Date(),
                                   minimumDate: nil,
                                   maximumDate: Date.getCurrentDate(),
                                   doneBlock: { picker, date, origin in
            
            if let aDate = date as? Date
            {
                self.txtEndDate.text = aDate.toString(formateType: .dd_MM_yyyy)
            }
            
            return
        }, cancel: { (sender) in
            return
        }, origin: sender)
    }
    
    @IBAction func checkBtnPressed(_ sender: UIButton) {
        guard let startDate = txtStartDate.text, !startDate.isEmpty else {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.chooseStartDate, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
            return
        }
        guard let endDate = txtEndDate.text, !endDate.isEmpty else {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.chooseEndDate, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
            return
        }
        delegate?.dateChosen(startDate: startDate, endDate: endDate)
    }
    
    @IBAction func fullHistoryBtnPressed(_ sender: UIButton) {
        delegate?.viewHistory()
    }
}
