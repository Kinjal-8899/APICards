//
//  ACMaunualCardVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 27/06/22.
//

import UIKit
import ActionSheetPicker_3_0

struct ManualCardData {
    var cardHolderName, cardNumber, expiryDate : String?
    var cvv: Int?
}

protocol ManualCardVCDelegate {
    func closeBtnClicked(isClicked: Bool)
    func payBtnClicked(cardData: ManualCardData)
}


class ACMaunualCardVC: UIViewController {
    
    //MARK: - IBOutlets
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var lblTotalAmount: UILabel!
    @IBOutlet weak var txtCVV: UITextField!
    @IBOutlet weak var txtExpiryDate: UITextField!
    @IBOutlet weak var txtCardNumber: UITextField!
    @IBOutlet weak var txtcardHolderName: UITextField!
    @IBOutlet weak var cvvView: UIView!
    @IBOutlet weak var expiryDateView: UIView!
    @IBOutlet weak var cardNumberView: UIView!
    @IBOutlet weak var cardHolderNameView: UIView!
    
    //MARK: - Variables
    var delegate: ManualCardVCDelegate?
    var customPicker = UIPickerView()
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        
    }

    //MARK: - Btn click events
    @IBAction func closeBtnPressed(_ sender: UIButton) {
        delegate?.closeBtnClicked(isClicked: true)
    }
    
    @IBAction func payNowBtnPressed(_ sender: UIButton) {
        guard let name = txtcardHolderName.text else { return }
        guard let number = txtCardNumber.text else { return }
        guard let edate = txtExpiryDate.text else { return }
        guard let cvv = txtCVV.text else { return }
        
        delegate?.payBtnClicked(cardData: ManualCardData(cardHolderName: name, cardNumber: number, expiryDate: edate, cvv: Int(cvv)))
        
    }
    
    @IBAction func expiryDatePressed(_ sender: UIButton) {
        customPicker.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 200)
//        ActionSheetDatePicker.show(withTitle: "Date",
//                                   datePickerMode: .date,
//                                   selectedDate: Date(),
//                                   minimumDate: Date.getCurrentDate(),
//                                   maximumDate: nil,
//                                   doneBlock: { picker, date, origin in
//
//            if let aDate = date as? Date
//            {
//                self.txtExpiryDate.text = aDate.toString(formateType: .dd_MM_yyyy)
//            }
//            return
//        }, cancel: { (sender) in
//            return
//        }, origin: sender)
    }
    
    //MARK: - Other methods
    private func initialSetup() {
        CommonMethods.setBorderRadius(view: cvvView, radius: 14, borderColor: AppColors.appBorderColor, borderWidth: 1)
        CommonMethods.setBorderRadius(view: expiryDateView, radius: 14, borderColor: AppColors.appBorderColor, borderWidth: 1)
        CommonMethods.setBorderRadius(view: cardNumberView, radius: 14, borderColor: AppColors.appBorderColor, borderWidth: 1)
        CommonMethods.setBorderRadius(view: cardHolderNameView, radius: 14, borderColor: AppColors.appBorderColor, borderWidth: 1)
        customPicker.dataSource = self
        customPicker.delegate = self
    }

   

}

extension ACMaunualCardVC: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return "Test"
    }
}
extension ACMaunualCardVC: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 10
    }
    
    
}
