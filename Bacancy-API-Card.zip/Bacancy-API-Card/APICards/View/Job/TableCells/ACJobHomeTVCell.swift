//
//  ACJobHomeTVCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 21/06/22.
//

import UIKit

class ACJobHomeTVCell: UITableViewCell {
    
    static let identifier = "ACJobHomeTVCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    @IBOutlet weak var lblJobTiming: UILabel!
    @IBOutlet weak var lblJobAmount: UILabel!
    @IBOutlet weak var lblJobDesc: UILabel!
    @IBOutlet weak var lblJobTitle: UILabel!
    @IBOutlet weak var lblTiming: UILabel!
    @IBOutlet weak var lblJobStatus: UILabel!
    @IBOutlet weak var timeStackView: UIStackView!
    
    var jobData: JobData?
    var timer: Timer?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setup() {
        setFontColorAccordingToStatus()
        lblJobStatus.text = jobData?.status?.getNewJobStatus()
        if jobData?.status == JobStatus.inProgress {
            lblTiming.text = SingleTonTimer.sharedTimer.currenttimeStr
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimerLabel), userInfo: nil, repeats: true)
        } else if jobData?.status == JobStatus.inBreak {
            lblTiming.text = SingleTonTimer.sharedTimer.currenttimeStr
        } else if jobData?.status == JobStatus.completed {
            lblTiming.text = jobData?.jobFinishDatetime?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
        } else if jobData?.status == JobStatus.cancelled {
            lblTiming.text = jobData?.jobCancelledDatetime?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
        
        }
        else {
            lblTiming.text = jobData?.createdAt?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
         
        }
        lblJobTitle.text = jobData?.name
        lblJobDesc.text = jobData?.datumDescription
        
        let amount = "\(Float(jobData?.paymentDetails?.totalPaidAmount ?? 0).round(to: 2))"
        
        lblJobAmount.text = "$\(amount)/hr"
        
        lblJobTiming.text = jobData?.totalInTime
    }
    
    func setFontColorAccordingToStatus() {
        if jobData?.status == JobStatus.assigned {
            lblJobStatus.textColor = AppColors.appOrangeColor
            lblTiming.textColor = AppColors.appGreyColor
        } else if jobData?.status == JobStatus.completed {
            lblJobStatus.textColor = AppColors.appGreenColor
            lblTiming.textColor = AppColors.appGreyColor
        } else if jobData?.status == JobStatus.inProgress || jobData?.status == JobStatus.inBreak {
            lblJobStatus.textColor = AppColors.appGreenColor
            lblTiming.textColor = AppColors.appGreenColor
        } else if jobData?.status == JobStatus.cancelled {
            lblJobStatus.textColor = AppColors.appDarkPinkColor
            lblTiming.textColor = AppColors.appGreyColor
        }// inReview
        else {
            
        }
    }
    
    //MARK: - update Timer Label
    @objc func updateTimerLabel() {
        if jobData?.id == UserDefaultHelper.jobIdInProgresss {
            
            self.lblTiming.text = SingleTonTimer.sharedTimer.currenttimeStr
        }
    }
}
