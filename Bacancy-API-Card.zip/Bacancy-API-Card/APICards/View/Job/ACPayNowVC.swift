//
//  ACPayNowVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 27/06/22.
//

import UIKit

class ACPayNowVC: UIViewController {

    @IBOutlet weak var lblTotalAmount: UILabel!
    @IBOutlet weak var lblJobName: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var gpayBtn: UIButton!
    @IBOutlet weak var applePayBtn: UIButton!
    @IBOutlet weak var cardReaderBtn: UIButton!
    @IBOutlet weak var cashBtn: UIButton!
    @IBOutlet weak var manualCardBtn: UIButton!
    @IBOutlet weak var lblInvoice: UILabel!
    
    //MARK: - Variables
    var manualCardVC: ACMaunualCardVC!
    var bgView: UIView!
    var invoiceData: CompanyPaymentData?
    var paymentViewModel = PaymentViewModel()
    var selectedBtnTag : Int = 11
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    //MARK: - Btn click events
    @IBAction func radioBtnChecked(_ sender: UIButton) {
        self.selectedBtnTag = sender.tag
        if sender == cardReaderBtn {
            cardReaderBtn.setImage(UIImage(named: "Radio Button - Selected"), for: .normal)
            manualCardBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            cashBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            applePayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            gpayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
        } else if sender == manualCardBtn {
            manualCardBtn.setImage(UIImage(named: "Radio Button - Selected"), for: .normal)
            cardReaderBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            cashBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            applePayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            gpayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            setupSwipeUpView()
        } else if sender == cashBtn {
            cashBtn.setImage(UIImage(named: "Radio Button - Selected"), for: .normal)
            manualCardBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            cardReaderBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            applePayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            gpayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            
        } else if sender == applePayBtn {
            applePayBtn.setImage(UIImage(named: "Radio Button - Selected"), for: .normal)
            manualCardBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            cashBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            cardReaderBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            gpayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
        } else if sender == gpayBtn {
            gpayBtn.setImage(UIImage(named: "Radio Button - Selected"), for: .normal)
            manualCardBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            cashBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            applePayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
            cardReaderBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
        }
    }
    
    @IBAction func backBtnPressed(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func payNowBtnPressed(_ sender: UIButton) {
        var paymentType: String = PaymentType.card
        if selectedBtnTag == 22 {
            openAlert(title: ACAlertTitle.oops, message: "Currently, we are only receiving cash payment", alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
            //paymentType = PaymentType.manualCard
        } else if selectedBtnTag == 33  {
            paymentType = PaymentType.cash
        } else if selectedBtnTag == 44  {
            openAlert(title: ACAlertTitle.oops, message: "Currently, we are only receiving cash payment", alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
            //paymentType = PaymentType.applePay
        } else if selectedBtnTag == 55  {
            openAlert(title: ACAlertTitle.oops, message: "Currently, we are only receiving cash payment", alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
            //paymentType = PaymentType.gPay
        } else {
            openAlert(title: ACAlertTitle.oops, message: "Currently, we are only receiving cash payment", alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
            //paymentType = PaymentType.card
        }
        
        self.makePayment(paymentType: paymentType)
        
    }
}

//MARK: - ACPayNowVC
extension ACPayNowVC {
    
    func initialSetup() {
        paymentViewModel.delegate = self
        cardReaderBtn.setImage(UIImage(named: "Radio Button - Selected"), for: .normal)
        manualCardBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
        cashBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
        applePayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
        gpayBtn.setImage(UIImage(named: "Controls - Checkboxes - Radio Ok"), for: .normal)
        
        lblInvoice.text = "Payment"
        lblJobName.text = invoiceData?.jobName
        lblCompanyName.text = invoiceData?.companyName
        lblTotalAmount.text = "$\(invoiceData?.total_paid_amount ?? 0)"
    }
    
    private func setupSwipeUpView() {
        
        bgView = UIView()
        bgView.frame = view.frame
        bgView.backgroundColor = .black
        bgView.alpha = 0.5
        view.addSubview(bgView)
        
        self.manualCardVC = ACMaunualCardVC(nibName: "ACMaunualCardVC", bundle: nil)
        self.manualCardVC.view.frame = CGRect(x: 0, y: self.view.frame.height - (self.manualCardVC.containerView.frame.height + 80), width: self.view.frame.width, height: self.manualCardVC.containerView.frame.height + 80)
        self.manualCardVC.delegate = self
        
        self.addChild(self.manualCardVC)
        self.view.addSubview(self.manualCardVC.view)
    }
    
    private func closeSlideupView() {
        self.manualCardVC.view.removeFromSuperview()
        self.manualCardVC.removeFromParent()
        self.bgView.removeFromSuperview()
    }
    
}
//MARK: - ACPayNowVC with ManualCardVCDelegate
extension ACPayNowVC: ManualCardVCDelegate {
    func closeBtnClicked(isClicked: Bool) {
        self.closeSlideupView()
    }
    
    func payBtnClicked(cardData: ManualCardData) {
        print(cardData)
        self.closeSlideupView()
    }
    
    
}

//MARK: - ACPayNowVC
extension ACPayNowVC {
    
    func makePayment(paymentType: String) {
        self.showActivityIndicator()
        guard let invoiceData = invoiceData else { return }
 
        let params: Dictionary<String,Any> = [ "job_id" : invoiceData.jobId ?? 0,
                                               "company_id": invoiceData.companyID ?? 0,
                                               "total_amount": invoiceData.total_amount ?? 0.0,
                                               "discount": invoiceData.discount ?? 0.0,
                                               "total_paid_amount": invoiceData.total_paid_amount ?? 0.0,
                                               "tips": invoiceData.tips ?? 0.0,
                                               "tax": invoiceData.tax ?? 0.0,
                                               "note": invoiceData.note ?? "",
                                               "transaction_id": "",
                                               "card_type": "",
                                               "card_holder_name": "",
                                               "card_number": "",
                                               "payment_type": paymentType
                                                ]
        paymentViewModel.makePayment(params: params)
        
    }
}

//MARK: - ACPayNowVC with PaymentViewModelDelegate
extension ACPayNowVC : PaymentViewModelDelegate {
    func didReceiveResponse(response: PaymentModel?) {
        self.hideActivityIndicator()
        if response?.data != nil {
            openAlert(title: ACAlertTitle.success, message: ACAlertMessage.paymentSuccess, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{_ in
                
                let selectedIndexTab = self.tabBarController?.selectedIndex
                
                if selectedIndexTab == 0 {
                    let aVC = ACDashboardVC.instantiate(storyboard: "Home")
                    self.navigationController?.pushViewController(aVC, animated: true)
                } else {
                    let aVC = ACJobsVC.instantiate(storyboard: "Home")
                    self.navigationController?.pushViewController(aVC, animated: true)
                }
              
                
                
            }])
        } else {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                self.navigationController?.popViewController(animated: true)
            }])
        }
    }
    
    
}
