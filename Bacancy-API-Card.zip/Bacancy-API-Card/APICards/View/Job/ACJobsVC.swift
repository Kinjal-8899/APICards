//
//  ACJobsVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 21/06/22.
//

import UIKit

class ACJobsVC: UIViewController {
    
    @IBOutlet weak var jobTableView: UITableView!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    var selectedIndex: Int = 0
    var params: Dictionary<String,Any>?
    
    var jobArray: [JobData] = [JobData]()
    var jobViewModel = JobViewModel()
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    //MARK: - Btn click events
    @IBAction func filterSegmentChanged(_ sender: UISegmentedControl) {
        selectedIndex = sender.selectedSegmentIndex
        if sender.selectedSegmentIndex == 0 {
            getJobList()
        } else if sender.selectedSegmentIndex == 1 {
            getJobList()
        } else {
            getJobList()
        }
    }
}

//MARK: - ACJobsVC
extension ACJobsVC {
    
    //MARK: - initial Setup
    func initialSetup() {
        self.selectedIndex = 0
        segmentedControl.selectedSegmentIndex = 0
        jobViewModel.delegate = self
        getJobList()
    }
    
    func setup() {
        jobTableView.register(ACJobHomeTVCell.nib(), forCellReuseIdentifier: ACJobHomeTVCell.identifier)
        jobTableView.register(ACNoDataTableViewCell.nib(), forCellReuseIdentifier: ACNoDataTableViewCell.identifier)
        
        segmentedControl.backgroundColor = .clear
        segmentedControl.tintColor = .clear
        segmentedControl.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.lightGray], for: .normal)
        segmentedControl.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.orange], for: .selected)
    }
    
    func getJobList() {
        jobTableView.isHidden = true
        self.showActivityIndicator()
        if selectedIndex == 0 {
            params = ["status" : "\(JobStatus.inProgress),\(JobStatus.inBreak),\(JobStatus.assigned)"]
        } else if selectedIndex == 1 {
            params = ["status" : JobStatus.completed]
        } else {
            params = ["status" : JobStatus.cancelled]
        }
        
        jobViewModel.getJobList(params: params)
    }
}

//MARK: - ACJobsVC with UITableViewDelegate, UITableViewDataSource
extension ACJobsVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if jobArray.count > 0 {
            return jobArray.count
        } else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if jobArray.count == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: ACNoDataTableViewCell.identifier, for: indexPath) as! ACNoDataTableViewCell
            cell.selectionStyle = .none
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: ACJobHomeTVCell.identifier, for: indexPath) as! ACJobHomeTVCell
            if selectedIndex == 1 {
                cell.timeStackView.isHidden = false
            } else {
                cell.timeStackView.isHidden = true
            }
            cell.jobData = jobArray[indexPath.row]
         //   print(jobArray[indexPath.row].createdAt)
            cell.setup()
            cell.selectionStyle = .none
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if jobArray.count == 0 {
            return 100
        }
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        if jobArray.count == 0 {
            return 100
        }
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if jobArray.count > 0 {
            if !(jobArray[indexPath.row].status == JobStatus.cancelled) {
                let aVC = ACJobDetailsVC.instantiate(storyboard: "Home")
                aVC.jobData = jobArray[indexPath.row]
                aVC.jobId = jobArray[indexPath.row].id
                self.navigationController?.pushViewController(aVC, animated: true)
            }
        }
    }
    
}

//MARK: - ACJobsVC with JobViewModelDelegate
extension ACJobsVC: JobViewModelDelegate {
    
    func didReceiveJobListResponse(jobsResponse: JobModel?) {
        jobArray.removeAll()
        self.hideActivityIndicator()
        if jobsResponse?.data != nil {
            jobArray = jobsResponse?.data ?? [JobData]()
            DispatchQueue.main.async {
                self.jobTableView.isHidden = false
                self.jobTableView.reloadData()
            }
        } else {
            openAlert(title: ACAlertTitle.oops, message: jobsResponse?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        }
    }
}
