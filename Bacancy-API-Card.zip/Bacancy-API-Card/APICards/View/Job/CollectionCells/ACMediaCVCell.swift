//
//  ACMediaCVCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 23/06/22.
//

import UIKit
import SDWebImage
import AVFoundation

class ACMediaCVCell: UICollectionViewCell {
    
    static let identifier = "ACMediaCVCell"
    
    var avQueuePlayer   : AVQueuePlayer?
    var avPlayerLayer   : AVPlayerLayer?
    var player: AVPlayer?
    
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var imageView: UIImageView!
    
    var url: URL?
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setup() {
        if url?.containsImage ?? false {
            setupForImage()
        } else {
            setupForVideo()
        }
    }
    
    func setupForImage() {
        videoView.isHidden = true
        imageView.isHidden = false
        imageView.sd_setImage(with: url)
    }

    func setupForVideo() {
        videoView.isHidden = false
        imageView.isHidden = true
        setVideoOnView()
    }
    
    func setVideoOnView() {
        guard let url = url else { return }
        player = AVPlayer(url: (url) as URL)
        player?.actionAtItemEnd = .none
        player?.isMuted = true
        
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = videoView.frame
        playerLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        playerLayer.zPosition = -1
        videoView.layer.addSublayer(playerLayer)
        
      //  player?.play()
        
        // add observer to watch for video end in order to loop video
//        NotificationCenter.default.addObserver(
//            self,
//            selector: #selector(loopVideo),
//            name: .AVPlayerItemDidPlayToEndTime,
//            object: self.player?.currentItem
//        )
    }
    
    // if video ends, will restart
    func playerItemDidReachEnd() {
        player?.seek(to: CMTime.zero)
    }
    
    // add this loop at the end, after viewDidLoad
    @objc func loopVideo() {
        playerItemDidReachEnd()
        player?.play()
    }
}
