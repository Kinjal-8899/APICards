//
//  ACAddNewCVCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 22/06/22.
//

import UIKit

class ACAddNewCVCell: UICollectionViewCell {
    
    @IBOutlet weak var mainView: UIView!
    static let identifier = "ACAddNewCVCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
    func setBorder() {
        let color = AppColors.appOrangeColor
        let shapeLayer:CAShapeLayer = CAShapeLayer()
        let shapeRect = CGRect(x: 0, y: 0, width: mainView.frame.width, height: mainView.frame.height)
        shapeLayer.bounds = shapeRect
        shapeLayer.position = CGPoint(x: self.frame.width/2, y: self.frame.height/2)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = color.cgColor
        shapeLayer.lineWidth = 2
        shapeLayer.lineJoin = CAShapeLayerLineJoin.round
        shapeLayer.lineDashPattern = [6,3]
        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 14).cgPath
        mainView.layer.addSublayer(shapeLayer)
    }
}
