//
//  ACJobDetailVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 21/06/22.
//

import UIKit
import DKImagePickerController
import AVFoundation

class ACJobDetailsVC: UIViewController {

    @IBOutlet weak var btnCancelJob: UIButton!
    @IBOutlet weak var lblJobAmount: UILabel!
    @IBOutlet weak var invoiceView: CardView!
    @IBOutlet weak var btnBreak: UIButton!
    
    @IBOutlet weak var bottomHeight: NSLayoutConstraint!
    @IBOutlet weak var btnEndJob: UIButton!
    @IBOutlet weak var line2View: UIView!
    @IBOutlet weak var line1View: UIView!
    @IBOutlet weak var firstCircleView: RoundShadowView!
    @IBOutlet weak var secondCircleView: RoundShadowView!
    @IBOutlet weak var thirdCircleView: RoundShadowView!
    @IBOutlet weak var jobCompleteTimeLbl: UILabel!
    @IBOutlet weak var jobCompletedStackView: UIStackView!
    @IBOutlet weak var jobStartedStackView: UIStackView!
    @IBOutlet weak var completedTimeLbl: UILabel!
    @IBOutlet weak var onGoingTimeLbl: UILabel!
    @IBOutlet weak var jobCompleteLbl: UILabel!
    @IBOutlet weak var jobStartedTimeLbl: UILabel!
    @IBOutlet weak var jobStartedLbl: UILabel!
    @IBOutlet weak var jobAssignedLbl: UILabel!
    @IBOutlet weak var jobAssignedTimeLbl: UILabel!
    
    @IBOutlet weak var bottomBtnView: UIView!
    @IBOutlet weak var breakStopStackView: UIStackView!
    @IBOutlet weak var startJobBtn: UIButton!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var lblJobTitle: UILabel!
    @IBOutlet weak var lblJobStatus: UILabel!
    @IBOutlet weak var lblJobDesc: UILabel!
    
    //MARK: - Variables
    let screenSize: CGRect = UIScreen.main.bounds
    
    var isFullDesc: Bool = false
    var arrImageBefore = [UIImage]()
    var arrVideoBefore = [URL]()
    var arrImageAfter = [UIImage]()
    var arrVideoAfter = [URL]()
    var noOfMedia: Int = 0
    var jobData: JobData?
    var timer: Timer?
    
    var jobViewModel = JobViewModel()
    var jobId: Int?
    var isStarted: Bool?
    var jobBeforeMedia = [URL]()
    var jobAfterMedia = [URL]()
    var selectedIndex: Int = 0
    var isInBreak: Bool = false
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
       // setupLblDesc()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    //MARK: - Btn click events
    @IBAction func backBtnPressed(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func jobStartBtnPressed(_ sender: UIButton) {
        if arrImageBefore.count == 0 && arrVideoBefore.count == 0 {
            openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.beforeStartJobSelect, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        } else {
            jobViewModel.startStopJob(jobId: jobData?.id ?? 0, eventName: Event.job, eventType: EventType.inEvent, images: arrImageBefore, videos: arrVideoBefore,image_type: ImageType.beforeStart)
            self.removeOldData()
        }
    }
    
    @IBAction func breakBtnPressed(_ sender: UIButton) {
        if isInBreak {
            SingleTonTimer.sharedTimer.resumeTimer()
            openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.breakTimeStop, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [ {
                _ in
                
                self.jobViewModel.breakInOut(jobId: self.jobData?.id ?? 0, eventName: Event.inBreak, eventType: EventType.outEvent)
            }])
        } else {
            SingleTonTimer.sharedTimer.pauseTimer()
            openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.breakTimeStart, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [ {
                _ in
                self.jobViewModel.breakInOut(jobId: self.jobData?.id ?? 0, eventName: Event.inBreak, eventType: EventType.inEvent)
              
            }])
        }
    }
    
    @IBAction func jobEndPressed(_ sender: UIButton) {
        if arrImageAfter.count == 0 && arrVideoAfter.count == 0 {
            openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.beforeEndJobSelect, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        } else {
            jobViewModel.startStopJob(jobId: jobData?.id ?? 0, eventName: Event.job, eventType: EventType.outEvent, images: arrImageAfter, videos: arrVideoAfter,image_type: ImageType.afterEnd)
            self.removeOldData()
           
        }
    }

    @IBAction func segmentChanged(_ sender: UISegmentedControl) {
        selectedIndex = sender.selectedSegmentIndex
        reloadCollectionView()
    }
    
    
    @IBAction func cancelJobBtnPressed(_ sender: UIButton) {
        self.showActivityIndicator()
        guard let jobId = jobData?.id else {
            return
        }
        guard let companyId = jobData?.companyID else {
            return
        }
        jobViewModel.cancelJob(jobId: jobId, companyId: companyId)
    }
    
    //MARK: - Other methods
    private func setupLblDesc() {
        let readmoreFont = UIFont(name: "Helvetica", size: 15.0)
        let readmoreFontColor = AppColors.appBlueColor
        DispatchQueue.main.async {
            self.lblJobDesc.addTrailing(with: "...", moreText: "More", moreTextFont: readmoreFont!, moreTextColor: readmoreFontColor)
        }
        let tap = UITapGestureRecognizer(target: self, action: #selector(moreLblTapped(_:)))
        lblJobDesc.addGestureRecognizer(tap)
    }
    
    @objc func moreLblTapped(_ sender: UITapGestureRecognizer) {
        if isFullDesc {
            lblJobDesc.numberOfLines = 5
        } else {
            lblJobDesc.numberOfLines = 0
        }
    }
    
}

//MARK: - ACJobDetailVC
extension ACJobDetailsVC {
    
    //MARK: - initial Setup
    func initialSetup() {
        jobViewModel.delegate = self
        //register cell
        collectionView.register(ACMediaCVCell.nib(), forCellWithReuseIdentifier: ACMediaCVCell.identifier)
        collectionView.register(ACAddNewCVCell.nib(), forCellWithReuseIdentifier: ACAddNewCVCell.identifier)
        
        //colelctionview setup
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.minimumInteritemSpacing = 12
        layout.minimumLineSpacing = 12
        collectionView.collectionViewLayout = layout
        reloadCollectionView()
        
        //segment control
        let font: [NSAttributedString.Key : Any] = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 22)]
        segmentControl.setTitleTextAttributes(font, for: .normal)
        segmentControl.backgroundColor = .clear
        segmentControl.tintColor = .clear
        segmentControl.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: AppColors.appBlackColor], for: .normal)
        segmentControl.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .selected)
        
        reloadSetup()
        getJobDetail()
    }
    
    func getJobDetail() {
        self.showActivityIndicator()
        guard let jobId = jobId else { return }
        jobViewModel.getJobDetail(jobId: jobId)
    }
    
    func reloadSetup() {
        //First card view
        self.lblJobStatus.text = jobData?.status?.getNewJobStatus()
        self.lblJobTitle.text = jobData?.name
        self.lblJobDesc.text = jobData?.datumDescription
        
        //second card view
        if jobData?.status == JobStatus.assigned {
            setupForUpcomingJob()
        } else if jobData?.status == JobStatus.inProgress {
            setupForOngoingJob()
        }  else if jobData?.status == JobStatus.completed  {
            setupForCompletedJob()
        } else if jobData?.status == JobStatus.inBreak {
            setupForInBreak()
        }
        
    }
    
    func removeOldData() {
        if arrImageBefore.count > 0 {
            arrImageBefore.removeAll()
        }
        if arrVideoBefore.count > 0 {
            arrVideoBefore.removeAll()
        }
        if arrImageAfter.count > 0 {
            arrImageAfter.removeAll()
        }
        if arrVideoAfter.count > 0 {
            arrVideoAfter.removeAll()
        }
    }
    
    func setShadow(view: UIView) {
        view.layer.shadowColor = view.backgroundColor?.cgColor
        view.layer.shadowOffset = .zero
        view.layer.cornerRadius = view.frame.width / 2
        view.layer.shadowOpacity = 0.5
        view.layer.shadowRadius = view.frame.width / 2
    }
    
    func reloadCollectionView() {
        jobBeforeMedia.removeAll()
        jobAfterMedia.removeAll()
        
        if jobData?.jobImages?.count ?? 0 > 0 {
            for i in 0..<(jobData?.jobImages!.count)! {
                let url: URL = URL(string: (jobData?.jobImages?[i].image)!)!
                if jobData?.jobImages?[i].imageType == ImageType.beforeStart {
                    jobBeforeMedia.append(URL(string: "\(APIUrls.imageBaseURL)\(url)")!)
                } else {
                    jobAfterMedia.append(URL(string: "\(APIUrls.imageBaseURL)\(url)")!)
                }
            }
        }
        self.showActivityIndicator()
        DispatchQueue.main.async {
            self.hideActivityIndicator()
            self.collectionView.reloadData()
            let height = self.collectionView.collectionViewLayout.collectionViewContentSize.height
            self.collectionViewHeight.constant = height
        }
        
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
//            self.hideActivityIndicator()
//            self.collectionView.reloadData()
//            let height = self.collectionView.collectionViewLayout.collectionViewContentSize.height
//            self.collectionViewHeight.constant = height
//        }
    }
    
    func setupForInBreak() {
        isStarted = true
        lblJobStatus.textColor = AppColors.appGreenColor
        
        //second card View
        firstCircleView.backgroundColor = AppColors.appOrangeColor
        secondCircleView.backgroundColor = AppColors.appOrangeColor
        thirdCircleView.backgroundColor = AppColors.appGreyColor
        line1View.backgroundColor = AppColors.appOrangeColor
        line2View.backgroundColor = AppColors.appGreyColor
        setShadow(view: firstCircleView)
        setShadow(view: secondCircleView)
        setShadow(view: thirdCircleView)
        
        jobAssignedLbl.textColor = UIColor(named: "AppWhiteBlackColor")
        jobStartedLbl.textColor = UIColor(named: "AppWhiteBlackColor")
        jobCompleteLbl.textColor = AppColors.appFontGreyColor
        
        jobStartedStackView.isHidden = false
        jobCompletedStackView.isHidden = true
        lblJobAmount.isHidden = true
        self.isInBreak = true
        self.btnBreak.setTitle("Break Out", for: .normal)
        
        onGoingTimeLbl.text = UserDefaultHelper.strLatestTime
        
        invoiceView.isHidden = true
        //bottom
        bottomBtnView.isHidden = false
        startJobBtn.isHidden = true
        btnCancelJob.isHidden = true
        breakStopStackView.isHidden = false
        
        jobAssignedTimeLbl.text = jobData?.createdAt?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
        jobStartedTimeLbl.text = jobData?.startTime?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
    }
    
    func setupForUpcomingJob() {
        isStarted = false
        lblJobStatus.textColor = AppColors.appOrangeColor
        
        //second card View
        firstCircleView.backgroundColor = AppColors.appOrangeColor
        secondCircleView.backgroundColor = AppColors.appGreyColor
        thirdCircleView.backgroundColor = AppColors.appGreyColor
        line1View.backgroundColor = AppColors.appGreyColor
        line2View.backgroundColor = AppColors.appGreyColor
        setShadow(view: firstCircleView)
        setShadow(view: secondCircleView)
        setShadow(view: thirdCircleView)
        
        jobAssignedLbl.textColor = UIColor(named: "AppWhiteBlackColor")
        jobStartedLbl.textColor = AppColors.appFontGreyColor
        jobCompleteLbl.textColor = AppColors.appFontGreyColor
        
        jobStartedStackView.isHidden = true
        jobCompletedStackView.isHidden = true
        lblJobAmount.isHidden = true
        
        invoiceView.isHidden = true
        
        //bottom
        bottomBtnView.isHidden = false
        startJobBtn.isHidden = false
        btnCancelJob.isHidden = false
        breakStopStackView.isHidden = true
        
        jobAssignedTimeLbl.text = jobData?.createdAt?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
    }
    
    func setupForOngoingJob() {
        isStarted = true
        lblJobStatus.textColor = AppColors.appGreenColor
        
        //second card View
        firstCircleView.backgroundColor = AppColors.appOrangeColor
        secondCircleView.backgroundColor = AppColors.appOrangeColor
        thirdCircleView.backgroundColor = AppColors.appGreyColor
        line1View.backgroundColor = AppColors.appOrangeColor
        line2View.backgroundColor = AppColors.appGreyColor
        setShadow(view: firstCircleView)
        setShadow(view: secondCircleView)
        setShadow(view: thirdCircleView)
        
        jobAssignedLbl.textColor = UIColor(named: "AppWhiteBlackColor")
        jobStartedLbl.textColor = UIColor(named: "AppWhiteBlackColor")
        jobCompleteLbl.textColor = AppColors.appFontGreyColor
        
        jobStartedStackView.isHidden = false
        jobCompletedStackView.isHidden = true
        lblJobAmount.isHidden = true
        
        self.isInBreak = false
        self.btnBreak.setTitle("Break In", for: .normal)
        
        onGoingTimeLbl.text = UserDefaultHelper.strLatestTime
        self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimerLabel), userInfo: nil, repeats: true)
        
        invoiceView.isHidden = true
        //bottom
        bottomBtnView.isHidden = false
        startJobBtn.isHidden = true
        btnCancelJob.isHidden = true
        breakStopStackView.isHidden = false
        
        jobAssignedTimeLbl.text = jobData?.createdAt?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
        jobStartedTimeLbl.text = jobData?.startTime?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
        onGoingTimeLbl.text = SingleTonTimer.sharedTimer.currenttimeStr
    }
    
    func setupForCompletedJob() {
        lblJobStatus.textColor = AppColors.appGreenColor
        
        //second card View
        firstCircleView.backgroundColor = AppColors.appOrangeColor
        secondCircleView.backgroundColor = AppColors.appOrangeColor
        thirdCircleView.backgroundColor = AppColors.appOrangeColor
        line1View.backgroundColor = AppColors.appOrangeColor
        line2View.backgroundColor = AppColors.appOrangeColor
        setShadow(view: firstCircleView)
        setShadow(view: secondCircleView)
        setShadow(view: thirdCircleView)
        
        jobAssignedLbl.textColor = UIColor(named: "AppWhiteBlackColor")
        jobStartedLbl.textColor = UIColor(named: "AppWhiteBlackColor")
        jobCompleteLbl.textColor = UIColor(named: "AppWhiteBlackColor")
        
        jobStartedStackView.isHidden = false
        onGoingTimeLbl.isHidden = true
        jobCompletedStackView.isHidden = false
        lblJobAmount.isHidden = false
        
        invoiceView.isHidden = false
        let amount = "\(Float(jobData?.paymentDetails?.totalPaidAmount ?? 0).round(to: 2))"
        lblJobAmount.text = "$\(amount)"
        
        //bottom
        bottomHeight.constant = 0
        bottomBtnView.frame.size.height = 0
        bottomBtnView.isHidden = true
        
        
        jobAssignedTimeLbl.text = jobData?.createdAt?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
        jobStartedTimeLbl.text = jobData?.startTime?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
        onGoingTimeLbl.isHidden = true
        jobCompleteTimeLbl.text = jobData?.endTime?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
        completedTimeLbl.text = jobData?.totalInTime
    }
    
    //MARK: - update Timer Label
    @objc func updateTimerLabel() {
        onGoingTimeLbl.text = SingleTonTimer.sharedTimer.currenttimeStr
    
    }
    
    //MARK: - pick Media
    func pickMedia() {
        let pickerController = DKImagePickerController()
        self.removeOldData()
//        if selectedIndex == 0 {
//        arrImageBefore.removeAll()
//        arrVideoBefore.removeAll()
//        } else {
//            arrImageAfter.removeAll()
//            arrVideoAfter.removeAll()
//        }
        pickerController.maxSelectableCount = 10
        pickerController.didSelectAssets = { (assets: [DKAsset]) in
            print("didSelectAssets")
            //print(assets)
            
            for data in assets {
                if data.type == .photo {
                    let screenSize = UIScreen.main.bounds.size
                    data.fetchImage(with: screenSize.toPixel(), completeBlock: { (image, hashable) in
                        DispatchQueue.main.async {
                            if image?.size.width ?? 0 >= 150 {
                                let img = image?.jpegData(compressionQuality: 0.5)
                                if self.selectedIndex == 0 {
                                    self.arrImageBefore.append(UIImage(data: img ?? Data()) ?? UIImage())
                                } else {
                                    self.arrImageAfter.append(UIImage(data: img ?? Data()) ?? UIImage())
                                }
                               // print(self.arrImage)
                            }
                        }
                    })
                } else if data.type == .video {
                    data.fetchAVAsset(options: .none) { video, info in
                        if let urlAsset = video as? AVURLAsset {
                            let localVideoUrl = urlAsset.url
                           // print(localVideoUrl)
                            DispatchQueue.main.async {
                               
                                if self.selectedIndex == 0 {
                                    self.arrVideoBefore.append(localVideoUrl)
                                } else {
                                    self.arrVideoAfter.append(localVideoUrl)
                                }
                            }
                        }
                    }
                }
            }
            self.showActivityIndicator()
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.hideActivityIndicator()
              //  self.uploadData()
            }
        }
        self.present(pickerController, animated: true)
    }
    
    //MARK: - upload Data
    func uploadData() {
        self.showActivityIndicator()
        if isStarted ?? false {
            jobViewModel.startStopJob(jobId: jobData?.id ?? 0, eventName: Event.job, eventType: EventType.outEvent, images: arrImageAfter, videos: arrVideoAfter,image_type: ImageType.afterEnd)
        } else {
            jobViewModel.startStopJob(jobId: jobData?.id ?? 0, eventName: Event.job, eventType: EventType.inEvent, images: arrImageBefore, videos: arrVideoBefore,image_type: ImageType.beforeStart)
        }
    }
}
//MARK: - ACJobDetailsVC with UICollectionViewDelegate, UICollectionViewDataSource
extension ACJobDetailsVC:  UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if selectedIndex == 0 {
            noOfMedia = jobBeforeMedia.count + 1
        } else {
            noOfMedia = jobAfterMedia.count + 1
        }
        return noOfMedia
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.row == noOfMedia - 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ACAddNewCVCell.identifier, for: indexPath) as! ACAddNewCVCell
            cell.setBorder()
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ACMediaCVCell.identifier, for: indexPath) as! ACMediaCVCell
            if selectedIndex == 0 {
                cell.url = jobBeforeMedia[indexPath.row]
            } else {
                cell.url = jobAfterMedia[indexPath.row]
            }
            cell.setup()
            return cell
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = screenSize.width / 3 - 32
        return CGSize(width: width, height: width)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.row == noOfMedia - 1 {
            self.pickMedia()
        } else {
            let aVC = ACMediaPreviewVC.instantiate(storyboard: "Home")
            if selectedIndex == 0 {
                aVC.url = jobBeforeMedia[indexPath.row]
            } else {
                aVC.url = jobAfterMedia[indexPath.row]
            }
            self.present(aVC, animated: true, completion: nil)
            //self.navigationController?.pushViewController(aVC, animated: true)
        }
    }
    
}

//MARK: - ACJobDetailsVC with JobViewModelDelegate
extension ACJobDetailsVC: JobViewModelDelegate {
    func didUpdateJobTomeLog(response: JobData?) {
        self.hideActivityIndicator()
        if response == nil {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                self.navigationController?.popViewController(animated: true)
            }])
        } else {
            if isStarted ?? false {
                SingleTonTimer.sharedTimer.stopGlobalTimer()
                UserDefaultHelper.jobIdInProgresss = nil
                DispatchQueue.main.async {
                    let aVC = ACInvoiceSummaryVC.instantiate(storyboard: "Home")
                    aVC.jobData = response
                    self.navigationController?.pushViewController(aVC, animated: true)
                }
            } else {
                SingleTonTimer.sharedTimer.startGlobalTimer()
                UserDefaultHelper.jobIdInProgresss = jobData?.id
            }
            DispatchQueue.main.async {
                self.jobData = response
                self.reloadCollectionView()
                self.reloadSetup()
                
            }
        }
    }
    
    func didUpdateBreakData(response: JobData?) {
        self.hideActivityIndicator()
        if response == nil {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                self.navigationController?.popViewController(animated: true)
            }])
        } else {
            DispatchQueue.main.async {
                self.jobData = response
                self.reloadCollectionView()
                self.reloadSetup()
            }
        }
    }
    
    func didReceiveJobDetails(response: JobData?) {
        self.hideActivityIndicator()
        if response == nil {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                self.navigationController?.popViewController(animated: true)
            }])
        } else {
            DispatchQueue.main.async {
                self.jobData = response
                self.reloadCollectionView()
                self.reloadSetup()
            }
        }
    }
    
    
    func didCancelJob(response: JobData?) {
        self.hideActivityIndicator()
        if response == nil {
            openAlert(title: ACAlertTitle.oops, message: ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                self.navigationController?.popViewController(animated: true)
            }])
        } else {
            DispatchQueue.main.async {
                self.openAlert(title: ACAlertTitle.success, message: "Job is successfully cancelled.", alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                    self.navigationController?.popViewController(animated: true)
                }])
            }
        }
    }
}
