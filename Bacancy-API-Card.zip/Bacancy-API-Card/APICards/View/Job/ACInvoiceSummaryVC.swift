//
//  ACInvoiceSummaryVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 27/06/22.
//

import UIKit

class ACInvoiceSummaryVC: UIViewController {

    @IBOutlet weak var lblPayableAmount: UILabel!
    @IBOutlet weak var lblDiscount: UILabel!
    @IBOutlet weak var lblTax: UILabel!
    @IBOutlet weak var lblTip: UILabel!
    @IBOutlet weak var lblTotalAmount: UILabel!
    @IBOutlet weak var lblTotalWorkingHours: UILabel!
    @IBOutlet weak var lblHourlyRate: UILabel!
    @IBOutlet weak var lblJobName: UILabel!
   
    //MARK: - Variables
    var jobData: JobData?
    var summaryData: CompanyPaymentData?
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    //MARK: - Btn click events
    @IBAction func checkoutBtnPressed(_ sender: UIButton) {
        let aVC = ACPayNowVC.instantiate(storyboard: "Home")
        aVC.invoiceData = self.summaryData
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    
}

//MARK: - ACInvoiceSummaryVC
extension ACInvoiceSummaryVC {
    
    func initialSetup() {
      
        guard let jobData = jobData else { return }
        
        
        //calculation of hours from String
        let timeArray : [String] = jobData.totalInTime?.components(separatedBy: ":") ?? [String]()
        print(timeArray)
        //minute to hour
        let minutes = Float(timeArray[1]) ?? 0
        print(minutes)
        let minToHour = Float(minutes / 60)
        print(minToHour)
        let hours = Float(timeArray[0]) ?? 0
        let totalHours = hours + minToHour
        print(totalHours)
        var total = Float(jobData.hourlyRate ?? 0) * totalHours
        total = total.round(to: 2)
        print(total)
        
        let tip: Float = 0
        let tax: Float = 0
        let discount: Float = 0
        
        var totalPayableAmount = total + tip + tax - discount
        totalPayableAmount = totalPayableAmount.round(to: 2)
        
        summaryData = CompanyPaymentData(jobId: jobData.id, companyID: jobData.companyID, companyName: jobData.companyName, total_amount: total, discount: discount.round(to: 2), total_paid_amount: totalPayableAmount, tips: tip.round(to: 2), tax: tax.round(to: 2), note: "", jobName: jobData.name)
        
        
        lblJobName.text = jobData.name
        
        lblHourlyRate.text = "$\(jobData.hourlyRate ?? 0)/hr"
        lblTotalWorkingHours.text = jobData.totalInTime
        lblTotalAmount.text = "$\(total)"
        lblTip.text = "$\(tip)"
        lblTax.text = "$\(tax)"
        lblDiscount.text = " - $\(discount)"
        lblPayableAmount.text = "$\(totalPayableAmount)"
        
        
              
    }
    
}
