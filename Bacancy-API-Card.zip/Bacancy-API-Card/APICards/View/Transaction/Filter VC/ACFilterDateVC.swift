//
//  ACFilterDateVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 28/06/22.
//

import UIKit
import ActionSheetPicker_3_0

//MARK: - FilterDateDelegate
protocol FilterDateDelegate {
    func applyClicked(from: String, to: String)
}

//MARK: - ACFilterDateVC
class ACFilterDateVC: UIViewController {
    
    //MARK: - IBOutlets
    @IBOutlet weak var applyResetBtn: UIButton!
    @IBOutlet weak var resetBtn: UIButton!
    @IBOutlet weak var txtToDate: UITextField!
    @IBOutlet weak var txtFromDate: UITextField!
    @IBOutlet weak var toView: UIView!
    @IBOutlet weak var fromView: UIView!
    @IBOutlet weak var containerView: UIView!
    
    //MARK: - Variables
    var delegate: FilterDateDelegate?
    var customPicker = UIPickerView()
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        
    }

    //MARK: - Btn click events
    @IBAction func resetBtnPressed(_ sender: UIButton) {
        txtFromDate.text = ""
        txtToDate.text = ""
    }
    @IBAction func toBtnPressed(_ sender: UIButton) {
        ActionSheetDatePicker.show(withTitle: "Date",
                                   datePickerMode: .date,
                                   selectedDate: Date(),
                                   minimumDate: nil,
                                   maximumDate: Date.getCurrentDate(),
                                   doneBlock: { picker, date, origin in
            
            if let aDate = date as? Date
            {
                self.txtToDate.text = aDate.toString(formateType: .dd_MM_yyyy)
            }
            return
        }, cancel: { (sender) in
            return
        }, origin: sender)
    }
    
    @IBAction func fromBtnPressed(_ sender: UIButton) {
        customPicker.frame = CGRect(x: 0, y: self.view.frame.height - 200, width: self.view.frame.width, height: 200)
//        ActionSheetDatePicker.show(withTitle: "Date",
//                                   datePickerMode: .date,
//                                   selectedDate: Date(),
//                                   minimumDate: nil,
//                                   maximumDate: nil,
//                                   doneBlock: { picker, date, origin in
//
//            if let aDate = date as? Date
//            {
//                self.txtFromDate.text = aDate.toString(formateType: .dd_MM_yyyy)
//
//            }
//            return
//        }, cancel: { (sender) in
//            return
//        }, origin: sender)
    }
    
    @IBAction func applyBtnPressed(_ sender: UIButton) {
        
        guard let fromDate = txtFromDate.text else { return }
        guard let toDate = txtToDate.text else { return }
        
        if fromDate == "" {
            openAlert(title: ACAlertTitle.oops, message: "Please select the 'From' date", alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        } else if toDate == "" {
            openAlert(title: ACAlertTitle.oops, message: "Please select the 'To' date", alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        } else {
            self.delegate?.applyClicked(from: fromDate, to: toDate)
        }
        
    }
    
    //MARK: - Other methods
    private func initialSetup() {
        txtToDate.delegate = self
        txtFromDate.delegate = self
        CommonMethods.setBorderRadius(view: fromView, radius: 14, borderColor: AppColors.appBorderColor, borderWidth: 1)
        CommonMethods.setBorderRadius(view: toView, radius: 14, borderColor: AppColors.appBorderColor, borderWidth: 1)
        
    }
    

}

//MARK: - ACFilterDateVC with UITextFieldDelegate
extension ACFilterDateVC: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == txtFromDate {
            ActionSheetDatePicker.show(withTitle: "Date",
                                       datePickerMode: .date,
                                       selectedDate: Date(),
                                       minimumDate: nil,
                                       maximumDate: nil,
                                       doneBlock: { picker, date, origin in
                
                if let aDate = date as? Date
                {
                    self.txtFromDate.text = aDate.toString(formateType: .dd_MM_yyyy)
                    
                }
                return
            }, cancel: { (sender) in
                return
            }, origin: textField)
        } else {
            ActionSheetDatePicker.show(withTitle: "Date",
                                       datePickerMode: .date,
                                       selectedDate: Date(),
                                       minimumDate: nil,
                                       maximumDate: Date.getCurrentDate(),
                                       doneBlock: { picker, date, origin in
                
                if let aDate = date as? Date
                {
                    self.txtToDate.text = aDate.toString(formateType: .dd_MM_yyyy)
                }
                return
            }, cancel: { (sender) in
                return
            }, origin: textField)
        }
    }
}


extension ACFilterDateVC: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return "Test"
    }
}
extension ACFilterDateVC: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 10
    }
    
    
}
