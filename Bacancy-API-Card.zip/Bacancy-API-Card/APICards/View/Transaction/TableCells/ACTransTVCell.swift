//
//  ACTransTVCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 28/06/22.
//

import UIKit

class ACTransTVCell: UITableViewCell {

    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblTotalAmount: UILabel!
    
    @IBOutlet weak var lblTransactionDate: UILabel!
    @IBOutlet weak var lblPaymentMode: UILabel!
    @IBOutlet weak var lblJobName: UILabel!
    
    static let identifier = "ACTransTVCell"
    
    var transModel: TransactionData?
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setup() {
        let amount = "\(Float(transModel?.totalPaidAmount ?? 0).round(to: 2))"
        lblTotalAmount.text = "$\(amount)"
        lblJobName.text = transModel?.job?.name
        lblCompanyName.text = transModel?.company
        lblPaymentMode.text = transModel?.paymentType
        lblTransactionDate.text = transModel?.createdAt?.UTCToLocal(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .d_MMM_yyyy)
    }
    
}
