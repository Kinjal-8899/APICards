//
//  ACTransHeaderCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 28/06/22.
//

import UIKit

class ACTransHeaderCell: UITableViewCell {

    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var containerLbl: UILabel!
    
    @IBOutlet weak var containerView: UIView!
    static let identifier = "ACTransHeaderCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
