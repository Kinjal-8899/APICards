//
//  ACTransactionsVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 27/06/22.
//

import UIKit

class ACTransactionsVC: UIViewController {

    //MARK: - IBOutlets
    @IBOutlet weak var filterBtn: UIButton!
    @IBOutlet weak var transactionTableView: UITableView!
    
    //MARK: - Variables
    var transArray: [TransactionData] = [TransactionData]()
    
    var filterVC: ACFilterDateVC!
    var bgView: UIView!
    
    var isFilterApplied: Bool = false
    var paymentViewModel = PaymentViewModel()
    var containerText: String = ""
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    //MARK: - Btn click events
    @IBAction func filterBtnPressed(_ sender: UIButton) {
        self.setupSwipeUpView()
    }
}

//MARK: - ACTransactionsVC
extension ACTransactionsVC {
    
    func initialSetup() {
        transactionTableView.register(ACTransTVCell.nib(), forCellReuseIdentifier: ACTransTVCell.identifier)
        transactionTableView.register(ACNoDataTableViewCell.nib(), forCellReuseIdentifier: ACNoDataTableViewCell.identifier)
        transactionTableView.register(ACTransHeaderCell.nib(), forCellReuseIdentifier: ACTransHeaderCell.identifier)
        transactionTableView.isHidden = true
        self.showActivityIndicator()
        paymentViewModel.delegate = self
        paymentViewModel.getTransactionlist()
       
    }
    
    private func setupSwipeUpView() {
        
        bgView = UIView()
        bgView.frame = view.frame
        bgView.backgroundColor = .black
        bgView.alpha = 0.5
        let tap = UITapGestureRecognizer(target: self, action: #selector(bgViewTapped(_:)))
        bgView.addGestureRecognizer(tap)
        view.addSubview(bgView)
        
        self.filterVC = ACFilterDateVC(nibName: "ACFilterDateVC", bundle: nil)
        self.filterVC.view.frame = CGRect(x: 0, y: self.view.frame.height - (self.filterVC.containerView.frame.height + 80), width: self.view.frame.width, height: self.filterVC.containerView.frame.height + 80)
        self.filterVC.delegate = self
        
        self.addChild(self.filterVC)
        self.view.addSubview(self.filterVC.view)
    }
    
    @objc func bgViewTapped(_ sender: UITapGestureRecognizer) {
        closeSlideupView()
    }
    
    private func closeSlideupView() {
        self.filterVC.view.removeFromSuperview()
        self.filterVC.removeFromParent()
        self.bgView.removeFromSuperview()
    }
    
}

//MARK: - ACTransactionsVC with FilterDateDelegate
extension ACTransactionsVC: FilterDateDelegate {
    func applyClicked(from: String, to: String) {
        print(from)
        print(to)
        let fromDate = from.changeDateFormat(fromFormat: .dd_MM_yyyy, toFormat: .d_MMM)
        let toDate = to.changeDateFormat(fromFormat: .dd_MM_yyyy, toFormat: .d_MMM)
        containerText = "From \(fromDate), to \(toDate)"
        self.isFilterApplied = true
        self.closeSlideupView()
        self.transactionTableView.isHidden = true
        self.showActivityIndicator()
        paymentViewModel.getTransactionlistBetweenDates(startDate: from, endDate: to)
        DispatchQueue.main.async {
            self.filterBtn.setImage(UIImage(named: "Filter2"), for: .normal)
        }
    }
    
    
}
//MARK: - ACTransactionsVC with PaymentViewModelDelegate
extension ACTransactionsVC: PaymentViewModelDelegate {
    
    func didReceiveTransactionList(response: TransactionModel?) {
        transArray.removeAll()
        self.hideActivityIndicator()
        if response?.data != nil {
            DispatchQueue.main.async {
                self.transArray = response?.data ?? [TransactionData]()
                self.transactionTableView.isHidden = false
                self.transactionTableView.reloadData()
            }
        } else {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        }
    }
}

//MARK: - ACTransactionsVC with UITableViewDelegate, UITableViewDataSource
extension ACTransactionsVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if transArray.count > 0 {
            return transArray.count
        } else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: ACTransHeaderCell.identifier) as! ACTransHeaderCell
        if isFilterApplied {
            cell.lblDate.isHidden = true
            cell.containerLbl.text = containerText
        } 
        cell.selectionStyle = .none
        return cell
    }


    func tableView(_ tableView: UITableView, estimatedHeightForHeaderInSection section: Int) -> CGFloat {
        if isFilterApplied {
            return 40
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if isFilterApplied {
            return 40
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if transArray.count > 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: ACTransTVCell.identifier, for: indexPath) as! ACTransTVCell
            cell.transModel = transArray[indexPath.row]
            cell.setup()
            cell.selectionStyle = .none
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: ACNoDataTableViewCell.identifier, for: indexPath) as! ACNoDataTableViewCell
            cell.selectionStyle = .none
            return cell
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if transArray.count > 0 {
            return UITableView.automaticDimension
        } else {
            return 100
        }
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        if transArray.count > 0 {
            return UITableView.automaticDimension
        } else {
            return 100
        }
    }

}
