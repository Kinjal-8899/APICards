//
//  ACSignInVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 05/04/22.
//

import UIKit

class ACSignInVC: UIViewController {

    @IBOutlet weak var errorMessage: UILabel!
    @IBOutlet weak var errorView: CardView!
    @IBOutlet weak var showPasswordBtn: UIButton!
    @IBOutlet weak var rememberMeBtn: UIButton!
    @IBOutlet weak var passwordView: UIView!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    
    //MARK: - Variables
    private var loginViewModel = LoginViewModel()
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        txtemail.delegate = self
        txtPassword.delegate = self
        
        if UserDefaultHelper.isRememberMe ?? false {
            //rememberMeBtn.isSelected = true
            rememberMeBtn.setImage(UIImage(named: "tick-square"), for: .normal)
            txtemail.text = UserDefaultHelper.userEmail
            txtPassword.text = UserDefaultHelper.userPassword
        }
        
        let tapGesture = UITapGestureRecognizer(target: self,
                                                action: #selector(hideKeyboard))
        view.addGestureRecognizer(tapGesture)
        setUpBtns()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    //MARK: - Button click events
    @IBAction func showPasswordBtnPressed(_ sender: UIButton) {
        showPasswordBtn.isSelected = !showPasswordBtn.isSelected
        if showPasswordBtn.isSelected {
            txtPassword.isSecureTextEntry = false
        } else {
            txtPassword.isSecureTextEntry = true
        }
    }
    
    @IBAction func rememberMeBtnPressed(_ sender: UIButton) {
        if rememberMeBtn.imageView?.image == UIImage(named: "tick-square-1") {
            rememberMeBtn.setImage(UIImage(named: "tick-square"), for: .normal)
        } else {
            rememberMeBtn.setImage(UIImage(named: "tick-square-1"), for: .normal)
        }
       // rememberMeBtn.isSelected = !rememberMeBtn.isSelected
    }
    
    @IBAction func forgotPasswordBtnPressed(_ sender: UIButton) {
        let aVC = ACForgotPasswordVC.instantiate(storyboard: "Main")
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func signInBtnPressed(_ sender: UIButton) {
        self.showActivityIndicator()
        loginViewModel.delegate = self
        guard let email = txtemail.text else { return }
        guard let password = txtPassword.text else { return }
        loginViewModel.loginUser(loginRequest: LoginRequest(email: email, password: password))
    }
}

//MARK: - ACSignInVC with UITextFieldDelegate
extension ACSignInVC : UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if !errorView.isHidden {
            errorView.isHidden = true
        }
    }
}

//MARK: - ACSignInVC
extension ACSignInVC {
    private func setUpBtns() {
        errorView.isHidden = true
        CommonMethods.setBorderRadius(view: emailView, radius: 14, borderColor: AppColors.appBorderColor, borderWidth: 1)
        CommonMethods.setBorderRadius(view: passwordView, radius: 14, borderColor: AppColors.appBorderColor, borderWidth: 1)
        
        showPasswordBtn.setImage(UIImage(systemName: "eye.slash"), for: .normal)
        showPasswordBtn.setImage(UIImage(systemName: "eye"), for: .selected)
//        rememberMeBtn.setImage(UIImage(named: "tick-square-1"), for: .normal)
//        rememberMeBtn.setImage(UIImage(named: "tick-square"), for: .normal)
    }
    
    @objc func hideKeyboard() {
        view.endEditing(true)
    }
}

//MARK: - ACSignInVC with LoginViewModelDelegate
extension ACSignInVC : LoginViewModelDelegate {
    
    func didReceiveLoginResponse(loginResponse: LoginResponse?) {
        self.hideActivityIndicator()
        if loginResponse?.data != nil {
            
            if rememberMeBtn.isSelected {
                UserDefaultHelper.isRememberMe = true
                UserDefaultHelper.userEmail = txtemail.text
                UserDefaultHelper.userPassword = txtPassword.text
            } else {
                UserDefaultHelper.isRememberMe = false
                UserDefaultHelper.userEmail = nil
                UserDefaultHelper.userPassword = nil
            }
            
            UserDefaultHelper.authToken = loginResponse?.data?.authToken
            UserDefaultHelper.isUserLoggedIn = true
            UserDefaultHelper.userId = loginResponse?.data?.id
            
            let initialViewController: UITabBarController = UIStoryboard(name: "Home", bundle: nil).instantiateViewController(withIdentifier: "ACTabBarVC2") as? UITabBarController ?? UITabBarController()
            self.navigationController?.pushViewController(initialViewController, animated: true)
        } else {
            DispatchQueue.main.async {
                if loginResponse?.message == "User Not Found." {
                    self.errorMessage.text = "Invalid Password or username"
                } else {
                    self.errorMessage.text = loginResponse?.message
                }
                self.errorView.isHidden = false
                if !(loginResponse?.message == ACValidationError.missingEmail || loginResponse?.message == ACValidationError.missingPassword || loginResponse?.message == ACValidationError.invalidEmail) {
                    self.txtemail.text = ""
                    self.txtPassword.text = ""
                    self.txtemail.resignFirstResponder()
                }
            }
        }
    }
}
