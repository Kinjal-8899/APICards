//
//  ACQuickSetupVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import UIKit

class ACQuickSetupVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func doneBtnPressed(_ sender: UIButton) {
//        let aVC = self.storyboard?.instantiateViewController(withIdentifier: "ACTabBarVC") as! ACTabBarVC
//        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func menuBtnPressed(_ sender: UIBarButtonItem) {
        let aVC = ACMenuVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }

}
