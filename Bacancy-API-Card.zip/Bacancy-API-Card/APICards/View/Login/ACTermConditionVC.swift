//
//  ACTermConditionVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 05/04/22.
//

import UIKit

class ACTermConditionVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    @IBAction func acceptBtnPressed(_ sender: UIButton) {
        let aVC = ACSignInVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func menuBtnPressed(_ sender: Any) {
        let aVC = ACMenuVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
}
