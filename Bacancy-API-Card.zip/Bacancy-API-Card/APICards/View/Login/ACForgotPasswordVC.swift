//
//  ACForgotPasswordVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 06/04/22.
//

import UIKit

class ACForgotPasswordVC: UIViewController {

    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var txtEmail: UITextField!
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        CommonMethods.setBorderRadius(view: emailView, radius: 14, borderColor: AppColors.appBorderColor, borderWidth: 1)
        let tapGesture = UITapGestureRecognizer(target: self,
                                                action: #selector(hideKeyboard))
        view.addGestureRecognizer(tapGesture)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
  
    //MARK: - Btn click events
    @IBAction func backBtnPressed(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submitBtnPressed(_ sender: UIButton) {
    }
    
    @objc func hideKeyboard() {
        view.endEditing(true)
    }
}

