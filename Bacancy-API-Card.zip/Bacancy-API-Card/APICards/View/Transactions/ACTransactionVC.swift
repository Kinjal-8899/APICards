//
//  ACTransactionVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 14/04/22.
//

import UIKit

class ACTransactionVC: UIViewController {

    
    @IBOutlet weak var navBar: UINavigationBar!
    @IBOutlet weak var transTableView: UITableView!
    
    var transArray: [TransactionData] = [TransactionData]()
    
    var chooseDateVC: ACHistoryVC!
    var bgView: UIView!
    var isChooseDateOpen: Bool = false
    var paymentViewModel = PaymentViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func menuBtnPressed(_ sender: UIBarButtonItem) {
        let aVC = ACMenuVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func historyBtnPressed(_ sender: UIBarButtonItem) {
        if self.isChooseDateOpen {
            hideCDView()
        } else {
            showChooseDateView()
        }
    }
}

extension ACTransactionVC {
    
    func initialSetup() {
//        transTableView.register(ACTransactionTVCell.nib(), forCellReuseIdentifier: ACTransactionTVCell.identifier)
//        transTableView.register(ACNoDataTableViewCell.nib(), forCellReuseIdentifier: ACNoDataTableViewCell.identifier)
        transTableView.isHidden = true
        self.showActivityIndicator()
        paymentViewModel.delegate = self
        paymentViewModel.getTransactionlist()
    }
    
    
    //MARK: - show Choose Date View
    func showChooseDateView() {
        self.isChooseDateOpen = true
        bgView = UIView()
        bgView.frame = view.frame
        bgView.backgroundColor = .black
        bgView.alpha = 0.1
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(hideCDView))
        bgView.addGestureRecognizer(tapGesture)
        view.addSubview(bgView)
        
        self.chooseDateVC = ACHistoryVC.instantiate()
        print(navBar.frame.origin.y + navBar.frame.height)
        self.chooseDateVC.view.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.chooseDateVC.mainView.frame.height )
        self.chooseDateVC.delegate = self
        self.addChild(self.chooseDateVC)
        self.view.addSubview(self.chooseDateVC.view)
    }
    
    @objc func hideCDView() {
        self.isChooseDateOpen = false
        self.chooseDateVC.view.removeFromSuperview()
        self.chooseDateVC.removeFromParent()
        self.bgView.removeFromSuperview()
    }
}

//MARK: - ACTransactionVC with PaymentViewModelDelegate
extension ACTransactionVC: PaymentViewModelDelegate {
    
    func didReceiveTransactionList(response: TransactionModel?) {
        transArray.removeAll()
        self.hideActivityIndicator()
        if response?.data != nil {
            transArray = response?.data ?? [TransactionData]()
            DispatchQueue.main.async {
                self.transTableView.isHidden = false
                self.transTableView.reloadData()
            }
        } else {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        }
    }
}

//MARK: - ACTransactionVC with ACChooseDateDelegate
extension ACTransactionVC: ACChooseDateDelegate {
    func dateChosen(startDate: String, endDate: String) {
        hideCDView()
        self.showActivityIndicator()
        paymentViewModel.getTransactionlistBetweenDates(startDate: startDate, endDate: endDate)
    }
    
    func viewHistory() {
        hideCDView()
        self.showActivityIndicator()
        paymentViewModel.getTransactionlist()
    }
    
}
//
//extension ACTransactionVC: UITableViewDelegate, UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if transArray.count > 0 {
//            return transArray.count
//        } else {
//            return 1
//        }
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        if transArray.count > 0 {
//          //  let cell = tableView.dequeueReusableCell(withIdentifier: ACTransactionTVCell.identifier, for: indexPath) as! ACTransactionTVCell
//            cell.transModel = transArray[indexPath.row]
//            cell.setup()
//      //      cell.selectionStyle = .none
//            return cell
//        } else {
//            let cell = tableView.dequeueReusableCell(withIdentifier: ACNoDataTableViewCell.identifier, for: indexPath) as! ACNoDataTableViewCell
//            cell.selectionStyle = .none
//            return cell
//        }
//    }
//
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        if transArray.count > 0 {
//            return UITableView.automaticDimension
//        } else {
//            return 100
//        }
//    }
//    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        if transArray.count > 0 {
//            return UITableView.automaticDimension
//        } else {
//            return 100
//        }
//    }
//
//}
