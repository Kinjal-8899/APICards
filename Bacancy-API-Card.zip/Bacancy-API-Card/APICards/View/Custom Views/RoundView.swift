//
//  RoundView.swift
//  APICards
//
//  Created by Harindra Pittalia on 07/04/22.
//

import Foundation
import UIKit

class RoundView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialSetup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        initialSetup()
    }
    
    private func initialSetup() {
        layer.shadowColor = UIColor.gray.cgColor
        layer.shadowOffset = .zero
        layer.cornerRadius = self.frame.width / 2
        layer.shadowOpacity = 0.3
        layer.shadowRadius = self.frame.width / 2
    }
    
}
