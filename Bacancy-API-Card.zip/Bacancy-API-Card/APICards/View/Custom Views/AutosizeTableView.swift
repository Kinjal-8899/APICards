//
//  AutosizeTableView.swift
//  APICards
//
//  Created by Harindra Pittalia on 08/04/22.
//

import Foundation
import UIKit

class AutosizeTableView: UITableView {

     override var contentSize: CGSize {
        didSet {
          self.invalidateIntrinsicContentSize()
        }
      }

      override var intrinsicContentSize: CGSize {
        self.layoutIfNeeded()
        return CGSize(width: UIView.noIntrinsicMetric, height: contentSize.height + 20)
      }
       override func reloadData() {
         super.reloadData()
         invalidateIntrinsicContentSize()
       }

  

}
