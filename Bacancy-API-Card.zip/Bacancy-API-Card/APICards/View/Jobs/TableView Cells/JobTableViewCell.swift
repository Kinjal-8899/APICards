//
//  JobTableViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 27/04/22.
//

//struct TimerData {
//    var jobId: Int?
//    var timing: String?
//    var timer: Timer?
//}

import UIKit

//protocol JobTableViewDelegate {
//    func didPressedStart(jobId: Int)
//    func didPressedEnd(jobId: Int)
//    func didPressedBreakIn(jobId: Int)
//    func didPressedBreakOut(jobId: Int)
//}

class JobTableViewCell: UITableViewCell {
   
    @IBOutlet weak var totalTimeStackView: UIStackView!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var dateStackView: UIStackView!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var mainView: CardView!
    @IBOutlet weak var lblTotalHours: UILabel!
    @IBOutlet weak var lblJobDesc: UILabel!
    @IBOutlet weak var lblJobTitle: UILabel!
    @IBOutlet weak var lblTimer: UILabel!
    
    var timer: Timer?
    var jobModel : JobData?
    
    static let identifier = "JobTableViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    //MARK: - setup cell data
    func setup() {
        self.totalTimeStackView.isHidden = true
        self.dateStackView.isHidden = true
        self.lblTimer.isHidden = false
        self.lblAmount.isHidden = true
        self.lblJobTitle.text = jobModel?.name
        self.lblJobDesc.text = jobModel?.datumDescription
        
        //Total hours label
        if jobModel?.totalInTime == "" {
            lblTotalHours.text = "0:00 hrs"
        } else {
            lblTotalHours.text = "\(jobModel?.totalInTime ?? "0:00") hrs"
        }
        
        //Timer label
        if jobModel?.id == UserDefaultHelper.jobIdInProgresss {
            self.lblTimer.text = UserDefaultHelper.strLatestTime
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimerLabel), userInfo: nil, repeats: true)
        } else {
            self.lblTimer.isHidden = true
            self.timer = nil
        }
        
        (UserDefaultHelper.jobIdInProgresss == jobModel?.id) ? CommonMethods.setBorderRadius(view: mainView, radius: 10, borderColor: AppColors.appOrangeColor, borderWidth: 2) :
        CommonMethods.setBorderRadius(view: mainView, radius: 10, borderColor: UIColor.white, borderWidth: 2)
        
        if jobModel?.status == JobStatus.completed {
            CommonMethods.setBorderRadius(view: mainView, radius: 10, borderColor: AppColors.appGreenColor, borderWidth: 2)
            lblAmount.isHidden = false
            self.totalTimeStackView.isHidden = false
            let amount = "\(Float(jobModel?.paymentDetails?.totalPaidAmount ?? 0).round(to: 2))"
            //let amount = String(format: "%.2f", jobModel?.totalRate as! CVarArg)
            lblAmount.text = "Amount: $\(amount)"
            self.dateStackView.isHidden = false
            lblDate.text = jobModel?.startTime?.changeDateFormateToUTC(fromFormat: .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: .dd_MM_yyyy)
            
            
        }
    }
    
    //MARK: - update Timer Label
    @objc func updateTimerLabel() {
        if jobModel?.id == UserDefaultHelper.jobIdInProgresss {
            
            self.lblTimer.text = SingleTonTimer.sharedTimer.currenttimeStr
        }
    }

}


