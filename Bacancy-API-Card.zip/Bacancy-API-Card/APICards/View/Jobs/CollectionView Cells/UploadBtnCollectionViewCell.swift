//
//  UploadBtnCollectionViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 09/05/22.
//

import UIKit

class UploadBtnCollectionViewCell: UICollectionViewCell {
    
    var completion : ((_ uploadClicked: Bool) -> Void)?
    
    @IBOutlet weak var uploadBtn: UIButton!
    static let identifier = "UploadBtnCollectionViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    //MARK: - upload Btn Pressed
    @IBAction func uploadBtnPressed(_ sender: UIButton) {
        guard let completion = completion else {
            return
        }
        completion(true)
    }
    
    //MARK: - set Title Of Btn
    func setTitleOfBtn(title: String) {
        uploadBtn.setTitle(title, for: .normal)
    }
}
