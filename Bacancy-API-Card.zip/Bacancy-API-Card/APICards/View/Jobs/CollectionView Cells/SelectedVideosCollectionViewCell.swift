//
//  SelectedVideosCollectionViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 06/05/22.
//

import UIKit
import AVFoundation
 
class SelectedVideosCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var displayView: UIView!
    
    var avQueuePlayer   : AVQueuePlayer?
    var avPlayerLayer   : AVPlayerLayer?
    var player: AVPlayer?
    
    static let identifier = "SelectedVideosCollectionViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    //MARK: - setup cell data
    func setup(url: URL) {
        player = AVPlayer(url: url as URL)
        player?.actionAtItemEnd = .none
        player?.isMuted = true
        
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = displayView.frame
        playerLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        playerLayer.zPosition = -1
        displayView.layer.addSublayer(playerLayer)
        
        player?.play()
        
        // add observer to watch for video end in order to loop video
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(loopVideo),
            name: .AVPlayerItemDidPlayToEndTime,
            object: self.player?.currentItem
        )
    }
    
    // if video ends, will restart
    func playerItemDidReachEnd() {
        player?.seek(to: CMTime.zero)
    }
    
    // add this loop at the end, after viewDidLoad
    @objc func loopVideo() {
        playerItemDidReachEnd()
        player?.play()
    }
}
