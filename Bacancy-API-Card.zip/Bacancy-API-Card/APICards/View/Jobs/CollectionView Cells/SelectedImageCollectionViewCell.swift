//
//  SelectedImageCollectionViewCell.swift
//  APICards
//
//  Created by Harindra Pittalia on 05/05/22.
//

import UIKit
import AVFoundation

class SelectedImageCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageView: UIImageView!
    static let identifier = "SelectedImageCollectionViewCell"
    
    
    static func nib() -> UINib {
        return UINib(nibName: self.identifier, bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    
}
