//
//  ACSummaryBillVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 17/05/22.
//

import UIKit

class ACSummaryBillVC: UIViewController {

    @IBOutlet weak var lblTotalPayableAmount: UILabel!
    @IBOutlet weak var lblDiscount: UILabel!
    @IBOutlet weak var lblTax: UILabel!
    @IBOutlet weak var lblTip: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var lblWorkingHours: UILabel!
    @IBOutlet weak var lblHourlyRate: UILabel!
    
    var jobModel : JobDataNewModel?
    var summaryData: CompanyPaymentData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
    }
    
    @IBAction func checkoutBtnPressed(_ sender: UIButton) {
        
        let aVC = ACPaymentOptionVC.instantiate()
        aVC.jobModel = jobModel
       
        aVC.summaryData = self.summaryData
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
}

//MARK: - ACSummaryBillVC
extension ACSummaryBillVC {
    
    //MARK: - initial Setup
    func initialSetup() {
        //jobModel = JobDataNewModel(id: 1, eventType: "Job", createdDate: "2022-05-17", startTime: "2022-05-17T06:12:14.344Z", endTime: "2022-05-17T06:17:26.491Z", totalInTime: "10:30", job: JobNew(jobID: 19, companyID: 1, name: "Job 6", jobDescription: "Job 6 description", totalRate: 6, hourlyRate: 6, approxHours: "6", status: "Completed"), jobImages: [JobImage(id: 21, jobID: 19, image: "/uploads/job_image/image/21/image1652767933.603376.jpeg", imageType: "BEFORE_START")])
        guard let jobModel = jobModel else { return }
        
        
        //calculation of hours from String
        let timeArray : [String] = jobModel.totalInTime?.components(separatedBy: ":") ?? [String]()
        print(timeArray)
        //minute to hour
        let minutes = Float(timeArray[1]) ?? 0
        print(minutes)
        let minToHour = Float(minutes / 60)
        print(minToHour)
        let hours = Float(timeArray[0]) ?? 0
        let totalHours = hours + minToHour
        print(totalHours)
        var total = Float(jobModel.job?.hourlyRate ?? 0) * totalHours
        total = total.round(to: 2)
        print(total)
        
        let tip: Float = 0
        let tax: Float = 0
        let discount: Float = 0
        
        var totalPayableAmount = total + tip + tax - discount
        totalPayableAmount = totalPayableAmount.round(to: 2)
//
//        summaryData = CompanyPaymentData(invoiceNo: "\(jobModel.job?.id ?? 0)", companyName: "Bacancy Technology", total_amount: total, discount: discount.round(to: 2), total_paid_amount: totalPayableAmount, tips: tip.round(to: 2), tax: tax.round(to: 2), note: "")
        
        lblHourlyRate.text = "\(jobModel.job?.hourlyRate ?? 0)"
        lblWorkingHours.text = jobModel.totalInTime
        lblTotal.text = "\(total)"
        lblTip.text = "\(tip)"
        lblTax.text = "\(tax)"
        lblDiscount.text = "\(discount)"
        lblTotalPayableAmount.text = "\(totalPayableAmount)"
    }
}
