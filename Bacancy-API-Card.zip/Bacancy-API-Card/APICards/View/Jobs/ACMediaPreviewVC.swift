//
//  ACMediaPreviewVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 28/06/22.
//

import UIKit
import SDWebImage
import AVFoundation

class ACMediaPreviewVC: UIViewController {

    @IBOutlet weak var videoView: UIView!
   
    @IBOutlet weak var imageView: UIImageView!
    
    //MARK: - Variables
    var url : URL?
    var avQueuePlayer: AVQueuePlayer?
    var avPlayerLayer: AVPlayerLayer?
    var player: AVPlayer?
    
    //MARK: - Life cycle of view
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if url?.containsImage ?? false {
            setupForImage()
        } else {
            setupForVideo()
        }
    }
    
    //MARK: - Btn click events
    @IBAction func closeBtnPressed(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //MARK: - Other methods
    func setupForImage() {
        videoView.isHidden = true
        imageView.isHidden = false
       
        imageView.sd_setImage(with: url)
    }

    func setupForVideo() {
        videoView.isHidden = false
        videoView.frame = CGRect(x: 0, y: view.frame.height - (videoView.frame.height * 2 + 100), width: self.view.frame.width, height: 400)
        imageView.isHidden = true
        
        setVideoOnView()
    }
    
    func setVideoOnView() {
        guard let url = url else { return }
        player = AVPlayer(url: (url) as URL)
        player?.actionAtItemEnd = .none
        player?.isMuted = true
        
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = videoView.frame
        playerLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        playerLayer.zPosition = -1
        videoView.layer.addSublayer(playerLayer)
        
        player?.play()
        
        // add observer to watch for video end in order to loop video
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(loopVideo),
            name: .AVPlayerItemDidPlayToEndTime,
            object: self.player?.currentItem
        )
    }
    
    // if video ends, will restart
    func playerItemDidReachEnd() {
        player?.seek(to: CMTime.zero)
    }
    
    // add this loop at the end, after viewDidLoad
    @objc func loopVideo() {
        playerItemDidReachEnd()
        player?.play()
    }
}
