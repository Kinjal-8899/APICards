//
//  ACJobHomeVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 27/04/22.
//

import UIKit

class ACJobHomeVC: UIViewController {

    @IBOutlet weak var navBar: UINavigationBar!
    @IBOutlet weak var jobTableView: UITableView!
    
    var jobArray: [JobData] = [JobData]()
    var jobViewModel = JobViewModel()
    
    var chooseDateVC: ACHistoryVC!
    var bgView: UIView!
    var isChooseDateOpen: Bool = false
    var params: Dictionary<String,Any>?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        jobTableView.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func menuBtnPressed(_ sender: UIBarButtonItem) {
        let aVC = ACMenuVC.instantiate()
        self.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func historyBtnPressed(_ sender: UIBarButtonItem) {
//        if self.isChooseDateOpen {
//           hideCDView()
//        } else {
//            showChooseDateView()
//        }
    }
}

//MARK: - ACJobHomeVC
extension ACJobHomeVC {
    
    //MARK: - initial Setup
    func initialSetup() {
        jobTableView.register(JobTableViewCell.nib(), forCellReuseIdentifier: JobTableViewCell.identifier)
        jobTableView.register(ACNoDataTableViewCell.nib(), forCellReuseIdentifier: ACNoDataTableViewCell.identifier)
        jobViewModel.delegate = self
        self.showActivityIndicator()
        params = ["Status" : JobStatus.assigned]
        jobViewModel.getJobList(params: params)
    }
    
    //MARK: - show Choose Date View
//    func showChooseDateView() {
//        self.isChooseDateOpen = true
//        bgView = UIView()
//        bgView.frame = view.frame
//        bgView.backgroundColor = .black
//        bgView.alpha = 0.1
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(hideCDView))
//        bgView.addGestureRecognizer(tapGesture)
//        view.addSubview(bgView)
//
//        self.chooseDateVC = ACHistoryVC.instantiate()
//        print(navBar.frame.origin.y + navBar.frame.height)
//        self.chooseDateVC.view.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.chooseDateVC.mainView.frame.height )
//        self.chooseDateVC.delegate = self
//        self.addChild(self.chooseDateVC)
//        self.view.addSubview(self.chooseDateVC.view)
//    }
    
    //MARK: - Hide Choose Date View
//    @objc func hideCDView() {
//        self.isChooseDateOpen = false
//        self.chooseDateVC.view.removeFromSuperview()
//        self.chooseDateVC.removeFromParent()
//        self.bgView.removeFromSuperview()
//    }
    
}

//MARK: - ACJobHomeVC with ACChooseDateDelegate
//extension ACJobHomeVC: ACChooseDateDelegate {
//    func dateChosen(startDate: String, endDate: String) {
//        hideCDView()
//        self.showActivityIndicator()
//        jobViewModel.getJobListBetweenDates(startDate: startDate, endDate: endDate)
//    }
//
//    func viewHistory() {
//        hideCDView()
//        self.showActivityIndicator()
//        jobViewModel.getJobList()
//    }
//
//}

//MARK: - ACJobHomeVC with UITableViewDelegate, UITableViewDataSource
extension ACJobHomeVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if jobArray.count > 0 {
            return jobArray.count
        } else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if jobArray.count > 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: JobTableViewCell.identifier, for: indexPath) as! JobTableViewCell
            cell.jobModel = jobArray[indexPath.row]
            cell.setup()
            cell.selectionStyle = .none
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: ACNoDataTableViewCell.identifier, for: indexPath) as! ACNoDataTableViewCell
            cell.selectionStyle = .none
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if jobArray.count > 0 {
            return UITableView.automaticDimension
        } else {
            return 100
        }
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        if jobArray.count > 0 {
            return UITableView.automaticDimension
        } else {
            return 100
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let temp = jobArray.filter{ $0.status == JobStatus.inProgress }
        if temp.count > 0 {
            UserDefaultHelper.jobIdInProgresss = temp.first?.id
        } else {
            UserDefaultHelper.jobIdInProgresss = nil
        }
        let aVC = ACJobDetailVC.instantiate()
        aVC.jobId = jobArray[indexPath.row].id
        aVC.jobModel = jobArray[indexPath.row]
        
        self.navigationController?.pushViewController(aVC, animated: true)
    }
}

//MARK: - ACJobHomeVC with JobViewModelDelegate
extension ACJobHomeVC: JobViewModelDelegate {
    
    func didReceiveJobListResponse(jobsResponse: JobModel?) {
        jobArray.removeAll()
        self.hideActivityIndicator()
        if jobsResponse?.data != nil {
            jobArray = jobsResponse?.data ?? [JobData]()
            DispatchQueue.main.async {
                self.jobTableView.isHidden = false
                self.jobTableView.reloadData()
            }
        } else {
            openAlert(title: ACAlertTitle.oops, message: jobsResponse?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [nil])
        }
    }
}

