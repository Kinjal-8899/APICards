//
//  ACMediaVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 09/05/22.
//

import UIKit
import DKImagePickerController
import AVFoundation

class ACMediaVC: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    static let categoryHeaderId = "Categories"
    static let headerId = "headerId"
    
    var arrImage = [UIImage]()
    var arrVideo = [URL]()
    var jobViewModel = JobViewModel()
    var jobId: Int?
    var isStarted: Bool?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        collectionView.collectionViewLayout = createlayout()
    }
    
    @IBAction func backBtnPressed(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
//MARK: - ACMediaVC
extension ACMediaVC {
    
    //MARK: - initial Setup
    func initialSetup() {
        self.collectionView.isHidden = true
        collectionView.register(SelectedImageCollectionViewCell.nib(), forCellWithReuseIdentifier: SelectedImageCollectionViewCell.identifier)
        collectionView.register(SelectedVideosCollectionViewCell.nib(), forCellWithReuseIdentifier: SelectedVideosCollectionViewCell.identifier)
        collectionView.register(UploadBtnCollectionViewCell.nib(), forCellWithReuseIdentifier: UploadBtnCollectionViewCell.identifier)
        collectionView.register(Header.self, forSupplementaryViewOfKind: ACMediaVC.categoryHeaderId, withReuseIdentifier: ACMediaVC.headerId)
        pickMedia()
    }
    
    //MARK: - create layout
    private func createlayout() -> UICollectionViewCompositionalLayout {
        return UICollectionViewCompositionalLayout { (sectionNumber, env) -> NSCollectionLayoutSection? in
            
            if sectionNumber == 0 || sectionNumber == 1 {
                let item = NSCollectionLayoutItem(layoutSize: .init(widthDimension: .fractionalWidth(0.33), heightDimension: .fractionalWidth(0.33)))
                item.contentInsets.trailing = 16
                item.contentInsets.bottom = 16
                
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .estimated(500)), subitems: [item])
                
                let section = NSCollectionLayoutSection(group: group)
                section.contentInsets.leading = 16
                if self.arrImage.count != 0 {
                    section.boundarySupplementaryItems = [NSCollectionLayoutBoundarySupplementaryItem(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .estimated(44)), elementKind: ACMediaVC.categoryHeaderId, alignment: .topLeading)]
                }
                return section
            }
            else if sectionNumber == 1 {
                let item = NSCollectionLayoutItem(layoutSize: .init(widthDimension: .fractionalWidth(0.33), heightDimension: .fractionalWidth(0.33)))
                item.contentInsets.trailing = 16
                item.contentInsets.bottom = 16
                
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .estimated(500)), subitems: [item])
                
                let section = NSCollectionLayoutSection(group: group)
                section.contentInsets.leading = 16
                if self.arrVideo.count != 0 {
                    section.boundarySupplementaryItems = [NSCollectionLayoutBoundarySupplementaryItem(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .estimated(44)), elementKind: ACMediaVC.categoryHeaderId, alignment: .topLeading)]
                }
                return section
            }
            else {
                let item = NSCollectionLayoutItem(layoutSize: .init(widthDimension: .fractionalWidth(1.0), heightDimension: .fractionalHeight(1)))
                item.contentInsets.trailing = 5
                item.contentInsets.bottom = 20
                
                let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(60))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
                
                let section = NSCollectionLayoutSection(group: group)
                section.orthogonalScrollingBehavior = .paging
                
                return section
            }
            
        }
    }
    
    //MARK: - pick Media
    func pickMedia() {
        let pickerController = DKImagePickerController()
        pickerController.maxSelectableCount = 10
        pickerController.didSelectAssets = { (assets: [DKAsset]) in
            print("didSelectAssets")
            print(assets)
            
            for data in assets {
                if data.type == .photo {
                    let screenSize = UIScreen.main.bounds.size
                    data.fetchImage(with: screenSize.toPixel(), completeBlock: { (image, hashable) in
                        DispatchQueue.main.async {
                            if image?.size.width ?? 0 >= 150 {
                                let img = image?.jpegData(compressionQuality: 0.5)
                                self.arrImage.append(UIImage(data: img ?? Data()) ?? UIImage())
                                print(self.arrImage)
                            }
                        }
                    })
                } else if data.type == .video {
                    data.fetchAVAsset(options: .none) { video, info in
                        if let urlAsset = video as? AVURLAsset {
                            let localVideoUrl = urlAsset.url
                            print(localVideoUrl)
                            DispatchQueue.main.async {
                                self.arrVideo.append(localVideoUrl)
                            }
                        }
                    }
                }
            }
            self.showActivityIndicator()
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.collectionView.isHidden = false
                self.hideActivityIndicator()
                self.collectionView.reloadData()
            }
        }
        self.present(pickerController, animated: true)
    }
    
    //MARK: - upload Data
    func uploadData() {
        jobViewModel.delegate = self
        self.showActivityIndicator()
        if isStarted ?? false {
            jobViewModel.startStopJob(jobId: jobId ?? 0, eventName: Event.job, eventType: EventType.outEvent, images: arrImage, videos: arrVideo,image_type: ImageType.afterEnd)
        } else {
            jobViewModel.startStopJob(jobId: jobId ?? 0, eventName: Event.job, eventType: EventType.inEvent, images: arrImage, videos: arrVideo,image_type: ImageType.beforeStart)
        }
    }
    
}

//MARK: - ACMediaVC with UICollectionViewDelegate, UICollectionViewDataSource
extension ACMediaVC : UICollectionViewDelegate, UICollectionViewDataSource{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return arrImage.count
        }
        else if section == 1{
            return arrVideo.count
        } else {
            return 1
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SelectedImageCollectionViewCell.identifier, for: indexPath) as! SelectedImageCollectionViewCell
            cell.imageView.image = arrImage[indexPath.row]
            return cell
        }
        else if indexPath.section == 1  {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SelectedVideosCollectionViewCell.identifier, for: indexPath) as! SelectedVideosCollectionViewCell
            cell.setup(url: arrVideo[indexPath.row])
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: UploadBtnCollectionViewCell.identifier, for: indexPath) as! UploadBtnCollectionViewCell
            if isStarted ?? false {
                cell.setTitleOfBtn(title: "Upload & End")
            } else {
                cell.setTitleOfBtn(title: "Upload & Start")
            }
            cell.completion = { isClicked in
                if isClicked {
                    DispatchQueue.main.async {
                        self.uploadData()
                    }
                    
                }
            }
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: ACMediaVC.headerId, for: indexPath) as! Header
        if indexPath.section == 0 {
            header.setTitle(title: HeaderTitle.photos)
        } else {
            header.setTitle(title: HeaderTitle.videos)
        }
        return header
    }
    
}

//MARK: - ACMediaVC with JobViewModelDelegate
extension ACMediaVC: JobViewModelDelegate {
    func didUpdateJobTomeLog(response: JobNewModel?) {
        self.hideActivityIndicator()
        if response?.data == nil {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                self.navigationController?.popViewController(animated: true)
            }])
        } else {
            if isStarted ?? false {
//                self.tabBarController?.selectedIndex = 2
                SingleTonTimer.sharedTimer.stopGlobalTimer()
                let aVC = ACSummaryBillVC.instantiate()
                aVC.jobModel = response?.data
                self.navigationController?.pushViewController(aVC, animated: true)
            } else {
                SingleTonTimer.sharedTimer.startGlobalTimer()
                UserDefaultHelper.jobIdInProgresss = jobId
                let aVC = ACJobHomeVC.instantiate()
                self.navigationController?.pushViewController(aVC, animated: true)
            }
        }
    }
}
