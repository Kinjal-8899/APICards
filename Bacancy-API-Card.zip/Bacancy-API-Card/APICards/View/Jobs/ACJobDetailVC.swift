//
//  ACJobDetailVC.swift
//  APICards
//
//  Created by Harindra Pittalia on 04/05/22.
//

import UIKit
import DKImagePickerController
import AVFoundation
import SDWebImage

class ACJobDetailVC: UIViewController {

    var jobId: Int?
    var jobModel: JobData?
    static let categoryHeaderId = "Categories"
    static let headerId = "headerId"
    var jobViewModel = JobViewModel()
    
    @IBOutlet weak var paymentStackView: UIStackView!
    @IBOutlet weak var afterJobView: UIView!
    @IBOutlet weak var beforeJobView: UIView!
    @IBOutlet weak var btnBreak: UIButton!
    
    @IBOutlet weak var btnJob: UIButton!
    @IBOutlet weak var nav: UINavigationItem!
    @IBOutlet weak var lblJobDesc: UILabel!
  
    @IBOutlet weak var beforeJobCollectionView: UICollectionView!
    @IBOutlet weak var beforeJobCVHeight: NSLayoutConstraint!
    
    @IBOutlet weak var afterJobCVHeight: NSLayoutConstraint!
    @IBOutlet weak var afterJobCollectionView: UICollectionView!
    
    var beforeJobImageArray = [URL]()
    var beforeJobVideoArray = [URL]()
    var afterJobImageArray = [URL]()
    var afterJobVideoArray = [URL]()
    
    var isStarted : Bool!
    var isInBreak : Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    @IBAction func backBtnPressed(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK: - Start/Stop Job Btn Pressed
    @IBAction func jobBtnPressed(_ sender: UIButton) {
        
        if isStarted {
            openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.beforeEndJobSelect, alertStyle: .alert, actionTitles: [ACAlertTitle.ok, ACAlertTitle.cancel], actionStyles: [.default, .cancel], actions: [{
                _ in
                let aVC = ACMediaVC.instantiate()
                aVC.jobId = self.jobId
                aVC.isStarted = true
                self.navigationController?.pushViewController(aVC, animated: true)
            }, nil])
        } else {
            
            
            if UserDefaultHelper.jobIdInProgresss != nil {
                openAlert(title: ACAlertTitle.oops, message: "Your one job is running, can't start another.If you want to start this job then end/pause previous job.", alertStyle: .alert, actionTitles: [ACAlertTitle.cancel, ACAlertTitle.gotoPrevious], actionStyles: [.cancel, .default], actions: [nil, { _ in
                    
                    self.jobId = UserDefaultHelper.jobIdInProgresss
                    self.getJobDetails(jobId: UserDefaultHelper.jobIdInProgresss ?? 0)
                }])
            } else {
                openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.beforeStartJobSelect, alertStyle: .alert, actionTitles: [ACAlertTitle.ok, ACAlertTitle.cancel], actionStyles: [.default, .cancel], actions: [{
                    _ in
                    let aVC = ACMediaVC.instantiate()
                    aVC.jobId = self.jobId
                    aVC.isStarted = false
                    self.navigationController?.pushViewController(aVC, animated: true)
                }, nil])
            }
        }
    }
    
    //MARK: - Break In/Out Btn Pressed
    @IBAction func breakBtnPressed(_ sender: UIButton) {
        self.showActivityIndicator()
        
        if isInBreak {
            SingleTonTimer.sharedTimer.resumeTimer()
            openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.breakTimeStop, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [ {
                _ in
                
                self.jobViewModel.breakInOut(jobId: self.jobModel?.id ?? 0, eventName: Event.inBreak, eventType: EventType.outEvent)
            }])
        } else {
            SingleTonTimer.sharedTimer.pauseTimer()
            openAlert(title: ACAlertTitle.alert, message: ACAlertMessage.breakTimeStart, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [ {
                _ in
                self.jobViewModel.breakInOut(jobId: self.jobModel?.id ?? 0, eventName: Event.inBreak, eventType: EventType.inEvent)
              
            }])
        }
    }
    
}

//MARK: - ACJobDetailVC
extension ACJobDetailVC {
    
    //MARK: - initial Setup
    func initialSetup() {
        jobViewModel.delegate = self
        setupUI(jobModel: jobModel!)
        registerCells()
        DispatchQueue.main.async {
            self.reloadingCollectionView()
        }
    }
    
    //MARK: - get Job Details
    func getJobDetails(jobId: Int) {
        self.showActivityIndicator()
        jobViewModel.getJobDetail(jobId: jobId)
    }
    
    //MARK: - setup UI
    func setupUI(jobModel: JobData) {
        nav.title = jobModel.name
        lblJobDesc.text = jobModel.datumDescription
        if jobModel.status == JobStatus.assigned {
            setupForAssigned()
        }
        else if jobModel.status == JobStatus.inProgress {
            setupForJobStarted()
        }
        else if jobModel.status == JobStatus.inBreak {
            setupForBreakIn()
        }
        else if jobModel.status == JobStatus.completed {
            setupForJobCompleted()
        } else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    //MARK: - register Cells
    func registerCells() {
        beforeJobCollectionView.register(SelectedImageCollectionViewCell.nib(), forCellWithReuseIdentifier: SelectedImageCollectionViewCell.identifier)
        beforeJobCollectionView.register(SelectedVideosCollectionViewCell.nib(), forCellWithReuseIdentifier: SelectedVideosCollectionViewCell.identifier)
        beforeJobCollectionView.register(Header.self, forSupplementaryViewOfKind: ACMediaVC.categoryHeaderId, withReuseIdentifier: ACMediaVC.headerId)
        
        afterJobCollectionView.register(SelectedImageCollectionViewCell.nib(), forCellWithReuseIdentifier: SelectedImageCollectionViewCell.identifier)
        afterJobCollectionView.register(SelectedVideosCollectionViewCell.nib(), forCellWithReuseIdentifier: SelectedVideosCollectionViewCell.identifier)
        afterJobCollectionView.register(Header.self, forSupplementaryViewOfKind: ACMediaVC.categoryHeaderId, withReuseIdentifier: ACMediaVC.headerId)
        
        if jobModel?.jobImages?.count ?? 0 > 0 {
        for i in 0..<(jobModel?.jobImages!.count)! {
            let url: URL = URL(string: (jobModel?.jobImages?[i].image)!)!
            if jobModel?.jobImages?[i].imageType == ImageType.beforeStart {
                if url.containsImage {
                    beforeJobImageArray.append(URL(string: "\(APIUrls.imageBaseURL)\(url)")!)
                } else {
                    beforeJobVideoArray.append(URL(string: "\(APIUrls.imageBaseURL)\(url)")!)
                }
            } else {
                if url.containsImage {
                    afterJobImageArray.append(URL(string: "\(APIUrls.imageBaseURL)\(url)")!)
                } else {
                    afterJobVideoArray.append(URL(string: "\(APIUrls.imageBaseURL)\(url)")!)
                }
            }
        }
        }

        beforeJobCollectionView.collectionViewLayout = createlayout(arrImage: beforeJobImageArray, arrVideo: beforeJobVideoArray)
        afterJobCollectionView.collectionViewLayout = createlayout(arrImage: afterJobImageArray, arrVideo: afterJobVideoArray)
        
    }
    
    //MARK: - reloadingCollectionView
    func reloadingCollectionView() {
        var height = self.beforeJobCollectionView.collectionViewLayout.collectionViewContentSize.height
        self.beforeJobCVHeight.constant = height
        
        height = self.afterJobCollectionView.collectionViewLayout.collectionViewContentSize.height
        self.afterJobCVHeight.constant = height
    }
    
    //MARK: - Setup for different job status
    func setupForAssigned() {
        paymentStackView.isHidden = true
        isStarted = false
        isInBreak = false
        btnBreak.isHidden = true
        btnJob.isHidden = false
        beforeJobView.isHidden = true
        afterJobView.isHidden = true
        btnJob.setTitle("Start Job", for: .normal)
        btnBreak.setTitle("Break In", for: .normal)
    }
    
    func setupForJobStarted() {
        paymentStackView.isHidden = true
        isStarted = true
        isInBreak = false
        btnBreak.isHidden = false
        btnJob.isHidden = false
        beforeJobView.isHidden = false
        afterJobView.isHidden = true
        btnJob.setTitle("End Job", for: .normal)
        btnBreak.setTitle("Break In", for: .normal)
    }
    
    func setupForJobCompleted() {
        paymentStackView.isHidden = false
        isStarted = false
        isInBreak = false
        btnBreak.isHidden = true
        btnJob.isHidden = true
        beforeJobView.isHidden = false
        afterJobView.isHidden = false
        btnJob.setTitle("Start Job", for: .normal)
        btnBreak.setTitle("Break In", for: .normal)
    }
    
    func setupForBreakIn() {
        paymentStackView.isHidden = true
        isStarted = true
        isInBreak = true
        btnBreak.isHidden = false
        btnJob.isHidden = false
        beforeJobView.isHidden = false
        afterJobView.isHidden = true
        btnJob.setTitle("End Job", for: .normal)
        btnBreak.setTitle("Break Out", for: .normal)
    }
}

//MARK: - ACJobDetailVC with JobViewModelDelegate
extension ACJobDetailVC: JobViewModelDelegate {
    func didUpdateJobTomeLog(response : JobNewModel?) {
        self.hideActivityIndicator()
        if response?.data == nil {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                
                self.navigationController?.popViewController(animated: true)
            }])
        } else {
            
            self.getJobDetails(jobId: self.jobId ?? 0)
            let aVC = ACJobHomeVC.instantiate()
            self.navigationController?.pushViewController(aVC, animated: true)
        }
    }
    
    func didUpdateBreakData(response: JobNewModel?) {
        self.hideActivityIndicator()
        if response?.data == nil {
            openAlert(title: ACAlertTitle.oops, message: response?.message ?? ACAlertMessage.internalError, alertStyle: .alert, actionTitles: [ACAlertTitle.ok], actionStyles: [.default], actions: [{ _ in
                self.navigationController?.popViewController(animated: true)
            }])
        } else {
            self.getJobDetails(jobId: self.jobId ?? 0)
        }
    }
    
    func didReceiveJobDetails(response: JobData?) {
        DispatchQueue.main.async {
            self.hideActivityIndicator()
            self.setupUI(jobModel: (response!))
        }
    }
}

//MARK: - ACJobDetailVC with UICollectionViewDelegate, UICollectionViewDataSource
extension ACJobDetailVC:  UICollectionViewDelegate, UICollectionViewDataSource{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == beforeJobCollectionView {
            if section == 0 {
                return beforeJobImageArray.count
            }
            else {
                return beforeJobVideoArray.count
            }
        } else {
            if section == 0 {
                return afterJobImageArray.count
            }
            else {
                return afterJobVideoArray.count
            }
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == beforeJobCollectionView {
            if indexPath.section == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SelectedImageCollectionViewCell.identifier, for: indexPath) as! SelectedImageCollectionViewCell
                cell.imageView.sd_setImage(with: beforeJobImageArray[indexPath.row])
                return cell
            }
            else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SelectedVideosCollectionViewCell.identifier, for: indexPath) as! SelectedVideosCollectionViewCell
                cell.setup(url: beforeJobVideoArray[indexPath.row])
                return cell
            }
        } else {
            if indexPath.section == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SelectedImageCollectionViewCell.identifier, for: indexPath) as! SelectedImageCollectionViewCell
                cell.imageView.sd_setImage(with: afterJobImageArray[indexPath.row])
                return cell
            }
            else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SelectedVideosCollectionViewCell.identifier, for: indexPath) as! SelectedVideosCollectionViewCell
                cell.setup(url: afterJobVideoArray[indexPath.row])
                return cell
            }
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: ACMediaVC.headerId, for: indexPath) as! Header
        if indexPath.section == 0 {
            header.setTitle(title: HeaderTitle.photos)
        } else {
            header.setTitle(title: HeaderTitle.videos)
        }
        return header
    }
    
    //setup collection view
    private func createlayout(arrImage: [URL], arrVideo : [URL]) -> UICollectionViewCompositionalLayout {
        return UICollectionViewCompositionalLayout { (sectionNumber, env) -> NSCollectionLayoutSection? in
            
            let item = NSCollectionLayoutItem(layoutSize: .init(widthDimension: .fractionalWidth(0.33), heightDimension: .fractionalWidth(0.33)))
            item.contentInsets.trailing = 16
            item.contentInsets.bottom = 16
            
            let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .estimated(500)), subitems: [item])
            
            let section = NSCollectionLayoutSection(group: group)
            section.contentInsets.leading = 16
            if arrImage.count != 0 {
                section.boundarySupplementaryItems = [NSCollectionLayoutBoundarySupplementaryItem(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .estimated(44)), elementKind: ACMediaVC.categoryHeaderId, alignment: .topLeading)]
            }
            return section
        }
    }
    
}



