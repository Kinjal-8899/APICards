//
//  PaymentResource.swift
//  APICards
//
//  Created by Harindra Pittalia on 17/05/22.
//

import Foundation

//MARK: - Payment Resource
struct PaymentResource {
    
    //MARK: - makePayment with Parameters
    func makePayment(params: Dictionary<String,Any>,completion: @escaping (_ result: PaymentModel) -> Void) {
        
        CommonWS.PostURL(url: APIUrls.paymentAPI, dict: params) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobs = try JSONDecoder().decode(PaymentModel.self, from: data!)
                    completion(jobs)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(PaymentModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
        
    }
    
    //MARK: - get Transaction list
    func getTransactionlist(completion: @escaping (_ result: TransactionModel) -> Void) {
        CommonWS.GetURLWithoutParameter(url: APIUrls.paymentList) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobData = try JSONDecoder().decode(TransactionModel.self, from: data!)
                    completion(jobData)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(TransactionModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
    //MARK: - get Transaction list Between Dates
    func getTransactionlistBetweenDates(startDate: String, endDate: String, completion: @escaping (_ result: TransactionModel) -> Void) {
        
        let params: Dictionary<String, Any> = ["start_date" : startDate,
                                               "end_date" : endDate]
        CommonWS.GetURLWithParameter(url: APIUrls.paymentList, dict: params) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobs = try JSONDecoder().decode(TransactionModel.self, from: data!)
                    completion(jobs)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(TransactionModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
}
