//
//  JobResource.swift
//  APICards
//
//  Created by Harindra Pittalia on 04/05/22.
//

import Foundation
import UIKit

//MARK: - Job Resource
struct JobResource {
    
    //MARK: - get Job List
    func getJobList(completion: @escaping (_ result: JobModel) -> Void) {
        CommonWS.GetURLWithoutParameter(url: APIUrls.getJobs) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobs = try JSONDecoder().decode(JobModel.self, from: data!)
                    completion(jobs)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(JobModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
    
    //MARK: - get Job List Between Dates
    func getJobListData(params: Dictionary<String,Any>?, completion: @escaping (_ result: JobModel) -> Void) {
        
       // let params: Dictionary<String, Any> = ["start_date" : startDate,"end_date" : endDate]
        CommonWS.GetURLWithParameter(url: APIUrls.getJobs, dict: params ?? [:]) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobs = try JSONDecoder().decode(JobModel.self, from: data!)
                    completion(jobs)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(JobModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
    //MARK: - get Job Details
    func getJobDetails(jobId: Int, completion: @escaping (_ result: JobData?) -> Void) {
        let params: Dictionary<String, Any> = ["job_id" : "\(jobId)"]
        CommonWS.GetURLWithParameter(url: APIUrls.getJobDetail, dict: params) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData["data"]!, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobs = try JSONDecoder().decode(JobData.self, from: data!)
                    completion(jobs)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                
            }
        }
    }
     
    //MARK: - start Stop Job
    func startStopJob(jobId: Int, eventName: String, eventType: String, images: [UIImage], videos: [URL], image_type: String, completion: @escaping (_ result: JobData?) -> Void) {
        let params: Dictionary<String, Any> = ["job_id" : "\(jobId)",
                      "event_type" : eventName,
                      "type" : eventType,
                     "image_type": image_type]
       
        CommonWS.PostURLWithMultipart(url: APIUrls.updateJobTimeLog, dict: params, imageData: images, videoData: videos, imageParameter: "image[]") { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData["data"]!, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let updatedJob = try JSONDecoder().decode(JobData.self, from: data!)
                    completion(updatedJob)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
               
            }
        }
    }
    
    //MARK: - break In Out Job
    func breakInOut(jobId: Int, eventName: String, eventType: String, completion: @escaping (_ result: JobData?) -> Void) {
        let params: Dictionary<String, Any> = ["job_id" : "\(jobId)",
                      "event_type" : eventName,
                      "type" : eventType]
        
        CommonWS.PostURLWithMultipart(url: APIUrls.updateJobTimeLog, dict: params, imageData: nil, videoData: nil, imageParameter: nil) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData["data"]!, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let updatedJob = try JSONDecoder().decode(JobData.self, from: data!)
                    completion(updatedJob)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                
            }
        }
    }
    
    func getTodayJobs(completion: @escaping (_ result: TodayJobModel?) -> Void) {
        CommonWS.GetURLWithoutParameter(url: APIUrls.getTodayJobData) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobData = try JSONDecoder().decode(TodayJobModel.self, from: data!)
                    completion(jobData)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(TodayJobModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
    func getBetweenJobsData(startDate: String, endDate: String, completion: @escaping (_ result: TodayJobModel?) -> Void) {
        
        let params: Dictionary<String, Any> = ["start_date" : startDate,
                                               "end_date" : endDate]
        CommonWS.GetURLWithParameter(url: APIUrls.getTodayJobData, dict: params) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobData = try JSONDecoder().decode(TodayJobModel.self, from: data!)
                    completion(jobData)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(TodayJobModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
    func cancelJob(jobId: Int, companyId: Int, completion: @escaping (_ result: JobData?) -> Void) {
        let params: Dictionary<String, Any> = ["job_id" : jobId,
                                               "company_id" : companyId]
        CommonWS.PostURL(url: APIUrls.cancelJob, dict: params) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData["data"]!, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let user = try JSONDecoder().decode(JobData.self, from: data!)
                    completion(user)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                
            }
        }
    }
    
}
