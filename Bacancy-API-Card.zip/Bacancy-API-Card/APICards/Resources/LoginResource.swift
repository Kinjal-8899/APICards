//
//  LoginResource.swift
//  APICards
//
//  Created by Harindra Pittalia on 11/04/22.
//

import Foundation

//MARK: - Login Resource
struct LoginResource
{
    //MARK: - login User with login request
    func loginUser(loginRequest: LoginRequest, completion : @escaping (_ result: LoginResponse?) -> Void)
    {
        let dict = loginRequest.structToDict()
        
        CommonWS.PostURL(url: APIUrls.login, dict: dict) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let user = try JSONDecoder().decode(LoginResponse.self, from: data!)
                    completion(user)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(LoginResponse(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
}
