//
//  LogoutResource.swift
//  APICards
//
//  Created by Harindra Pittalia on 14/04/22.
//

import Foundation

//MARK: - Logout Resource
struct LogoutResource {
    
    //MARK: - logout User
    func logoutUser(email: String, completion: @escaping (_ result: LogoutModel?) -> Void) {
        
        let dict = ["email": email]
        
        CommonWS.PostURL(url: APIUrls.logout, dict: dict) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let user = try JSONDecoder().decode(LogoutModel.self, from: data!)
                    completion(user)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                
                completion(LogoutModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
}
