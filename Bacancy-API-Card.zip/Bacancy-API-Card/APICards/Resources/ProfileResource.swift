//
//  ProfileResource.swift
//  APICards
//
//  Created by Harindra Pittalia on 29/06/22.
//

import Foundation

struct ProfileResource {
    
    
    func getUserData(userId: Int, completion: @escaping (_ result: LoginResponse) -> Void) {
        let params: Dictionary<String, Any> = ["user_id": userId]
        CommonWS.GetURLWithParameter(url: APIUrls.userProfile, dict: params) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobs = try JSONDecoder().decode(LoginResponse.self, from: data!)
                    completion(jobs)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(LoginResponse(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
    func getReportslist(completion: @escaping (_ result: ReportsModel) -> Void) {
        CommonWS.GetURLWithoutParameter(url: APIUrls.reportsList) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobData = try JSONDecoder().decode(ReportsModel.self, from: data!)
                    completion(jobData)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(ReportsModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
    func getReportslistBetweenDates(startDate: String, endDate: String, completion: @escaping (_ result: ReportsModel) -> Void) {
        
        let params: Dictionary<String, Any> = ["start_date" : startDate,
                                               "end_date" : endDate]
        CommonWS.GetURLWithParameter(url: APIUrls.reportsList, dict: params) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobs = try JSONDecoder().decode(ReportsModel.self, from: data!)
                    completion(jobs)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(ReportsModel(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
    }
    
    //MARK: - makePayment with Parameters
    func setAppPermission(params: Dictionary<String,Any>,completion: @escaping (_ result: LoginResponse) -> Void) {
        
        CommonWS.PostURL(url: APIUrls.userPermission, dict: params) { responseData, success in
            if success {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: responseData, options: .prettyPrinted)
                    let reqJSONStr = String(data: jsonData, encoding: .utf8)
                    let data = reqJSONStr?.data(using: .utf8)
                    let jobs = try JSONDecoder().decode(LoginResponse.self, from: data!)
                    completion(jobs)
                } catch  {
                    print(error.localizedDescription)
                }
            } else {
                completion(LoginResponse(data: nil, type: responseData["type"] as? String, status: responseData["status"] as? Int, message: responseData["message"] as? String))
            }
        }
        
    }
    
    
    
}
