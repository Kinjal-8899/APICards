//
//  LogoutModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 14/04/22.
//

import Foundation

//MARK: - LogoutModel
struct LogoutModel: Decodable {
    let data: LogoutData?
    let type: String?
    let status: Int?
    let message: String?
}

struct LogoutData: Decodable {
    
}
