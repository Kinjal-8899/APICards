//
//  TransactionModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 25/05/22.
//

import Foundation

// MARK: - TransactionModel
struct TransactionModel: Codable {
    let data: [TransactionData]?
    let type: String?
    let status: Int?
    let message: String?
}

// MARK: - Datum
struct TransactionData: Codable {
    let id, companyID: Int?
    let totalAmount: Double?
    let discount: Int?
    let totalPaidAmount: Double?
    let tips, tax: Int?
    let note, transactionID: String?
    let cardType: String?
    let cardHolderName, cardNumber, paymentType, createdAt: String?
    let job: Job?
    let company: String?

    enum CodingKeys: String, CodingKey {
        case id
        case companyID = "company_id"
        case totalAmount = "total_amount"
        case discount
        case totalPaidAmount = "total_paid_amount"
        case tips, tax, note
        case transactionID = "transaction_id"
        case cardType = "card_type"
        case cardHolderName = "card_holder_name"
        case cardNumber = "card_number"
        case paymentType = "payment_type"
        case createdAt = "created_at"
        case job, company
    }
}
