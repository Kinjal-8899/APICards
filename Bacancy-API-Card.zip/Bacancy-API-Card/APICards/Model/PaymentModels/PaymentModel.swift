//
//  PaymentModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 17/05/22.
//

import Foundation

//MARK: - PaymentModel
struct PaymentModel: Codable {
    let data: PaymentData?
        let type: String?
        let status: Int?
        let message: String?
}

//MARK: - PaymentData
struct PaymentData: Codable {
    let id, companyID: Int?
    let totalPaidAmount, tips, tax, totalAmount, discount: Float?
    let note: String?
    let transactionID, cardType, cardHolderName, cardNumber: String?
    let paymentType: String?
    let job: Job?

    enum CodingKeys: String, CodingKey {
        case id
        case companyID = "company_id"
        case totalAmount = "total_amount"
        case discount
        case totalPaidAmount = "total_paid_amount"
        case tips, tax, note
        case transactionID = "transaction_id"
        case cardType = "card_type"
        case cardHolderName = "card_holder_name"
        case cardNumber = "card_number"
        case paymentType = "payment_type"
        case job
    }
}

// MARK: - Job
struct Job: Codable {
    let jobID: Int?
    let name, jobDescription: String?
    let totalRate, hourlyRate: Int?
    let approxHours, status: String?

    enum CodingKeys: String, CodingKey {
        case jobID = "job_id"
        case name
        case jobDescription = "description"
        case totalRate = "total_rate"
        case hourlyRate = "hourly_rate"
        case approxHours = "approx_hours"
        case status
    }
}

// MARK: - PaymentType
enum PaymentType {
    static var card = "Card"
    static var manualCard = "ManualCard"
    static var cash = "Cash"
    static var applePay = "ApplePay"
    static var gPay = "Gpay"
}

// MARK: - CompanyPaymentData
struct CompanyPaymentData {
    let jobId, companyID: Int?
    var companyName: String?
    var total_amount, discount, total_paid_amount, tips, tax : Float?
    var note: String?
    var jobName: String?
}

