//
//  JobModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 04/05/22.
//

import Foundation

// MARK: - JobModel
struct JobModel: Codable {
    let data: [JobData]?
    let type: String?
    let status: Int?
    let message: String?
}

// MARK: - JobData
struct JobData: Codable {
    let id, companyID: Int?
    let companyName: String?
    let name, datumDescription: String?
    let totalRate, hourlyRate: Int?
    let approxHours: String?
    let status: String?
    let startTime, endTime: String?
    let totalInTime, createdAt, jobFinishDatetime, jobCancelledDatetime: String?
    let jobImages: [JobImage]?
    let paymentDetails: PaymentDetails?
    
    enum CodingKeys: String, CodingKey {
        case id, name
        case companyName = "company_name"
        case companyID = "company_id"
        case datumDescription = "description"
        case totalRate = "total_rate"
        case hourlyRate = "hourly_rate"
        case approxHours = "approx_hours"
        case status
        case startTime = "start_time"
        case endTime = "end_time"
        case totalInTime = "total_in_time"
        case jobFinishDatetime = "job_finish_datetime"
        case jobCancelledDatetime = "job_cancelled_datetime"
        case createdAt = "created_at"
        case jobImages = "job_images"
        case paymentDetails = "payment_details"
    }
}

// MARK: - JobImage
struct JobImage: Codable {
    let id, jobID: Int?
    let image, imageType: String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case jobID = "job_id"
        case image
        case imageType = "image_type"
    }
}

// MARK: - PaymentDetails
struct PaymentDetails: Codable {
    let id, jobID, companyID: Int?
    let totalAmount: Double?
    let discount: Int?
    let totalPaidAmount: Double?
    let tips, tax: Int?
    let note, transactionID: String?
    let cardType: String?
    let cardHolderName, cardNumber, paymentType, createdAt: String?
    let updatedAt: String?

    enum CodingKeys: String, CodingKey {
        case id
        case jobID = "job_id"
        case companyID = "company_id"
        case totalAmount = "total_amount"
        case discount
        case totalPaidAmount = "total_paid_amount"
        case tips, tax, note
        case transactionID = "transaction_id"
        case cardType = "card_type"
        case cardHolderName = "card_holder_name"
        case cardNumber = "card_number"
        case paymentType = "payment_type"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
}

// MARK: - Job Events
enum Event {
    static var job: String { return "Job"}
    static var inBreak: String { return "Break"}
}
enum EventType {
    static var inEvent: String { return "In"}
    static var outEvent: String { return "Out"}
}

enum ImageType {
    static var beforeStart: String { return "BEFORE_START"}
    static var afterEnd: String { return "AFTER_END"}
}

enum JobStatus {
    static let assigned = "Assigned" 
    static let inProgress = "In_Progress"
    static let inBreak = "Break_IN"
    static let completed = "Completed"
    static let inReview = "In_Review"
    static let cancelled = "Cancelled"
}

 // MARK: - JobNewModel
struct JobNewModel: Codable {
    let data: JobDataNewModel?
    let type: String?
    let status: Int?
    let message: String?
}

struct JobDataNewModel: Codable {
    let id: Int?
    let eventType, createdDate, startTime, endTime: String?
    let totalInTime: String?
    let job: JobNew?
    let jobImages: [JobImage]?
    
    enum CodingKeys: String, CodingKey {
        case id
        case eventType = "event_type"
        case createdDate = "created_date"
        case startTime = "start_time"
        case endTime = "end_time"
        case totalInTime = "total_in_time"
        case job
        case jobImages = "job_images"
    }
    
}

struct JobNew: Codable {
    let id, companyID: Int?
    let name, jobDescription: String?
    let totalRate, hourlyRate: Int?
    let approxHours, status: String?
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case companyID = "company_id"
        case name
        case jobDescription = "description"
        case totalRate = "total_rate"
        case hourlyRate = "hourly_rate"
        case approxHours = "approx_hours"
        case status
    }
}

// MARK: - JobCountModel
struct TodayJobModel: Codable {
    let data: TodayJobData?
    let type: String?
    let status: Int?
    let message: String?
}

// MARK: - DataClass
struct TodayJobData: Codable {
    let todayRemainingJobs, todayCompletedJobs, totalJobsDone: Int
    let todayPayment, totalPayment: String
    
    enum CodingKeys: String, CodingKey {
        case todayRemainingJobs = "today_remaining_jobs"
        case todayCompletedJobs = "today_completed_jobs"
        case totalJobsDone = "total_jobs_done"
        case todayPayment = "today_payment"
        case totalPayment = "total_payment"
    }
}


//// MARK: - JobDetailModel
//struct JobDetailModel: Codable {
//    let data: JobDetailData?
//    let type: String?
//    let status: Int?
//    let message: String?
//}
//
//// MARK: - JobDetailData
//struct JobDetailData: Codable {
//    let id, companyID: Int?
//    let name, dataDescription: String?
//    let totalRate, hourlyRate: Int?
//    let approxHours, status, startTime, endTime: String?
//    let totalInTime: String?
//    let jobImages: [JobImage]?
//
//    enum CodingKeys: String, CodingKey {
//        case id
//        case companyID = "company_id"
//        case name
//        case dataDescription = "description"
//        case totalRate = "total_rate"
//        case hourlyRate = "hourly_rate"
//        case approxHours = "approx_hours"
//        case status
//        case startTime = "start_time"
//        case endTime = "end_time"
//        case totalInTime = "total_in_time"
//        case jobImages = "job_images"
//    }
//}
