//
//  ReportsModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 29/06/22.
//

import Foundation

// MARK: - ReportsModel
struct ReportsModel: Codable {
    let data: [ReportsData]?
    let type: String?
    let status: Int?
    let message: String?
}

// MARK: - ReportsData
struct ReportsData: Codable {
    
    let date: String
    let jobsCount, totalPayment: Int
    
    enum CodingKeys: String, CodingKey {
        case date
        case jobsCount = "jobs_count"
        case totalPayment = "total_payment"
    }
}
