//
//  ViewController.swift
//  API Cards
//
//  Created by Harindra Pittalia on 20/06/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

