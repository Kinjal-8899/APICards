//
//  ACDashboardVC.swift
//  API Cards
//
//  Created by Harindra Pittalia on 20/06/22.
//

import UIKit

class ACDashboardVC: UIViewController {

    @IBOutlet weak var tblViewHeight: NSLayoutConstraint!
    @IBOutlet weak var upcomingTableView: UITableView!
    
    var isViewAll: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        initialSetup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    
    @IBAction func viewAllBtnClicked(_ sender: UIButton) {
        isViewAll = !isViewAll
        DispatchQueue.main.async {
            self.upcomingTableView.reloadData()
        }
    }
    
}

//MARK: - ACDashboardVC
extension ACDashboardVC {
    
    //MARK: - initial Setup
    func initialSetup() {
        upcomingTableView.register(ACUpcomingTVCell.nib(), forCellReuseIdentifier: ACUpcomingTVCell.identifier)
    }
}


//MARK: - ACDashboardVC with UITableViewDelegate, UITableViewDataSource
extension ACDashboardVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isViewAll {
            return 20
        } else {
            return 5
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: ACUpcomingTVCell.identifier, for: indexPath) as! ACUpcomingTVCell
        cell.selectionStyle = .none
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        tblViewHeight.constant = tableView.contentSize.height
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
