//
//  Date+Extension.swift
//  APICards
//
//  Created by Harindra Pittalia on 21/04/22.
//

import Foundation

//MARK: - DateFormate
enum DateFormate: String {
    case yyyy_MM_dd_HH_MM_SS_Z = "yyyy-MM-dd HH:mm:ss Z"
    case yyyy_MM_dd_T_HH_MM_SS_Z = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    case dd_MM_yyyy_hh_mm_a = "dd/MM/yyyy hh:mm a"
    case dd_MMM_yyyy = "dd-MMM-yyyy"
    case hh_mm_a = "hh:mm a"
    case hh_mm_A = "hh:mm A"
    case MM_dd_yyyy_hh_mm_a = "MM/dd/yyyy hh:mm a"
    case yyyy_MM_dd = "yyyy-MM-dd"
    case MM_dd_yyyy = "MM/dd/yyyy"
    case dd_MM_yyyy = "dd/MM/yyyy"
    case yyyy_MM_dd_hh_mm_a = "yyyy-MM-dd hh:mm a"
    
    case d_MMM_yyyy = "d MMM. yyyy, hh:mma"
    case d_dd_mmmm = "EEEE, d MMMM"
    case d_MMM = "d MMM."
    case d_MMM_YYYY = "d MMM. YYYY"
    
    case YYYY_MM_DD = "YYYY-MM-dd"
    case yy = "yy"
    case MM = "MM"
    case MM_DD = "MMM dd"
    case MMMM = "MMMM"
    case DD_MM_HH_MM_A = "MM/dd hh:mm a"
}

//MARK: - extension Float
extension Float {
    func round(to places: Int) -> Float {
        let divisor  = pow(10.0, Float(places))
        return (self * divisor).rounded() / divisor
    }
}

//MARK: - extension String
extension String {
    func changeDateFormateToUTC(fromFormat: DateFormate = .yyyy_MM_dd_T_HH_MM_SS_Z, toFormat: DateFormate = .d_MMM_yyyy) -> String?
    {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = fromFormat.rawValue
        dateformatter.calendar = Calendar.current
        dateformatter.timeZone = TimeZone.current
        dateformatter.amSymbol = "am"
        dateformatter.pmSymbol = "pm"
        
        if let date = dateformatter.date(from: self)
        {
            dateformatter.timeZone = TimeZone(abbreviation: "UTC")
            dateformatter.dateFormat = toFormat.rawValue
            let strDate = dateformatter.string(from: date)
            return strDate
        }
        return ""
    }
    func UTCToLocal(fromFormat: DateFormate, toFormat: DateFormate) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = fromFormat.rawValue
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        let dt = dateFormatter.date(from: self)
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = toFormat.rawValue
        
        return dateFormatter.string(from: dt!)
    }
    
    func changeDateFormat(fromFormat: DateFormate?,toFormat: DateFormate?) -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = fromFormat?.rawValue
        dateformatter.calendar = Calendar.current
        dateformatter.timeZone = TimeZone.current
        
        if let date = dateformatter.date(from: self)
        {
            dateformatter.dateFormat = toFormat?.rawValue
            let strDate = dateformatter.string(from: date)
            return strDate
        }
        return ""
    }
    
    static func getCurrentDateStr() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = DateFormate.d_dd_mmmm.rawValue
        return dateFormatter.string(from: Date())
    }
    
    func getNewJobStatus() -> String {
       //  "Assigned","In_Progress","Break_IN","Completed","In_Review","Cancelled"
        if self == JobStatus.assigned {
            return "Upcoming"
        } else if self == JobStatus.cancelled {
            return "Cancelled"
        } else if self == JobStatus.inProgress {
            return "Ongoing"
        } else if self == JobStatus.inBreak {
            return "In Break"
        } else if self == JobStatus.completed {
            return "Completed"
        } else if self == JobStatus.inReview {
            return "In Review"
        } else {
            return ""
        }
    }
}

//MARK: - extension Date
extension Date
{
    func toString(formateType type: DateFormate) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = type.rawValue
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.locale = Locale.current
        return dateFormatter.string(from: self)
    }
    
    static func getCurrentDate() -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        let str = dateFormatter.string(from: Date())
        return dateFormatter.date(from: str)!
    }
    
    
    
//    func isBetween(startDate:Date, endDate:Date)->Bool
//    {
//        return (startDate.compare(self) == .orderedAscending || startDate.compare(self) == .orderedSame) && (endDate.compare(self) == .orderedDescending || endDate.compare(self) == .orderedSame)
//    }
//
//    func dayNameOfWeek() -> String?
//    {
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "EEEE"
//        return dateFormatter.string(from: self)
//    }
//
//    func dayNameOfWeekThreeLetters() -> String?
//    {
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "EEE"
//        return dateFormatter.string(from: self)
//    }
//
//    func adding(minutes: Int) -> Date
//    {
//        return Calendar.current.date(byAdding: .minute, value: minutes, to: self)!
//    }
//
//    func getDiferenceInDays(endDate: Date) -> Int?
//    {
//        let calendar = Calendar.current
//
//        // Replace the hour (time) of both dates with 00:00
//        let date1 = calendar.startOfDay(for: self)
//        let date2 = calendar.startOfDay(for: endDate)
//
//        let components = calendar.dateComponents([.day], from: date1, to: date2)
//
//        return components.day
//    }
}
