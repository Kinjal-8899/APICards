//
//  Encodable+Extension.swift
//  APICards
//
//  Created by Harindra Pittalia on 14/04/22.
//

import Foundation

extension Encodable {
    
    func structToDict() -> Dictionary<String, Any> {
        var dict: Dictionary<String, Any>? = nil
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(self)
            dict = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Dictionary<String, Any>
        } catch {
            print(error)
        }
        guard let dict = dict else { return ["":""] }
        return dict
    }
    
}
