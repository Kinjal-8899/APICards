//
//  UIView+Extension.swift
//  APICards
//
//  Created by Harindra Pittalia on 05/04/22.
//

import Foundation
import UIKit

//MARK: - extension UIView
extension UIView {
    
    //MARK: - IBInspectable cornerRadius
    @IBInspectable var cornerRadius: CGFloat {
        get {
            return self.cornerRadius
        }
        set {
            self.layer.cornerRadius = newValue
        }
    }
    
    func addDashedBorder() {
        let color = UIColor.red.cgColor
        
        let shapeLayer:CAShapeLayer = CAShapeLayer()
        let frameSize = self.frame.size
        let shapeRect = CGRect(x: 0, y: 0, width: frameSize.width, height: frameSize.height)
        
        shapeLayer.bounds = shapeRect
        shapeLayer.position = CGPoint(x: frameSize.width/2, y: frameSize.height/2)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = color
        shapeLayer.lineWidth = 2
        shapeLayer.lineJoin = CAShapeLayerLineJoin.round
        shapeLayer.lineDashPattern = [6,3]
        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 5).cgPath
        
        self.layer.addSublayer(shapeLayer)
    }
    
    //MARK: - Make round corners of UIView
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
         let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
         let mask = CAShapeLayer()
         mask.path = path.cgPath
         layer.mask = mask
     }
    
    func addBorders(edges: UIRectEdge = .all, color: UIColor = .black, width: CGFloat = 1.0) {
           
            func createBorder() -> UIView {
                let borderView = UIView(frame: CGRect.zero)
                borderView.translatesAutoresizingMaskIntoConstraints = false
                borderView.backgroundColor = color
                
                return borderView
            }

            if (edges.contains(.all) || edges.contains(.top)) {
                let topBorder = createBorder()
                self.addSubview(topBorder)
                NSLayoutConstraint.activate([
                    topBorder.topAnchor.constraint(equalTo: self.topAnchor),
                    topBorder.leadingAnchor.constraint(equalTo: self.leadingAnchor),
                    topBorder.trailingAnchor.constraint(equalTo: self.trailingAnchor),
                    topBorder.heightAnchor.constraint(equalToConstant: width)
                ])
            }
            if (edges.contains(.all) || edges.contains(.left)) {
                let leftBorder = createBorder()
                self.addSubview(leftBorder)
                NSLayoutConstraint.activate([
                    leftBorder.topAnchor.constraint(equalTo: self.topAnchor),
                    leftBorder.bottomAnchor.constraint(equalTo: self.bottomAnchor),
                    leftBorder.leadingAnchor.constraint(equalTo: self.leadingAnchor),
                    leftBorder.widthAnchor.constraint(equalToConstant: width)
                    ])
            }
            if (edges.contains(.all) || edges.contains(.right)) {
                let rightBorder = createBorder()
                self.addSubview(rightBorder)
                NSLayoutConstraint.activate([
                    rightBorder.topAnchor.constraint(equalTo: self.topAnchor),
                    rightBorder.bottomAnchor.constraint(equalTo: self.bottomAnchor),
                    rightBorder.trailingAnchor.constraint(equalTo: self.trailingAnchor),
                    rightBorder.widthAnchor.constraint(equalToConstant: width)
                    ])
            }
            if (edges.contains(.all) || edges.contains(.bottom)) {
                let bottomBorder = createBorder()
                self.addSubview(bottomBorder)
                NSLayoutConstraint.activate([
                    bottomBorder.bottomAnchor.constraint(equalTo: self.bottomAnchor),
                    bottomBorder.leadingAnchor.constraint(equalTo: self.leadingAnchor),
                    bottomBorder.trailingAnchor.constraint(equalTo: self.trailingAnchor),
                    bottomBorder.heightAnchor.constraint(equalToConstant: width)
                ])
            }
        }
}
