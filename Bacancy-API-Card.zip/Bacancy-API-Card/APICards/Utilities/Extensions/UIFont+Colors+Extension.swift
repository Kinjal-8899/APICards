//
//  UIFont+Extension.swift
//  APICards
//
//  Created by Harindra Pittalia on 09/05/22.
//

import Foundation
import UIKit

//MARK: - extension UIFont
extension UIFont
{
    static func Font_Medium(xx: CGFloat) -> UIFont?
    {
        return UIFont(name: "SFProDisplay-Medium", size: xx)
    }
    static func Font_Bold(xx: CGFloat) -> UIFont?
    {
        return UIFont(name: "SFProDisplay-Bold", size: xx)
    }
    static func Font_Light(xx: CGFloat) -> UIFont?
    {
        return UIFont(name: "SFProDisplay-Light", size: xx)
    }
    static func Font_Regular(xx: CGFloat) -> UIFont?
    {
        return UIFont(name: "Inter-Regular", size: xx)
    }
    static func Font_Semibold(xx: CGFloat) -> UIFont?
    {
        return UIFont(name: "SFProDisplay-Semibold", size: xx)
    }
    
}

// MARK: - Colors
enum AppColors {
    static var appBlackColor: UIColor =  #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    static var appOrangeColor: UIColor = #colorLiteral(red: 0.9490196078, green: 0.2470588235, blue: 0, alpha: 1)
    static var appGreenColor: UIColor = #colorLiteral(red: 0.2039215686, green: 0.7803921569, blue: 0.3490196078, alpha: 1)
    static var appBorderColor: UIColor =  #colorLiteral(red: 0.8980392157, green: 0.8980392157, blue: 0.9176470588, alpha: 1)
    static var appBlueColor: UIColor =  #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
    static var appGreyColor: UIColor =  #colorLiteral(red: 0.5568627451, green: 0.5568627451, blue: 0.5764705882, alpha: 1)
    static var appFontGreyColor: UIColor =  #colorLiteral(red: 0.8196078431, green: 0.8196078431, blue: 0.8392156863, alpha: 1)
    static var appBGColor: UIColor =  #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
    static var appDarkPinkColor: UIColor = #colorLiteral(red: 1, green: 0.1764705882, blue: 0.3333333333, alpha: 1)
}
