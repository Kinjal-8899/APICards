//
//  UIViewController+Extension.swift
//  APICards
//
//  Created by Harindra Pittalia on 05/04/22.
//

import Foundation
import UIKit

//MARK: - extension UIViewController
extension UIViewController {
    static var identifier: String {
        return String(describing: self)
    }
    
    //MARK: - instantiate UIViewController
    static func instantiate() -> Self {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(identifier: identifier) as! Self
        return controller
    }
    
    //MARK: - instantiate UIViewController
    static func instantiate(storyboard: String) -> Self {
        let storyboard = UIStoryboard(name: storyboard, bundle: nil)
        let controller = storyboard.instantiateViewController(identifier: identifier) as! Self
        return controller
    }
    
    //MARK: - openAlert
    public func openAlert(title: String,
                          message: String,
                          alertStyle: UIAlertController.Style,
                          actionTitles: [String],
                          actionStyles: [UIAlertAction.Style],
                          actions: [((UIAlertAction) -> Void)?]) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: alertStyle)
        
        for (index,indexTitle) in actionTitles.enumerated()
        {
            let action = UIAlertAction(title: indexTitle, style: actionStyles[index], handler: actions[index])
            alert.addAction(action)
        }
        self.present(alert, animated: true)
    }
    
    
    func popBack<T: UIViewController>(toControllerType: T.Type) {
        if var viewControllers: [UIViewController] = self.navigationController?.viewControllers {
            viewControllers = viewControllers.reversed()
            for currentViewController in viewControllers {
                if currentViewController .isKind(of: toControllerType) {
                    self.navigationController?.popToViewController(currentViewController, animated: true)
                    break
                }
            }
        }
    }
}

extension UIViewController {
    
    //MARK: - showActivityIndicator
    func showActivityIndicator() {
        var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(frame: CGRect.init(x: 0, y: 0, width: 50, height: 50))
        activityIndicator.hidesWhenStopped = true
        activityIndicator.tag = 222
        activityIndicator.color = UIColor(named: "AppWhiteBlackColor")
        activityIndicator.style = UIActivityIndicatorView.Style.medium
        activityIndicator.startAnimating()
        self.view.isUserInteractionEnabled = false
        
//        let greyView = UIView()
//        greyView.frame = CGRect(x: 0, y: 0, width: 150, height: 150)
//        greyView.backgroundColor = UIColor.black
//        greyView.layer.cornerRadius = 15
//        greyView.layer.borderWidth = 5
//        greyView.layer.borderColor = UIColor.white.cgColor
//        greyView.alpha = 0.9
//        greyView.tag = 111
//        greyView.center = self.view.center
        
        self.view.alpha = 0.7
     //   self.view.addSubview(greyView)
   //     activityIndicator.center = greyView.center
        activityIndicator.center = self.view.center
        view.addSubview(activityIndicator)
    }
    
    //MARK: - hideActivityIndicator
    func hideActivityIndicator() {
      //  if let background = self.view.viewWithTag(111) {
            if let activityIndicatorVisible = self.view.viewWithTag(222) as? UIActivityIndicatorView{
                activityIndicatorVisible.stopAnimating()
                activityIndicatorVisible.removeFromSuperview()
             //   background.removeFromSuperview()
            }
   //     }
        self.view.alpha = 1
        self.view.isUserInteractionEnabled = true
    }
}

