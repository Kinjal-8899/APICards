//
//  ACAlertTitle.swift
//  APICards
//
//  Created by Harindra Pittalia on 14/04/22.
//

import Foundation
import UIKit

//MARK: - ACAlertTitle
enum ACAlertTitle {
//    static let gotIt = "Got It!"
//    static let dismiss = "Dismiss"
//    static let save = "Save"
//    static let invalid = "Invalid"
    static let yes = "Yes"
    static let no = "No"
    static let cancel = "Cancel"
    static let INTERNET_ERROR = "You are browsing offline. Please check your internet connection!"
    static let oops = "Oops!."
    static let success = "Success"
    static let ok = "OK"
    static let alert = "Alert!"
    static let gotoPrevious = "Go To Previous Job"
}
//MARK: - ACAlertMessage
enum ACAlertMessage {
//    static let allFieldRequired = "Please fill all the fields."
//    static let needStrongPwd = "Please enter Strong Password"
    
//    static let invalidPhone = "Please enter valid Phone"
//    static let passwordUnmatch = "Passwords do not match"
//    static let noProvider = "No Provider Found."
    static let internalError = "Something went wrong."
    static let notLoggedIn = "You haven't logged in!"
    static let logout = "Are you sure you want to Logout?"
    static let loggedout = "You're successfully logged out."
    static let chooseStartDate = "You haven't chosen start date."
    static let chooseEndDate = "You haven't chosen end date."
    static let beforeStartJobSelect = "Before you start the job take photos/ videos"
    static let beforeEndJobSelect = "Before you end the job take photos/ videos"
    static let breakTimeStart = "Your break time is started"
    static let breakTimeStop = "Your break time is over"
    static let paymentSuccess = "Paid Successfully."
}
//MARK: - ACValidationError
enum ACValidationError {
    static let missingEmail = "Please enter Email Address."
    static let missingPassword = "Please enter password."
    static let invalidEmail = "Please enter valid Email address"
//    static let emptyEmail = "Please enter the email"
//    static let invalidEmail = "Please enter valid Email address"
//    static let emptyPassword = "Please enter the password"
//    static let invalidPassword = "Please enter valid password"
    
}




