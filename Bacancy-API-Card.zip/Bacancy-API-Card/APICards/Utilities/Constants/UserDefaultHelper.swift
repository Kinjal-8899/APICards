//
//  UserDefaultHelper.swift
//  APICards
//
//  Created by Harindra Pittalia on 14/04/22.
//

import Foundation

//MARK: - Defaults
enum Defaults: String {
    case userId = "userId"
    case userData = "userData"
    case isUserLoggedIn = "isUserLoggedIn"
   // case userRole = "userRole"
    case userEmail = "userEmail"
    case userPassword = "userPassword"
    case userPhone = "userPhone"
    case isRememberMe = "isRememberMe"
    case authToken = "auth_token"
    case userName = "userName"
    case latestTime = "latestTime"
    case jobIdInProgresss = "jobIdInProgresss"
    case strLatestTime = "strLatestTime"
}

//MARK: - UserDefaultHelper
final class UserDefaultHelper {
    
    //MARK: - userId
    static var userId: Int? {
        set{
            _set(value: newValue, key: .userId)
        } get {
            return _get(valueForKey: .userId) as? Int ?? nil
        }
    }
    
    //MARK: - userName
    static var userName: String? {
        set{
            _set(value: newValue, key: .userName)
        } get {
            return _get(valueForKey: .userName) as? String ?? nil
        }
    }
    
    //MARK: - userPhone
    static var userPhone: String? {
        set{
            _set(value: newValue, key: .userPhone)
        } get {
            return _get(valueForKey: .userPhone) as? String ?? nil
        }
    }
    
    //MARK: - latestTime
    static var latestTime : Int? {
        set {
            _set(value: newValue, key: .latestTime)
        }
        get {
            return _get(valueForKey: .latestTime) as? Int ?? nil
        }
    }
    
    //MARK: - strLatestTime
    static var strLatestTime: String? {
        set{
            _set(value: newValue, key: .strLatestTime)
        } get {
            return _get(valueForKey: .strLatestTime) as? String ?? "00:00:00"
        }
    }
    
    //MARK: - jobIdInProgresss
    static var jobIdInProgresss : Int? {
        set {
            _set(value: newValue, key: .jobIdInProgresss)
        }
        get {
            return _get(valueForKey: .jobIdInProgresss) as? Int ?? nil
        }
    }
    
    //MARK: - authToken
    static var authToken : String? {
        set {
            _set(value: newValue, key: .authToken)
        }
        get {
            return _get(valueForKey: .authToken) as? String ?? nil
        }
    }
    
    //MARK: - userEmail
    static var userEmail: String? {
        set{
            _set(value: newValue, key: .userEmail)
        } get {
            return _get(valueForKey: .userEmail) as? String ?? nil
        }
    }
    
    //MARK: - userPassword
    static var userPassword: String? {
        set{
            _set(value: newValue, key: .userPassword)
        } get {
            return _get(valueForKey: .userPassword) as? String ?? nil
        }
    }
    
    //MARK: - isUserLoggedIn
    static var isUserLoggedIn: Bool? {
        set{
            _set(value: newValue, key: .isUserLoggedIn)
        } get {
            return _get(valueForKey: .isUserLoggedIn) as? Bool ?? false
        }
    }
    
    //MARK: - isRememberMe
    static var isRememberMe: Bool? {
        set{
            _set(value: newValue, key: .isRememberMe)
        } get {
            return _get(valueForKey: .isRememberMe) as? Bool ?? nil
        }
    }
    
//    //MARK: - userRole
//    static var userRole: String? {
//        set{
//            _set(value: newValue, key: .userRole)
//        } get {
//            return _get(valueForKey: .userRole) as? String ?? nil
//        }
//    }
//
    //MARK: - userData
    static var userData: Data? {
        set{
            _set(value: newValue, key: .userData)
        } get {
            return _get(valueForKey: .userData) as? Data ?? nil
        }
    }
    
    //MARK: - get set value in user default
    private static func _set(value: Any?, key: Defaults) {
        UserDefaults.standard.set(value, forKey: key.rawValue)
    }
    
    private static func _get(valueForKey key: Defaults)-> Any? {
        return UserDefaults.standard.value(forKey: key.rawValue)
    }
    
    //MARK: - delete value from user default
    class func deleteUserDefalutValue(deleteKey : Defaults) {
        UserDefaults.standard.removeObject(forKey: deleteKey.rawValue)
    }
    
//    //MARK: - store Any Data
//    func store(key: String, data: Any){
//        UserDefaults.standard.set(data, forKey: key)
//    }
}
