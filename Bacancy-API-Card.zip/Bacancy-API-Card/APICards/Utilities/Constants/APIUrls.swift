//
//  APIUrls.swift
//  APICards
//
//  Created by Harindra Pittalia on 12/04/22.
//

import Foundation

//MARK: - extension API Urls
struct APIUrls {
    static let BASE_URL : String = Configuration.environment.hostUrl
    
    static let imageBaseURL = "http://13.127.182.178"
    
    static let login = "/users/log_in"
    static let logout = "/users/log_out"
    static let userPermission = "/update_user_app_permission"
    static let userProfile = "/user_profile"
    
    static let getJobs = "/job_list"
    static let getJobDetail = "/job_detail"
    static let getTodayJobData = "/assigned_today_job_count"
    
    static let updateJobTimeLog = "/add_update_job_timelog"
    
    static let paymentAPI = "/job_payment_success"
    static let paymentList = "/payment_list"
    static let reportsList = "/my_reports"
    
    static let cancelJob = "/cancel_job"
    
}
