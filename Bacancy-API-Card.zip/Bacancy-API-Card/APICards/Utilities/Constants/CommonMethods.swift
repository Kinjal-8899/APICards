//
//  CommonMethods.swift
//  APICards
//
//  Created by Harindra Pittalia on 05/05/22.
//

import Foundation
import UIKit

//MARK: - CommonMethods
class CommonMethods {
    
    //MARK: - set Login Screen
    class func setLoginScreen(){
        let initialViewController: UINavigationController? = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Login") as? UINavigationController
        
        DispatchQueue.main.async {
            UIApplication.topViewController()?.view.window?.rootViewController = initialViewController
            UIApplication.topViewController()?.view.window?.makeKeyAndVisible()
        }
    }
    //MARK: - set Home Screen
    class func setHomeScreen() {
        let initialViewController: UITabBarController? = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ACTabBarVC") as? UITabBarController
        
        DispatchQueue.main.async {
            UIApplication.topViewController()?.view.window?.rootViewController = initialViewController
            UIApplication.topViewController()?.view.window?.makeKeyAndVisible()
        }
    }
    
    
    class func setDashboard() {
        let initialViewController: UITabBarController? = UIStoryboard(name: "Home", bundle: nil).instantiateViewController(withIdentifier: "ACTabBarVC2") as? UITabBarController
        
        DispatchQueue.main.async {
            UIApplication.topViewController()?.view.window?.rootViewController = initialViewController
            UIApplication.topViewController()?.view.window?.makeKeyAndVisible()
        }
    }
    
    //MARK: - Get UIColor From Hex
    class func getUIColor(hex: String, alpha: Double = 1.0) -> UIColor? {
        var cleanString = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cleanString.hasPrefix("#")) {
            cleanString.remove(at: cleanString.startIndex)
        }

        if ((cleanString.count) != 6) {
            return nil
        }
        let rgbValue: UInt32 = 0
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    //MARK: - Set Border
    class func setBorderRadius(view : UIView, radius : Int, borderColor : UIColor, borderWidth : CGFloat)
    {
        view.layer.borderColor = borderColor.cgColor
        view.layer.borderWidth = borderWidth
        view.layer.cornerRadius = CGFloat(radius)
        
        view.layer.shadowColor = UIColor.gray.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowOpacity = 0.1
        view.layer.shadowRadius = 10
    }
}
