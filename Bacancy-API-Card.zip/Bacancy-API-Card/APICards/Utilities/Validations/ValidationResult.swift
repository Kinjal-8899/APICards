//
//  ValidationResult.swift
//  APICards
//
//  Created by Harindra Pittalia on 11/04/22.
//

import Foundation

struct ValidationResult
{
    let success: Bool
    let error : String?
}
