//
//  LoginValidation.swift
//  APICards
//
//  Created by Harindra Pittalia on 11/04/22.
//

import Foundation

struct LoginValidation {

    func validate(loginRequest: LoginRequest) -> ValidationResult
    {
        if(loginRequest.email!.isEmpty)
        {
            return ValidationResult(success: false, error: ACValidationError.missingEmail)
        }

        if(loginRequest.password!.isEmpty)
        {
            return ValidationResult(success: false, error: ACValidationError.missingPassword)
        }

        if !(Validation.shared.validateEmailId(emailID: loginRequest.email!)) {
            return ValidationResult(success: false, error: ACValidationError.invalidEmail)
        }
        return ValidationResult(success: true, error: nil)
    }

}
