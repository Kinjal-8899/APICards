//
//  CommonMethods.swift
//  APICards
//
//  Created by Harindra Pittalia on 12/04/22.
//

import Foundation

class CommonMethods {
    
  
}
