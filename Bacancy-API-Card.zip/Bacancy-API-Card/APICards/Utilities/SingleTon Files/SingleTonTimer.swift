//
//  SingleTonTimer.swift
//  APICards
//
//  Created by Harindra Pittalia on 12/05/22.
//

import Foundation

//MARK: - SingleTonTimer
class SingleTonTimer: NSObject {
    
    //MARK: - Variables
    static let sharedTimer: SingleTonTimer = {
       let timer = SingleTonTimer()
        return timer
    }()
    
    var internalTimer: Timer?
    var currenttimeStr = "00:00:00"
    var currentTime = 0
    
    //MARK: - Start global timer
    func startGlobalTimer() {
        guard self.internalTimer == nil else {
            fatalError("Timer already intialized, how did we get here with a singleton?!")
        }
        self.internalTimer = Timer.scheduledTimer(timeInterval: 1.0 /*seconds*/, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    
    //MARK: - Stop global timer
    func stopGlobalTimer(){
        currentTime = 0
        UserDefaultHelper.jobIdInProgresss = nil
        UserDefaultHelper.strLatestTime = "00:00:00"
        self.internalTimer?.invalidate()
        internalTimer = nil
    }
    
    //MARK: - update timer
    @objc func updateTimer() -> String {
        currentTime += 1
        return self.timeFormatted(self.currentTime)
    }
    
    //MARK: - Time format to be displayed
    func timeFormatted(_ totalSeconds: Int) -> String {
        let seconds: Int = totalSeconds % 60
        let minutes: Int = (totalSeconds / 60) % 60
        let hours: Int = (totalSeconds / 3600) % 60
        currenttimeStr = String(format: "%02d:%02d:%02d", hours, minutes, seconds)
        UserDefaultHelper.strLatestTime = currenttimeStr
        return currenttimeStr
    }
    
    //MARK: - pause Timer
    func pauseTimer() {
        UserDefaultHelper.latestTime = currentTime
        internalTimer?.invalidate()
        internalTimer = nil
    }
    
    //MARK: - resumer Timer
    func resumeTimer() {
        currentTime = UserDefaultHelper.latestTime ?? 0
        startGlobalTimer()
        
    }
    
}
