////
////  CommonWS.swift
////  APICards
////
////  Created by Harindra Pittalia on 11/04/22.
////
//
import Foundation
import Alamofire
import Reachability

//MARK: - StatusCode
struct StatusCode {
    static let success = 200
}

//MARK: - apiCompletionBlock
typealias apiCompletionBlock = (_ responseData : Dictionary<String, Any>, _ success: Bool) -> ()

//MARK: - CommonWS
class CommonWS:  NSObject
{
    //MARK: - Post URL
    class func PostURL(url: String, dict:Dictionary<String, Any> ,completion: @escaping apiCompletionBlock)
    {
        if Reachability.isConnectedToNetwork()
        {
            let aUrl = APIUrls.BASE_URL + url
            var headers = HTTPHeaders()
            
            //set Headers
            headers = ["Content-Type": "application/json"]
            
            if UserDefaultHelper.authToken != nil {
                headers = ["Content-Type" : "application/json",
                           "TOKEN" : "\(UserDefaultHelper.authToken!)"]
            }
            print("POST API: \(aUrl)")
            print("PARAMETER: \(dict as NSDictionary)")
            print(headers)
            
            AF.request(aUrl, method: .post, parameters: dict, encoding: JSONEncoding.prettyPrinted, headers: headers, interceptor: nil).responseJSON { (response) in
                print(response.value)
                switch response.result
                {
                case .success(_):
                    if let result = response.value {
                        if let JSON = result as? [String : AnyObject] {
                            print("\(aUrl) = \(JSON)")
                            
                            if let code = JSON["status"] as? Int, code == StatusCode.success
                            {
                                completion(JSON, true)
                            }
                            else
                            {
                                completion(JSON, false)
                            }
                        }
                    }
                    break
                case .failure(_):
                    print(response.error!)
                    let temp = NSDictionary.init(object: response.error?.localizedDescription ?? ACAlertMessage.internalError, forKey: "message" as NSCopying)
                    completion(temp as! Dictionary<String, Any>,false)
                    break
                }
            }
        }
        else
        {
            let temp = NSDictionary.init(object: ACAlertTitle.INTERNET_ERROR, forKey: "message" as NSCopying)
            completion(temp as! Dictionary<String, Any>,false)
        }
    }
    
    //MARK: - GET URL with Parameter
    class func GetURLWithParameter(url: String, dict:Dictionary<String, Any> ,completion:  @escaping apiCompletionBlock)
    {
        if Reachability.isConnectedToNetwork()
        {
            var aUrl = APIUrls.BASE_URL + url
            var headers = HTTPHeaders()
            
            //set Headers
            headers = ["Content-Type": "application/json"]
            
            if UserDefaultHelper.authToken != nil {
                headers = ["Content-Type" : "application/json",
                           "TOKEN" : "\(UserDefaultHelper.authToken!)"]
            }
            
            
            print("GET API: \(aUrl)")
            print("PARAMETER: \(dict as NSDictionary)")
            
            
            for (index,value) in dict.enumerated()
            {
                if index == 0
                {
                    aUrl = "\(aUrl)?\(value.key)=\(value.value)"
                }
                else
                {
                    aUrl = "\(aUrl)&\(value.key)=\(value.value)"
                }
            }
            aUrl = aUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
            print(aUrl)
            
            AF.request(aUrl, method: .get, encoding: JSONEncoding.prettyPrinted, headers: headers).responseJSON { (response) in
                print(response)
                switch response.result
                {
                case .success(_):
                    if let result = response.value {
                        if let JSON = result as? [String : AnyObject] {
                            print("\(aUrl) = \(JSON)")
                            
                            if let code = JSON["status"] as? Int, code == StatusCode.success
                            {
                                completion(JSON, true)
                            }
                            else
                            {
                                completion(JSON, false)
                            }
                        }
                    }
                    break
                case .failure(_):
                    print(response.error!)
                    let temp = NSDictionary.init(object: response.error?.localizedDescription ?? ACAlertMessage.internalError, forKey: "message" as NSCopying)
                    completion(temp as! Dictionary<String, Any>,false)
                    break
                }
            }
        }
        else
        {
            let temp = NSDictionary.init(object: ACAlertTitle.INTERNET_ERROR, forKey: "message" as NSCopying)
            completion(temp as! Dictionary<String, Any>,false)
        }
    }
    
    //MARK: - GET URL without Parameter
    class func GetURLWithoutParameter(url: String, completion:  @escaping apiCompletionBlock)
    {
        if Reachability.isConnectedToNetwork()
        {
            let aUrl = APIUrls.BASE_URL + url
            var headers = HTTPHeaders()
            
            headers = ["Content-Type": "application/json"]
            
            if UserDefaultHelper.authToken != nil {
                headers = ["Content-Type" : "application/json",
                           "TOKEN" : "\(UserDefaultHelper.authToken!)"]
            }
             print(headers)
              print("GET API: \(aUrl)")
            
            AF.request(aUrl, method: .get, encoding: JSONEncoding.prettyPrinted, headers: headers).responseJSON { (response) in
                // print(response)
                switch response.result
                {
                case .success(_):
                    if let result = response.value {
                        if let JSON = result as? [String : AnyObject] {
                            print("\(aUrl) = \(JSON)")
                            
                            if let code = JSON["status"] as? Int, code == StatusCode.success
                            {
                                completion(JSON, true)
                            }
                            else
                            {
                                completion(JSON, false)
                            }
                        }
                    }
                    break
                case .failure(_):
                    print(response.error!)
                    let temp = NSDictionary.init(object: response.error?.localizedDescription ?? ACAlertMessage.internalError, forKey: "message" as NSCopying)
                    completion(temp as! Dictionary<String, Any>,false)
                    break
                }
            }
        }
        else
        {
            let temp = NSDictionary.init(object: ACAlertTitle.INTERNET_ERROR, forKey: "message" as NSCopying)
            completion(temp as! Dictionary<String, Any>,false)
        }
    }
    
    //MARK: - Multiple media upload URL
    class func PostURLWithMultipart(url: String, dict:Dictionary<String, Any>, imageData: [UIImage]?, videoData: [URL]?, imageParameter:String?, completion:  @escaping apiCompletionBlock)
        {
            if Reachability.isConnectedToNetwork()
            {
                let aUrl = APIUrls.BASE_URL + url
                var headers = HTTPHeaders()
    
                //set Headers
                headers = ["Content-Type": "application/json"]
    
                print("MALTIPART API: \(aUrl)")
                print("PARAMETER: \(dict as NSDictionary)")
                if UserDefaultHelper.authToken != nil {
                    headers = [ "Content-Type": "application/json",
                               "TOKEN" : "\(UserDefaultHelper.authToken!)"]
                }
    
                print(headers)
                 
                AF.upload(multipartFormData: { (multipartFormData) in
                    if imageData != nil || videoData != nil {
                    guard let imageData = imageData else {
                        return
                    }
                    guard let videoData = videoData else {
                        return
                    }
                    if imageData.count > 0 {
                        for data in imageData {
                            guard let jpegData = data.jpegData(compressionQuality: 0.5) else {
                                return
                            }
                            print(jpegData)
                            multipartFormData.append(jpegData, withName: imageParameter ?? "", fileName: "image\(Date().timeIntervalSince1970).jpeg")
                            
                        }
                    }
                    if videoData.count > 0 {
                        for data in videoData {
                            do {
                                let video = try Data(contentsOf: data, options: .dataReadingMapped)
                                print(video)
                                multipartFormData.append(video, withName: imageParameter ?? "", fileName: "video\(Date().timeIntervalSince1970).mov")
                            } catch  {
                                print("error in conversion of video to data")
                            }
                        }
                    }
                    }
                    for (key, value) in dict {
                       if let boolvalue:Int =  value as? Int{
                            multipartFormData.append(Int(boolvalue).description.data(using: .utf8)!, withName: key)
                        }else{
                            multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                        }
                    }
                    //Response
                }, to: aUrl, method: .post, headers: headers).responseJSON(completionHandler: { (response) in
                    switch response.result
                    {
                    case .success(_):
                        if let result = response.value {
                            if let JSON = result as? [String : AnyObject] {
                                print("\(aUrl) = \(JSON)")

                                if let code = JSON["status"] as? Int, code == StatusCode.success
                                {
                                    completion(JSON, true)
                                }
                                else
                                {
                                    completion(JSON, false)
                                }
                            }
                        }
                        break
                    case .failure(_):
                        print(response.error!)
                        let temp = NSDictionary.init(object: response.error?.localizedDescription ?? ACAlertMessage.internalError, forKey: "message" as NSCopying)
                            completion(temp as! Dictionary<String, Any>,false)
                            break
                    }
                    //upload progress
                }).uploadProgress { (progrss) in
                    print("Upload Progress: \(progrss.fractionCompleted)")
                }
            }
            else
            {
                let temp = NSDictionary.init(object: ACAlertTitle.INTERNET_ERROR, forKey: "message" as NSCopying)
                completion(temp as! Dictionary<String, Any>,false)
            }
        }
    
    
    
    
    //    //MARK: - PATCH Method
    //    class func PatchURL(url: String, dict:Dictionary<String, Any> ,completion: @escaping apiCompletionBlock)
    //    {
    //        if Reachability.isConnectedToNetwork()
    //        {
    //            let aUrl = APIURL.BASEURL + url
    //            var headers = HTTPHeaders()
    //
    //            //set Headers
    //            headers = ["Content-Type": "application/json"]
    //
    //            print("PATCH API: \(aUrl)")
    //            print("PARAMETER: \(dict as NSDictionary)")
    //
    //            AF.request(aUrl, method: .patch, parameters: dict, encoding: JSONEncoding.prettyPrinted, headers: headers, interceptor: nil).responseJSON { (response) in
    //                switch response.result
    //                {
    //                    case .success(_):
    //                        if let result = response.value {
    //                            if let JSON = result as? [String : AnyObject] {
    //                                print("\(aUrl) = \(JSON)")
    //
    //                                if let code = JSON["code"] as? Int, code == StatusCode.success
    //                                {
    //                                    completion(JSON, true)
    //                                }
    //                                else
    //                                {
    //                                    completion(JSON, false)
    //                                }
    //                            }
    //                        }
    //                        break
    //                    case .failure(_):
    //                        print(response.error!)
    //                        let temp = NSDictionary.init(object: response.error?.localizedDescription ?? HPMessageConst.internalError, forKey: "message" as NSCopying)
    //                        completion(temp as! Dictionary<String, Any>,false)
    //                        break
    //                }
    //            }
    //        }
    //        else
    //        {
    //            let temp = NSDictionary.init(object: HPAlertTitleMessage.INTERNET_ERROR, forKey: "message" as NSCopying)
    //            completion(temp as! Dictionary<String, Any>,false)
    //        }
    //    }
    //
    //    class func PatchURLWithMultipart(url: String, dict:Dictionary<String, Any>, imageData: Data, imageParameter:String, isAuth: Bool, completion: @escaping apiCompletionBlock)
    //    {
    //        if Reachability.isConnectedToNetwork()
    //        {
    //            let aUrl = APIURL.BASEURL + url
    //            var headers = HTTPHeaders()
    //
    //            //set Headers
    //            headers = ["Content-Type": "image/jpeg"]
    //
    //            print("MALTIPART API: \(aUrl)")
    //            print("PARAMETER: \(dict as NSDictionary)")
    //
    //            AF.upload(multipartFormData: { (multipartFormData) in
    //
    //                //images
    //                if !imageData.isEmpty  {
    //                    multipartFormData.append(imageData, withName: imageParameter, fileName: "imageProfile\(Date().timeIntervalSince1970).jpg", mimeType: "image/jpg")
    //                }
    //                //other params
    //                for (key, value) in dict {
    //                    if let boolvalue:Bool =  value as? Bool{
    //                        multipartFormData.append(Bool(boolvalue).description.data(using: .utf8)!, withName: key)
    //                    }
    //                    else if let boolvalue:Float =  value as? Float{
    //                        multipartFormData.append(Float(boolvalue).description.data(using: .utf8)!, withName: key)
    //                    }
    //                    else if let boolvalue:Int =  value as? Int{
    //                        multipartFormData.append(Int(boolvalue).description.data(using: .utf8)!, withName: key)
    //                    }else{
    //                        multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
    //                    }
    //                }
    //                //Response
    //            }, to: aUrl, method: .patch, headers: headers).responseJSON(completionHandler: { (response) in
    //                switch response.result
    //                {
    //                    case .success(_):
    //                        if let result = response.value {
    //                            if let JSON = result as? [String : AnyObject] {
    //                                print("\(aUrl) = \(JSON)")
    //
    //                                if let code = JSON["code"] as? Int, code == StatusCode.success
    //                                {
    //                                    completion(JSON, true)
    //                                }
    //                                else
    //                                {
    //                                    completion(JSON, false)
    //                                }
    //                            }
    //                        }
    //                        break
    //                    case .failure(_):
    //                        print(response.error!)
    //                        let temp = NSDictionary.init(object: response.error?.localizedDescription ?? HPMessageConst.internalError, forKey: "message" as NSCopying)
    //                        completion(temp as! Dictionary<String, Any>,false)
    //                        break
    //                }
    //                //upload progress
    //            }).uploadProgress(queue: .main, closure:  { progrss in
    //                print("Upload Progress: \(progrss.fractionCompleted)")
    //            })
    //        }
    //        else
    //        {
    //            let temp = NSDictionary.init(object: HPAlertTitleMessage.INTERNET_ERROR, forKey: "message" as NSCopying)
    //            completion(temp as! Dictionary<String, Any>,false)
    //        }
    //    }
    //
    //    //MARK: - Delete Method
    //    class func DeleteURLWithParmeter(url: String, dict:Dictionary<String, Any> ,completion:  @escaping apiCompletionBlock)
    //    {
    //        if Reachability.isConnectedToNetwork()
    //        {
    //            let aUrl = APIURL.BASEURL + url
    //            var headers = HTTPHeaders()
    //
    //            //set Headers
    //            headers = ["Content-Type": "application/json"]
    //
    //            print("DELETE API: \(aUrl)")
    //            print("PARAMETER: \(dict as NSDictionary)")
    //
    //            AF.request(aUrl, method: .delete, parameters: dict, encoding: JSONEncoding.prettyPrinted, headers: headers, interceptor: nil).responseJSON { (response) in
    //                switch response.result
    //                {
    //                    case .success(_):
    //                        if let result = response.value {
    //                            if let JSON = result as? [String : AnyObject] {
    //                                print("\(aUrl) = \(JSON)")
    //
    //                                if let code = JSON["code"] as? Int, code == StatusCode.success
    //                                {
    //                                    completion(JSON, true)
    //                                }
    //                                else
    //                                {
    //                                    completion(JSON, false)
    //                                }
    //                            }
    //                        }
    //                        break
    //                    case .failure(_):
    //                        print(response.error!)
    //                        let temp = NSDictionary.init(object: response.error?.localizedDescription ?? HPMessageConst.internalError, forKey: "message" as NSCopying)
    //                        completion(temp as! Dictionary<String, Any>,false)
    //                        break
    //                }
    //            }
    //        }
    //        else
    //        {
    //            let temp = NSDictionary.init(object: HPAlertTitleMessage.INTERNET_ERROR, forKey: "message" as NSCopying)
    //            completion(temp as! Dictionary<String, Any>,false)
    //        }
    //    }
    //
    //    class func DeleteURLWithoutParmeter(url: String, completion:  @escaping apiCompletionBlock)
    //    {
    //        if Reachability.isConnectedToNetwork()
    //        {
    //            let aUrl = APIURL.BASEURL + url
    //            var headers = HTTPHeaders()
    //
    //            //set Headers
    //            headers = ["Content-Type": "application/json"]
    //
    //            print("DELETE API: \(aUrl)")
    //
    //            AF.request(aUrl, method: .delete, encoding: JSONEncoding.prettyPrinted, headers: headers, interceptor: nil).responseJSON { (response) in
    //                switch response.result
    //                {
    //                    case .success(_):
    //                        if let result = response.value {
    //                            if let JSON = result as? [String : AnyObject] {
    //                                print("\(aUrl) = \(JSON)")
    //
    //                                if let code = JSON["code"] as? Int, code == StatusCode.success
    //                                {
    //                                    completion(JSON, true)
    //                                }
    //                                else
    //                                {
    //                                    completion(JSON, false)
    //                                }
    //                            }
    //                        }
    //                        break
    //                    case .failure(_):
    //                        print(response.error!)
    //                        let temp = NSDictionary.init(object: response.error?.localizedDescription ?? HPMessageConst.internalError, forKey: "message" as NSCopying)
    //                        completion(temp as! Dictionary<String, Any>,false)
    //                        break
    //                }
    //            }
    //        }
    //        else
    //        {
    //            let temp = NSDictionary.init(object: HPAlertTitleMessage.INTERNET_ERROR, forKey: "message" as NSCopying)
    //            completion(temp as! Dictionary<String, Any>,false)
    //        }
    //    }
    //
    
    //    //MARK: - Multipart
    //    class func PostURLWithMultipartWithoutImage(url: String, dict:Dictionary<String, Any>,  isAuth: Bool, completion:  @escaping apiCompletionBlock)
    //    {
    //        if Reachability.isConnectedToNetwork()
    //        {
    //            let aUrl = APIURL.BASEURL + url
    //            var headers = HTTPHeaders()
    //
    //            //set Headers
    //            headers = ["Content-Type": "image/jpeg"]
    //
    //            print("MALTIPART API: \(aUrl)")
    //            print("PARAMETER: \(dict as NSDictionary)")
    //
    //            AF.upload(multipartFormData: { (multipartFormData) in
    //
    //                //other params
    //                for (key, value) in dict {
    //                    if let boolvalue:Bool =  value as? Bool{
    //                        multipartFormData.append(Bool(boolvalue).description.data(using: .utf8)!, withName: key)
    //                    }
    //                    else if let boolvalue:Float =  value as? Float{
    //                        multipartFormData.append(Float(boolvalue).description.data(using: .utf8)!, withName: key)
    //                    }
    //                    else if let boolvalue:Int =  value as? Int{
    //                        multipartFormData.append(Int(boolvalue).description.data(using: .utf8)!, withName: key)
    //                    }else{
    //                        multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
    //                    }
    //                }
    //                //Response
    //            }, to: aUrl, method: .post, headers: headers).responseJSON(completionHandler: { (response) in
    //                switch response.result
    //                {
    //                    case .success(_):
    //                        if let result = response.value {
    //                            if let JSON = result as? [String : AnyObject] {
    //                                print("\(aUrl) = \(JSON)")
    //
    //                                if let code = JSON["code"] as? Int, code == StatusCode.success
    //                                {
    //                                    completion(JSON, true)
    //                                }
    //                                else
    //                                {
    //                                    completion(JSON, false)
    //                                }
    //                            }
    //                        }
    //                        break
    //                    case .failure(_):
    //                        print(response.error!)
    //                        let temp = NSDictionary.init(object: response.error?.localizedDescription ?? HPMessageConst.internalError, forKey: "message" as NSCopying)
    //                        completion(temp as! Dictionary<String, Any>,false)
    //                        break
    //                }
    //                //upload progress
    //            }).uploadProgress { (progrss) in
    //                print("Upload Progress: \(progrss.fractionCompleted)")
    //            }
    //        }
    //        else
    //        {
    //            let temp = NSDictionary.init(object: HPAlertTitleMessage.INTERNET_ERROR, forKey: "message" as NSCopying)
    //            completion(temp as! Dictionary<String, Any>,false)
    //        }
    //    }
    //
    
    //    class func PostURLWithMultiMediaMultipart(url: String, dict:Dictionary<String, Any>, imageData: [[String : Any]], imageParameter:String, isAuth: Bool, completion:  @escaping apiCompletionBlock)
    //    {
    //        if Reachability.isConnectedToNetwork()
    //        {
    //            let aUrl = APIURL.BASEURL + url
    //            var headers = HTTPHeaders()
    //
    //            //set Headers
    //            headers = ["Content-Type": "image/jpeg"]
    //
    //            print("MALTIPART API: \(aUrl)")
    //            print("PARAMETER: \(dict as NSDictionary)")
    //
    //            AF.upload(multipartFormData: { (multipartFormData) in
    //
    //                //images
    //                for aimageData in imageData {
    //                    multipartFormData.append( aimageData["data"] as! Data, withName: (aimageData["filename"] as! String).count == 0 ?  "media" : (aimageData["filename"] as! String) , fileName: (aimageData["filename"] as! String).count == 0 ?  "image.jpg" : (aimageData["filename"] as! String), mimeType: "image/jpg")
    //                }
    //
    //                //other params
    //                for (key, value) in dict {
    //                    if let boolvalue:Bool =  value as? Bool{
    //                        multipartFormData.append(Bool(boolvalue).description.data(using: .utf8)!, withName: key)
    //                    } else if let intvalue:Int =  value as? Int{
    //                        multipartFormData.append(Int(intvalue).description.data(using: .utf8)!, withName: key)
    //                    }
    //                    else if let Json : [String ] =  value as? [String]{
    //                        let arrData =  try! JSONSerialization.data(withJSONObject: Json, options: .prettyPrinted)
    //                        multipartFormData.append(arrData, withName: key as String)
    //                    }
    //                    else if let Json : [[String : Any]] =  value as? [[String : Any]]{
    //                        let arrData =  try! JSONSerialization.data(withJSONObject: Json, options: .prettyPrinted)
    //                        multipartFormData.append(arrData, withName: key as String)
    //                    } else if let Json :  [String : Any] =  value as?  [String : Any]{
    //                        let arrData =  try! JSONSerialization.data(withJSONObject: Json, options: .prettyPrinted)
    //                        multipartFormData.append(arrData, withName: key as String)
    //                    }
    //                    else {
    //                        multipartFormData.append(((value as AnyObject).data(using: String.Encoding.utf8.rawValue))!, withName: key)
    //                    }
    //                }
    //                //Response
    //            }, to: aUrl, method: .post, headers: headers).responseJSON(completionHandler: { (response) in
    //                switch response.result
    //                {
    //                    case .success(_):
    //                        if let result = response.value {
    //                            if let JSON = result as? [String : AnyObject] {
    //                                print("\(aUrl) = \(JSON)")
    //
    //                                if let code = JSON["code"] as? Int, code == StatusCode.success
    //                                {
    //                                    completion(JSON, true)
    //                                }
    //                                else
    //                                {
    //                                    completion(JSON, false)
    //                                }
    //                            }
    //                        }
    //                        break
    //                    case .failure(_):
    //                        print(response.error!)
    //                        let temp = NSDictionary.init(object: response.error?.localizedDescription ?? HPMessageConst.internalError, forKey: "message" as NSCopying)
    //                        completion(temp as! Dictionary<String, Any>,false)
    //                        break
    //                }
    //                //upload progress
    //            }).uploadProgress { (progrss) in
    //                print("Upload Progress: \(progrss.fractionCompleted)")
    //            }
    //        }
    //        else
    //        {
    //            let temp = NSDictionary.init(object: HPAlertTitleMessage.INTERNET_ERROR, forKey: "message" as NSCopying)
    //            completion(temp as! Dictionary<String, Any>,false)
    //        }
    //    }
    //
    //    class func PostURLWithMultipartVideo(url: String, dict:Dictionary<String, Any>, imageData: Data, imageParameterName:String, videoData: Data, videoParameterName:String, isAuth: Bool, completion: @escaping apiCompletionBlock)
    //    {
    //        if Reachability.isConnectedToNetwork()
    //        {
    //            let aUrl = APIURL.BASEURL + url
    //            var headers = HTTPHeaders()
    //
    //            //set Headers
    //            headers = ["Content-Type": "image/jpeg"]
    //
    //            print("MALTIPART API: \(aUrl)")
    //            print("PARAMETER: \(dict as NSDictionary)")
    //
    //            AF.upload(multipartFormData: { (multipartFormData) in
    //
    //                //images
    //                if imageData.count != 0 {
    //                    multipartFormData.append(imageData, withName: imageParameterName, fileName: "imageProfile\(Date().timeIntervalSince1970).jpg", mimeType: "image/jpg")
    //                }
    //
    //                //Video
    //                if videoData.count != 0 {
    //                    multipartFormData.append(videoData, withName: videoParameterName, fileName: "video\(Date().timeIntervalSince1970).mp4", mimeType: "video/mp4")
    //                }
    //                //other params
    //
    //                //other params
    //                for (key, value) in dict {
    //                    if let boolvalue:Bool =  value as? Bool{
    //                        multipartFormData.append(Bool(boolvalue).description.data(using: .utf8)!, withName: key)
    //                    } else if let intvalue:Int =  value as? Int{
    //                        multipartFormData.append(Int(intvalue).description.data(using: .utf8)!, withName: key)
    //                    }
    //                    else if let Json : [String] =  value as? [String]{
    //                        let arrData =  try! JSONSerialization.data(withJSONObject: Json, options: .prettyPrinted)
    //                        multipartFormData.append(arrData, withName: key as String)
    //                    }
    //                    else if let Json : [[String : Any]] =  value as? [[String : Any]]{
    //                        let arrData =  try! JSONSerialization.data(withJSONObject: Json, options: .prettyPrinted)
    //                        multipartFormData.append(arrData, withName: key as String)
    //                    } else if let Json :  [String : Any] =  value as?  [String : Any]{
    //                        let arrData =  try! JSONSerialization.data(withJSONObject: Json, options: .prettyPrinted)
    //                        multipartFormData.append(arrData, withName: key as String)
    //                    }
    //                    else {
    //                        multipartFormData.append(((value as AnyObject).data(using: String.Encoding.utf8.rawValue))!, withName: key)
    //                    }
    //                }
    //                //Response
    //            }, to: aUrl, method: .post, headers: headers).responseJSON(completionHandler: { (response) in
    //                switch response.result
    //                {
    //                    case .success(_):
    //                        if let result = response.value {
    //                            if let JSON = result as? [String : AnyObject] {
    //                                print("\(aUrl) = \(JSON)")
    //
    //                                if let code = JSON["code"] as? Int, code == StatusCode.success
    //                                {
    //                                    completion(JSON, true)
    //                                }
    //                                else
    //                                {
    //                                    completion(JSON, false)
    //                                }
    //                            }
    //                        }
    //                        break
    //                    case .failure(_):
    //                        print(response.error!)
    //
    //                        let temp = NSDictionary.init(object: response.error?.localizedDescription ?? HPMessageConst.internalError, forKey: "message" as NSCopying)
    //                        completion(temp as! Dictionary<String, Any>,false)
    //                        break
    //                }
    //                //upload progress
    //            }).uploadProgress (queue: .main, closure:  { progrss in
    //                print("Upload Progress: \(progrss.fractionCompleted)")
    //            })
    //        }
    //        else
    //        {
    //            let temp = NSDictionary.init(object: HPAlertTitleMessage.INTERNET_ERROR, forKey: "message" as NSCopying)
    //            completion(temp as! Dictionary<String, Any>,false)
    //        }
    //    }
    
    //MARK: - Multiple media upload URL
//    class func callWebServiceWithParameterToUploadMultipleMedia(url: String, withParameter parameters: Parameters, mediaName: String, mediaData: [UIImage], httpMethod: HTTPMethod, completion: @escaping apiCompletionBlock)
//    {
//        if Reachability.isConnectedToNetwork()
//        {
//            let aUrl = APIUrls.BASE_URL + url
//            var headers = HTTPHeaders()
//
//            headers = ["Content-Type": "application/json"]
//
//            if UserDefaultHelper.authToken != nil {
//                headers = ["Content-Type" : "application/json",
//                           "TOKEN" : "\(UserDefaultHelper.authToken!)"]
//            }
//
//            AF.upload(multipartFormData: { multipartFormData in
//                if mediaData.count > 0 {
//                    for data in mediaData {
//                        guard let jpegData = data.jpegData(compressionQuality: 0.5) else {
//                            return
//                        }
//                        multipartFormData.append(jpegData, withName: mediaName, fileName: "file.jpeg", mimeType: "image/jpeg")
//                    }
//                }
//                if parameters.count > 0
//                {
//                    for (key, value) in parameters
//                    {
//                        if let data = ((value as AnyObject) as? [[String:Any]])
//                        {
//                            let arrData =  try! JSONSerialization.data(withJSONObject: data, options: .prettyPrinted)
//                            multipartFormData.append(arrData, withName: key as String)
//                        }
//                        else if let data = ((value as AnyObject) as? [Any])
//                        {
//                            //multipartFormData.append(data.description.data(using: String.Encoding.utf8)!, withName: key)
//
//                            let arrData =  try! JSONSerialization.data(withJSONObject: data, options: .prettyPrinted)
//                            multipartFormData.append(arrData, withName: key as String)
//
//                            //multipartFormData.append(arrData.description.data(using: String.Encoding.utf8)!, withName: key as String)
//
//                        }
//                        else
//                        {
//                            multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
//                        }
//                    }
//                }
//
//            }, to: aUrl, method: httpMethod , headers: headers) .response { (response) in
//
//                switch response.result {
//
//                case .success( _):
//                    //to get JSON return value
//                    if let data = response.value {
//                        if data != nil {
//                            do {
//                                let dicFromData = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
//
//                                if let JSON = dicFromData as? [String: AnyObject] {
//                                    print("\(url) = \(JSON)")
//                                    completion(JSON, true)
//                                }
//                            } catch{
//                                print(error)
//                                let temp = NSDictionary.init(object: error.localizedDescription, forKey: "message" as NSCopying)
//                                completion(temp as! [String : AnyObject], false)
//                            }
//                        }
//                    }
//                    break
//
//                case .failure(let encodingError ):
//
//                    print("Error = \(encodingError)")
//                    let temp = NSDictionary.init(object: encodingError.localizedDescription, forKey: "message" as NSCopying)
//                    completion(temp as! [String : AnyObject], false)
//                    break
//                }
//            }
//        }
//        else
//        {
//            let temp = NSDictionary.init(object: ACAlertTitle.INTERNET_ERROR, forKey: "message" as NSCopying)
//            completion(temp as! Dictionary<String, Any>,false)
//        }
//    }
}

