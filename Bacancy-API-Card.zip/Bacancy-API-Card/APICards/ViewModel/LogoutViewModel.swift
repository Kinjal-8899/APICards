//
//  LogoutViewModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 14/04/22.
//

import Foundation

//MARK: - LogoutViewModelDelegate
protocol LogoutViewModelDelegate {
    func didReceiveLogoutResponse(logoutResponse: LogoutModel?)
}

//MARK: - LogoutViewModel
struct LogoutViewModel
{
    var delegate : LogoutViewModelDelegate?

    //MARK: - logout User
    func logoutUser(email : String)
    {
        let logoutResource = LogoutResource()
        logoutResource.logoutUser(email: email) { result in
            self.delegate?.didReceiveLogoutResponse(logoutResponse: result)
        }
    }
}
