//
//  ProfileViewModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 29/06/22.
//

import Foundation

//MARK: - PaymentViewModelDelegate
protocol ProfileViewModelDelegate {
    func didReceiveReportsList(response: ReportsModel?)
    func didReceiveUserData(response: LoginResponse?)
}

//MARK: - PaymentViewModel
struct ProfileViewModel {
    
    var delegate: ProfileViewModelDelegate?
    var profileResource = ProfileResource()
    
    
    func getReportlist() {
        profileResource.getReportslist { result in
            self.delegate?.didReceiveReportsList(response: result)
        }
    }
    
    func getReportlistBetweenDates(startDate: String, endDate: String) {
        profileResource.getReportslistBetweenDates(startDate: startDate, endDate: endDate) { result in
            self.delegate?.didReceiveReportsList(response: result)
        }
    }
    
    func getUserData(userId: Int) {
        profileResource.getUserData(userId: userId) { result in
            self.delegate?.didReceiveUserData(response: result)
        }
    }
    
    func setAppPermissions(params: Dictionary<String,Any>) {
        profileResource.setAppPermission(params: params) { result in
            self.delegate?.didReceiveUserData(response: result)
        }
    }
}

extension ProfileViewModelDelegate {
    func didReceiveReportsList(response: ReportsModel?) { }
    func didReceiveUserData(response: LoginResponse?) { }
}
