//
//  JobViewModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 04/05/22.
//

import Foundation
import UIKit

//MARK: - JobViewModelDelegate Protocol
protocol JobViewModelDelegate {
    func didReceiveJobListResponse(jobsResponse: JobModel?)
    func didUpdateJobTomeLog(response : JobData?)
    func didReceiveJobDetails(response: JobData?)
    func didUpdateBreakData(response: JobData?)
    func didReceiveTodayJobs(response: TodayJobModel?)
    func didCancelJob(response: JobData?)
}

//MARK: - JobViewModel
struct JobViewModel
{
    var delegate : JobViewModelDelegate?
    let jobResource = JobResource()
    
    //MARK: - Get all Job data
    func getJobList(params: Dictionary<String,Any>?)
    {
        jobResource.getJobListData(params: params) { result in
            self.delegate?.didReceiveJobListResponse(jobsResponse: result)
        }
    }
    
    
    func cancelJob(jobId: Int, companyId: Int) {
        jobResource.cancelJob(jobId: jobId, companyId: companyId) { result in
            self.delegate?.didCancelJob(response: result)
        }
    }
    
    //MARK: - Get all Job data Between Dates
//    func getJobListBetweenDates(startDate: String, endDate: String)
//    {
//        jobResource.getJobListBetweenDates(startDate: startDate, endDate: endDate) { result in
//            self.delegate?.didReceiveJobListResponse(jobsResponse: result)
//        }
//    }
    
    //MARK: - Get details of particular job with jobID
    func getJobDetail(jobId: Int) {
        jobResource.getJobDetails(jobId: jobId) { result in
            self.delegate?.didReceiveJobDetails(response: result)
        }
    }
    
    //MARK: - Start or stop job
    func startStopJob(jobId: Int, eventName: String, eventType: String, images: [UIImage], videos: [URL],image_type: String) {
        jobResource.startStopJob(jobId: jobId, eventName: eventName, eventType: eventType, images: images, videos: videos, image_type: image_type) { result in
            self.delegate?.didUpdateJobTomeLog(response: result)
        }
    }
    
    //MARK: - Break in or out job
    func breakInOut(jobId: Int, eventName: String, eventType: String) {
        jobResource.breakInOut(jobId: jobId, eventName: eventName, eventType: eventType) { result in
            self.delegate?.didUpdateBreakData(response: result)
        }
    }
    
    //MARK: - get Todays Job Data
    func getTodaysJobData() {
        jobResource.getTodayJobs { result in
            self.delegate?.didReceiveTodayJobs(response: result)
        }
    }
    
    //MARK: - get Todays Job Data
    func getBetweenDatesJobData(startDate: String, endDate: String) {
        jobResource.getBetweenJobsData(startDate: startDate, endDate: endDate) { result in
            self.delegate?.didReceiveTodayJobs(response: result)
        }
    }
}

//MARK: - extension of JobViewModelDelegate for non-mandatory methods
extension JobViewModelDelegate {
    func didReceiveJobListResponse(jobsResponse: JobModel?) { }
    func didUpdateJobTomeLog(response : JobData?) { }
    func didReceiveJobDetails(response: JobData?) { }
    func didUpdateBreakData(response: JobData?) { }
    func didReceiveTodayJobs(response: TodayJobModel?) { }
    func didCancelJob(response: JobData?) { }
}
