//
//  PaymentViewModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 17/05/22.
//

import Foundation

//MARK: - PaymentViewModelDelegate
protocol PaymentViewModelDelegate {
    func didReceiveResponse(response: PaymentModel?)
    func didReceiveTransactionList(response: TransactionModel?)
    
}

//MARK: - PaymentViewModel
struct PaymentViewModel {
    
    var delegate: PaymentViewModelDelegate?
    var paymentResource = PaymentResource()
    
    //MARK: - make Payment
    func makePayment(params: Dictionary<String,Any>) {
        paymentResource.makePayment(params: params) { result in
            self.delegate?.didReceiveResponse(response: result)
        }
    }
    
    func getTransactionlist() {
        paymentResource.getTransactionlist { result in
            self.delegate?.didReceiveTransactionList(response: result)
        }
    }
    
    func getTransactionlistBetweenDates(startDate: String, endDate: String) {
        paymentResource.getTransactionlistBetweenDates(startDate: startDate, endDate: endDate) { result in
            self.delegate?.didReceiveTransactionList(response: result)
        }
    }
}

extension PaymentViewModelDelegate {
    func didReceiveResponse(response: PaymentModel?) { }
    func didReceiveTransactionList(response: TransactionModel?) { }
}
