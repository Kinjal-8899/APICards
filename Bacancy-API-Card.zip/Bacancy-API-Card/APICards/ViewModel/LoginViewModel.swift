//
//  LoginViewModel.swift
//  APICards
//
//  Created by Harindra Pittalia on 11/04/22.
//

import Foundation

//MARK: - LoginViewModelDelegate
protocol LoginViewModelDelegate {
    func didReceiveLoginResponse(loginResponse: LoginResponse?)
}

//MARK: - LoginViewModel
struct LoginViewModel
{
    var delegate : LoginViewModelDelegate?

    //MARK: - login User
    func loginUser(loginRequest: LoginRequest)
    {
        let validationResult = LoginValidation().validate(loginRequest: loginRequest)

        if(validationResult.success)
        {
            //use loginResource to call login API
            let loginResource = LoginResource()
            loginResource.loginUser(loginRequest: loginRequest) { (loginApiResponse) in

                //return the response we get from loginResource
                DispatchQueue.main.async {
                    self.delegate?.didReceiveLoginResponse(loginResponse: loginApiResponse)
                }
            }
        } else {
            self.delegate?.didReceiveLoginResponse(loginResponse: LoginResponse(data: nil, type: "error", status: 400, message: validationResult.error))
        }
     
    }
}
